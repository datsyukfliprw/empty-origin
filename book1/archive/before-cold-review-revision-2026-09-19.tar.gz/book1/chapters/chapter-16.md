CHAPTER SIXTEEN

Iven needs a saw.

I look at the word in the mirror, then at the question I spent half the night making large and careful. Somewhere in my head I had prepared for medicine, company, news of his children. A tool hadn't made the list.

“He says small teeth,” I tell Dain. “For metal.”

Mara has already begun writing the next question. Her letters are better than mine and substantially less surprised.

*What are you cutting?*

Beyond the bright strip, Iven lowers his board. His hand remains around the rail for a moment before he lets go and disappears through the gray door.

“He should tell us before he walks off,” Mara says.

Then she rubs the chalk away. There is nowhere useful to send that sentence.

It is first daylight on my fifth reading day. The yard below smells of wet ash and bread, and I have arrived with four reserve, a shoulder that complains when I reach behind my back, and absolutely no idea how to give a saw to a man in another building that may be on another planet. The shutter checks are done. The spindle hasn't moved. Harra waits beside the red retraction handle with a measuring extension laid along the wall.

Iven returns dragging something.

For a second all I can see is a dull silver line against his trouser leg. He lifts it across the landing, sets one end on the rail, and moves his mirror so we can see the other.

A length of metal with a hole through one end. Two more pieces hang from it at right angles.

“Bed frame?” I say.

Dain takes the hood. “Ask whether those are joints or bends.”

They are joints. Iven has loosened two and cannot get the third apart. There are beds in the upper room, he tells us, narrow ones with fabric bottoms. One is broken. The long piece would reach across the missing stair if he could detach it, and he wants to push a line across to us.

Mara stops writing.

“He wants to walk on that?”

She puts the question on the slate. The answer comes back underlined.

*No. I'm a sluicewright.*

Dain coughs into his beard. Mara glares at him, and for one strange instant I can almost see the three of them having this argument in an ordinary workshop, before a wheel took four years out of the room.

We send back the shape of our access. Iven knew the old lower route; he doesn't know about the sleeve or where we are standing. Dain draws a little person above the chamber, adds the rod, crosses out the idea of a hand reaching through it. Iven studies that for a long time.

His next board says he can use the metal strip to measure the broken flight. He has thin cord pulled from a bed and one surviving section of his old folding rule. If we show him our ruler, he can check which divisions Dain wants him to use.

No delivery yet. But something he can do from his side.

Harra lifts the long wooden measure into the patch caught by our mirror. Iven shows us the worn divisions on his rule, then uses its sound section to mark the metal strip. We spend the next several minutes agreeing which marks he is counting. The reflections make every length look different; Dain trusts the rule in Iven’s hand, not how large it looks beside ours.

“Six feet here,” Dain says when he has checked the marks. “Our feet. Put that in your copy.”

I do. My handwriting leans into the margin.

On the landing Iven kneels carefully, keeping one knee behind the rail post. His cord lowers into the break. We lose the end in blackness.

Mara grips her pen with both hands.

I want to tell him to stop. I want him to have measurements when he comes back up. I stand very still and let a man who has been living there make a decision in his own room.

---

Tolliver finds me eating bread beside the workshop after the first contact closes.

He has a coil of survey cord over one shoulder and mud on his knees. I hadn't known where he was this morning. The small unasked question has followed me through the gallery, and now I resent how pleased I am to see its answer walking toward me.

“Work?” I ask.

“North collector. Dain wants the old wash channel checked against the levels we took.”

“For today?”

“Today and tomorrow. Eight bits each, food and a bunk.” He takes a piece of bread when I offer it. “After that, he needs to know what he can afford.”

“You get the reader rate.”

“I'll try to survive the distinction.”

He sits beside me, leaving room for the coil. His hair has escaped its tie at the temple. I tuck the loose strand back before I remember we haven't quite learned how to be around each other this morning.

He turns toward my hand. I let it rest briefly against his cheek.

“How was last night?” he asks.

The question is quiet enough that I could pretend to misunderstand it.

“Good.”

He nods, looking at the bread.

“I don't want details,” he says.

“All right.”

“I did want to know whether you'd look as though you'd been caught when you saw me.”

“Do I?”

“A little.”

“I'm working on it.”

He smiles without quite finishing. Then he tells me about a farmer who found a survey peg and moved it because it was in the way of a bucket. Dain has spent an hour arguing with a hill that became shorter overnight.

I laugh with my mouth full. Tolliver waits for me to swallow before leaning in. The kiss is brief, familiar enough now that my hand reaches for his sleeve on its own. When he gets up, I let it go without making him pull away.

Across the yard Harra is assembling a narrow fork at the end of the measuring rod. It could carry a little packet if we ever get a clear reach. Today it will carry a plumb cord and a wooden crosspiece, all tied back to the rod so nothing can drop loose into the chamber.

“Come see,” she calls.

Tolliver takes his coil north. I take the last of my bread to the bench.

---

The extension is longer than the mirror rod, and much more interested in falling over.

Harra rests it in a second cradle, separate from the viewing frame. A swivel lets her point the end down toward the chamber floor while the mirror stays still. The collar stops it short of the bright opening. We will touch our side of the sill, then withdraw. Iven will show the remaining steps and the gap on his side with his own strip.

I watch her lower the fork against a block on the workshop floor. The cord straightens. Dain reads a mark.

“That gets the near approach,” he says. “A bridge needs somewhere to start.”

“And somewhere to end.”

“He's measuring that.”

The removable crosspiece isn't wide enough for a person. Even I can see that. Still, the sight of a tool reaching the same place twice loosens something in my chest. We have spent days looking. This is a thing we could repeat with our hands.

Harra shows me the side handle. My job is to keep the cradle from twisting while she changes its angle. The bolts take the weight. There are stops beneath it and a catch that will hold if we let go.

“I want you feeling for the twist,” she says. “You aren't a third bolt.”

I put my feet where Sella showed me yesterday. Harra gives the rod a small push, and the pressure reaches my arm cleanly. I can follow it into the floor.

For once I get to say yes knowing which yes it is.

---

Iven's broken flight is worse when he shows it properly.

Three steps descend from his landing. Part of the next hangs at an angle, which explains the fourth edge I thought I saw. Beyond that is a gap, then a lower stub of stair close to the arch. His measuring cord catches on the broken edge twice before he gets it down.

Roughly six local feet between places that might bear weight. Dain makes Mara add *might*.

The metal strip could carry thread across. It cannot carry Iven, and neither landing has yet proved it can take a rescue load. Iven taps the rail post with his tool, shows a spreading crack around the foot, and shakes his head vigorously enough to blur his reflection.

“No rope on the rail,” I tell Harra.

She changes a line on the sketch.

Iven points through the door. His board follows.

*Stone jamb. Could loop behind. Need inspect.*

“Good,” Dain says. He leans closer to the hood. “That's good.”

For the first time since Iven wrote his name, I hear Dain speaking to a colleague who might come back to finish the work.

We show him where our probe will appear. He raises his hand to acknowledge, then keeps his own equipment clear.

Harra feeds the extension through beside the viewing rod. Dain calls the distance as marks pass the sleeve. I keep a hand on the cradle, watching the line of her wrist because I cannot both hold this and look through the hood.

“Down a little,” he says.

She turns the control. The weight comes sideways, heavier than in the yard. I settle into the line and spend one.

The cradle steadies.

There is a pale crumble at the edge of the packing beneath its side shoe.

I see it before I understand it. Dust against dark iron. Then the pressure changes. My rear foot is still solid, my arm still locked into the shape, but the thing I am keeping straight has begun moving where it meets the wall.

“Seat's giving.”

Harra reaches for the catch.

I want to finish the hold. I can feel the reserve working, the absurd conviction that a thing I've paid for must be used all the way. The shoe slips another fraction.

“Let it down,” she says.

I release.

The handle jolts under my hand. Harra lowers the cradle onto its catch with a loud iron knock, and I step back while Dain lifts his head out of the hood.

“Still clear,” he says. “Draw in.”

They retract together. My hand hangs uselessly at my side. I stare at the spot where I should have been stronger until Harra digs a fingernail beneath the packing and lifts out a cracked sliver of old mortar.

“Look at that,” she says.

The new shoe had rested partly on a patch hidden under the old plate. The cradle held the workshop load; this seat had survived only the first, shorter reach here. The longer downward reach found the weak bit.

“You called it,” she says. “Before it took the bolt sideways.”

“I let go.”

“Yes.”

She says it with enough irritation that I finally hear the praise inside it.

Dain sends the pause message to Iven. We close the shutter while Harra removes the bad packing. Sella stays at the doorway until there is room to step in, then lifts my hand and has me open and close it.

“Pain?”

“Same.”

“Then sit until they need you.”

I sit. Through the open door I can see the top of the yard wall, and above it a cloud so white it looks indecent. I used to lose an entire evening to wiping because somebody refused to stop casting when the floor changed color. I am trying very hard not to think about how close that somebody just came to being me.

Harra cuts a proper hardwood seat and fits it on sound stone. Dain loads it with a lever while she watches the edges. They swap places and do it again.

When she asks whether I will take the handle, I stand.

My shoulder pulls. I lower my elbow before she has to tell me.

---

The second hold lasts less than two breaths.

One point. The fork touches stone, Dain calls the mark, and Harra locks the angle before I release. No grit falls. Nothing jumps. I step away and get to the hood in time to see the wooden crosspiece resting on our side of the sill, all of it short of the bright boundary.

It is almost offensively uneventful.

I grin anyway.

Iven lifts his own strip across the far gap, its end stopping on the lower stair stub. He keeps both feet above the break. For a few seconds we can see the start and end of the problem in the same reflection.

Dain takes the measurements. Mara records them. Harra brings everything back through the sleeve with the plumb weight still tied in place.

No one has crossed. We have no line between us. But Iven holds up his board before we finish.

*Can make messenger. Need way to lift me if stair goes.*

Mara copies that sentence slowly.

We have gone from a man beside a rail to a man who has contributed half a rescue design. The difference doesn't fit in the drawing. It shows in how Dain handles it afterward, carrying the sheet flat in both hands.

Outside, I sit on the step and open my measure.

**[MAYA SZCZEPANIAK, LV. 3]**

I blink. The letters remain.

**[PROGRESS: 0 / 18]**

**[RESERVE: 2 / 5]**

**[RUN: WARDER]**

Five spaces. Only two filled. My shoulder aches exactly as much as it did before the universe decided I had improved.

I count the spaces again.

Sella comes down behind me. “What?”

I point at my head, although I know she can't see the private measure. “Three.”

“I can read.”

“You could sound more excited.”

“I was waiting for you to notice.”

“You saw?”

“When you came out.” Her grin widens as mine does. “There it is.”

I laugh, and this time there is no embarrassment in it. One more point I can have in me. One more chance to do something before being empty. No sword, no fire, no sudden knowledge of how to land without hurting my foot. I want all of those things too. Right now I want to look at the five spaces until they feel ordinary, which might take several years.

Sella sits one step above and lets her knee rest against my back.

“Two left?” she asks.

“Yes. It didn't fill them.”

“Good to know before you try something stupid.”

“I'd already scheduled something tasteful.”

Her laugh reaches the back of my neck. I tilt my head against her knee for a moment, then sit forward because people are carrying equipment past us and I want to watch it leave whole.

---

The dispatch arrives before supper.

Pell reads it standing in the yard. Dain has spread our sketch across a crate; the paper is trying to curl toward his greasy thumb. I have been paid my fifth piece, bringing me to forty-six bits, and was about to put the money away when Pell calls us over.

“Captain Rusk has received the change of work,” she says.

Dain looks up. “Good.”

“She acknowledges it. She reserves the recovery claim.”

Vey comes across from the records stair. He seems to know which paper Pell is holding before she offers it to him.

“What recovery claim?” I ask.

“The inner iron formed part of the crew's payment,” Pell says. “When it was to be cut out.”

“And now it isn't.”

“Now we have suspended removal. That doesn't pay for the men or the equipment she has brought.”

I look at the sketch. Six feet of nothing beneath a man's boots. A lifting device starts to acquire a price before I've even seen it.

Pell reads the last paragraph aloud. Captain Rusk has long shear legs, chain tackle, experienced hands. She is prepared to consider retrieval work. Any departure from the original salvage arrangement requires agreement on the resulting access and recoveries.

“She knows about Iven?” Mara asks.

“I told her there is a living man.”

“Then he isn't a recovery.”

“No,” Pell says. “He isn't.”

Vey folds the dispatch along its existing crease. “She will want to hear what we have found before naming a price.”

I watch him put his thumb over the captain's seal.

“Will you tell her about me?”

He looks at me, and for once he seems to hear the whole question before answering.

“She can ask you.”

The promise is narrow enough to keep. I intend to remember it.

Tomorrow is my last reading day. The crew will come with the equipment Dain has drawn as an empty box above Iven's stair. I had pictured a crane, or a rope, or whatever people here use when one frightened body needs moving over a hole.

Pell takes back the dispatch and goes to find somewhere for the captain's men to sleep.

On the crate, Dain writes a weight beside the empty box.
