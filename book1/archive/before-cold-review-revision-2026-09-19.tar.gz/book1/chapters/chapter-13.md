CHAPTER THIRTEEN

Dain draws a door in spilled flour and puts his breakfast on the other side of it.

“That's you,” he says, pointing to the door. “That's the part you want to look at.”

“Your egg.”

“The arch. Do keep up.”

I have been awake for an hour and already found a man willing to explain why my plan is bad using food. On Earth this would have required a comment section.

He draws another line with the handle of his spoon. The kitchen table rocks under his hand. Around us people finish eating, collect tools, argue about a missing glove. My second reading day has not started. I stand beside his bench with my copied page, trying to get to the important part before he finishes eating.

“The service passage goes here. Wheel stands back around this bend, above the chamber floor. Man at the wheel can't see through the arch. Elena was right about that.”

“Could somebody hold a mirror at the bend?”

“Yes. Somebody could stand in the passage we closed because water rose over a man's head.”

I look at the flour. “Right.”

He eats the egg.

There goes the destination.

“Could we look from higher up?”

He stops chewing. Then he draws a short line above the door.

“There's an inspection gallery. Separate stair from the yard. It has a sleeve through the chamber wall for checking the gate seat. We used to put a lamp through it. Mirror on a rod, sometimes.”

“You already have one?”

“Had. Mirrors break.”

“But the hole's still there.”

“So are several things I wouldn't put your arm in.” He wipes the spoon on his bread. “I'll inspect the upper access after the bank walk. If it's sound, I can see what the sleeve gives us without unbarring the service passage. Nothing turns. Nobody goes down to the chamber.”

I pull the bench out and sit. My knee hits the table, which shifts his cup through our diagram.

“Sorry. If you look through it now, what will you see?”

“I don't know.”

“But it was closed.”

“The cover was closed. The access was closed. The wheel was at its old mark. Yesterday the last of those changed.”

I look at his flour drawing again. The locked cover and the thing beyond it are farther apart than I had understood.

I turn my sheet over. “Can you draw it on something I won't eat?”

He looks down at the table, then hands me the spoon.

“You draw. I'll correct you.”

By the time Tolliver comes in, I have made the gallery twice as large as it should be and accidentally connected the mill to a place Dain identifies as a solid hill.

Tolliver leans over the back of my bench. “Planning improvements?”

“I'm replacing stone with optimism.”

His mouth is close to my temple. My attention goes there so fast I lose the end of Dain's next sentence. Tolliver waits until the old man bends over the corrected drawing, then touches two fingers to the back of my hand.

“Morning,” he says, quietly enough that it belongs to me.

“Morning.”

He smells of soap and the leather of his bow strap. Last night comes back in pieces: the stair under my legs, his thumb moving at my waist, the small breath he took before I kissed him again. I want to pull him down beside me. Dain knocks the spoon against the table.

“If the pair of you are finished discovering breakfast, I've a bank to walk.”

Tolliver straightens. “Outer bank. I heard.”

“Then bring the long measure.”

He goes to fetch it. I watch him get through the kitchen doorway without turning to check whether I follow.

Dain folds my drawing. “Bring the page to Mara. Ask whether Elena tried it. I'd rather break something new.”

---

She did try it.

The entry is six written pages beyond the warning, between a calculation neither Mara nor I can explain without Dain and a complaint about a blister on Elena's heel. Mara has numbered the written pages on loose slips, thirty-six of them, so we can finally stop describing our place as the one after the beetle.

The unfinished pages wait with their slips sticking out of the tray. Today we follow the works entries.

*Upper sleeve. Mirror sees near jamb, floor. Can't see around the return. Need elbow beyond inner face.*

Underneath, a little drawing shows a rod with a hinged end. Elena has crossed it out.

*Hinge droops under its own weight. String control no good. Lost glass. Dain furious. Correctly.*

I look at Mara. She is reading the local sentence she has just written, lips moving slightly.

“Did he tell you?” I ask.

“He sent a charge for the glass.”

“Did she pay?”

“She argued that looking at the works was work. He argued that the mirror had belonged to his wife.”

“Oh.”

“She paid.”

I turn back to the drawing. The hinge is tiny. The failure took one line to record. Somewhere below that line there had been a sound, and Elena had stood here holding the useless end of a rod while a man counted the cost of something that could not be replaced merely by buying another.

I had been enjoying finding her jokes.

Mara makes room for the next sheet. “Read the rest.”

There are measurements of the sleeve, a note about the position of a stone projection, and three attempts to turn the geometry into something that will fit through a round hole. The last drawing uses two fixed mirrors. There is no result beside it.

“Proposed,” I say before Mara writes anything. “She hasn't said she built this.”

Mara adds the word.

Farther down, the handwriting changes. Smaller, less space between lines. A date in local script follows the date on the accident statement.

*He kept asking whether the light meant morning. I told him I didn't know. Remember that if I start pretending I knew anything.*

I hold the page flat at its clean margin.

“Who?” Mara asks.

“She doesn't say.”

But I can see her deciding. Her pen stays just above the copy, waiting.

“I think she means Iven,” I say. “I can't put his name in the sentence for her.”

“Then don't.”

Mara writes what is there. Outside, a cart rolls past the window with one bad wheel, a little silence between every knock. When it has gone, she asks me to continue.

The next entry is less kind to hope.

*Same wheel mark did not give the same water. Two readings, a day apart. Temperature changed. Mark is a place to start, not an address.*

I say *address* and my hand moves toward the scrap in my clothes, Elena's name and the Missouri dates. I don't touch it. I still have ink on my fingers.

“So even if you put it back,” Mara says.

“You might not get the same place.”

“Or the same water from that place.”

“Yes.”

I hate that she is better at this distinction than I am. I want a dial with numbers around it and one number that means the street outside my apartment. I want to tell Dain where to point it and be a difficult passenger instead of a person who doesn't know whether there is a road.

Mara sands the copy. “We'll ask him about the readings.”

We keep working. Two labels describe samples taken from the outlet; one agrees with the warm water and pale grit, the other has a date but no surviving sample attached. Another tag reads *not brass?* and proves, when Mara opens its wrapper, to be tied to a greenish washer. I translate the question mark too.

At midday I have seven pages of notes, an aching hand, and considerably less faith in a mirror than I had at breakfast.

---

Sella is eating an onion like an apple.

I find her beside the closure rope with a heel of bread, a knife, and the expression of someone who has been asked whether the lower pump is open enough times to consider moving it personally.

“That's horrifying,” I tell her.

She looks at the onion. “Small ones are sweet.”

“I meant the job. But thank you for adding texture.”

She grins and offers me the bread. I have brought my own food from the kitchen. We eat on a low wall where she can see both approaches to the path.

The sight box is quiet. Below the rope, the locked iron cover lies over the service stair. A second, narrower stair climbs along the bank to a squat stone building I had taken for a shed. Now that Dain has put it on paper, I can see how the upper gallery sits above the chamber, how a wall could hide a whole drop from someone standing in this yard.

“I'd like another lesson,” I say.

“Good. I'd like another guard. Neither of us gets what she wants until someone relieves me.”

“What about here?”

She looks down at my hands. The linen has come off; the skin beneath is pink and still pulls when I make a fist.

“Feet, then. No shield.”

She puts her bread on the wall and makes me stand with my forearms against a square pier. I know this part. My body takes more convincing.

“Don't spend.”

“I wasn't going to.”

“You got the face.”

“What face?”

“The one people get before using reserve to avoid learning.”

I give her a different face. She seems to enjoy it.

We practice the step away from the wall, the reset, the weight coming through my legs. When someone approaches, she leaves me standing there and goes to turn them back. I watch where she puts herself. Beside their route, enough room to stop, her sword still sheathed. She gets a man with a sack to change direction without touching him.

When she returns, I ask, “Is there a way to move while holding Brace?”

“There are moving holds. You haven't got this one yet.”

“Cruel but accurate.”

“What happens at the end of three breaths?”

“It stops.”

“What do you do before that?”

I look at my arms against the stone.

“Hope somebody kills the thing.”

“That worked once. Let's give you another choice.”

She presses against my hip while I hold the ordinary stance. On her count I take my weight back, let my forearms leave the pier, and step. The first time my rear heel catches a stone and she has to catch me.

The second time I do it right.

“Now spend one. End it yourself on two. You don't have to use every breath you bought.”

The pattern opens easily. That is the seductive part. No password, no loading screen, just the right arrangement of body and attention, and the stone feels connected to the ground through me.

One breath. Sella's hand rests lightly at my waist.

Two.

I stop feeding the hold. Pressure returns to my muscles; I step back as we practiced, and for once none of me ends up sitting down.

Sella's hand lifts away.

“There.”

I grin before checking my measure. Three reserve left. Progress nine out of fourteen.

Only one more than last night, and I like it more than I expected. I know what I did this time. At least one useful thing went into the number.

“Again?” I ask.

“Without spending.”

“You take the glamour out of everything.”

“You should see me at a dance.”

The picture arrives before I can stop it: those hands, without the guard work between them. I look at her face instead of the place she touched me.

“Do you dance?”

“When someone asks well.”

She gives me time to do something with that. A ridiculous amount of time, perhaps two seconds, during which I acquire complete awareness of my boots.

“How old are you?” I ask.

Her eyebrows rise. “Is there an age restriction?”

“No. I just— You said three years on caravans. I didn't know whether you'd had a birthday since.”

“Twenty-one. Summer birthday. You?”

“Nineteen.”

“You look nineteen when you try to explain something you didn't mean to ask.”

I laugh, finally, and she smiles without rescuing me from it.

Another worker approaches. She goes to intercept him, and I practice my step while watching the turn of her shoulders. This is possibly the least efficient lesson I have ever paid no money for.

---

Dain and Tolliver return before the afternoon shadows reach the rope.

Tolliver carries a wooden measure with mud halfway up it. Dain carries a covered jar. They come from the outer road, well above the closed towpath, and stop in the yard while Sella waves over the relief guard.

“Found a feeder?” I ask.

“Found a discharge,” Dain says. “Don't give it a direction it hasn't earned.”

He lets me smell the jar. Warm stone, faintly sour water, nothing I can name as another planet. Fine pale grit has begun to settle at the bottom.

“There’s a little outlet under the east bank,” Tolliver says. “Above the main pool. Couldn't see it from the road. Warm water's killed the grass around the lip.”

“New?”

“Bare patch isn't. Fresh silt over the old roots is.”

Dain takes the jar back. “We'll measure it again tomorrow. No one puts anything down it. Might be carrying water from the chamber. Might be a separate spring.”

I bring him the page about the same mark giving different water. He sets the jar beside it and reads, then carries both toward the upper building.

At the upper building he leaves me outside with Tolliver while he and two house workers inspect the stair and gallery. The door has its own seal, a crust of wax across a cord. Dain has Mara brought to record its opening. Below us, the service cover remains locked.

It takes most of an hour. I sit on the stair with my copies on my knees and read Tolliver the mirror entry. He stops scraping mud from the measure when I reach the part about Dain's wife.

“I won't suggest borrowing another,” he says.

Dain comes out dusty and annoyed, which I choose to take as encouraging.

“Upper stone's sound. Dry landing. Sleeve cover holds. There's light beyond it.”

My fingers tighten on the paper.

“What kind?”

“A strip at the shutter edge. White. I didn't open it.”

“Could it be daylight?”

“Could be.”

I look at the solid bank behind him. He looks too.

Pell arrives while he is reading Elena's proposed two-mirror arrangement. She hears about the light, then the outlet, then asks what they cost her. Dain says an inspection mirror from the fitting chest, timber for a frame, and two workers tomorrow. She gives him all three.

“No turning the inner wheel,” he says. “I want a restraint on the upper spindle before we expose the sleeve. The old tooth stays missing. This is a separate clamp.”

“Can you fit it from the gallery?”

“Yes. Socket's above the floor. Provided the face is sound once we clean it.”

“Then that first. Observation after you approve the fitting.”

I start to speak. Pell turns toward me.

“Can she observe from outside the controls?” Pell asks.

“Behind the frame,” Dain says. “I need her if there's writing.”

Pell looks at me. “You can refuse. Your reading agreement stands.”

“I want to look.”

“Then show me the arrangement tomorrow.”

She reminds him that the removal crew comes in four days. He says he remembers. Neither of them mentions giving those days to me.

---

My second piece goes beside the first and the six bits. Twenty-two bits, if I spread my whole life across a counter.

I don't. I tie the purse and put it away.

Tolliver finds me at supper before the stew has cooled. He has been paid for his first survey day; he tells me when I ask, without showing me a sum I haven't earned the right to count. Tomorrow is the second. After that, he says, Dain might want an escort when the removal crew inspects the outer route.

“You don't have to keep finding work here,” I tell him.

“I know where the road is.”

The answer stings before I understand why. I had wanted him to say he was staying for me. I had also wanted him to have a reason that didn't cost me anything.

He watches me over his bowl.

“I like sitting here,” he adds.

I move my knee until it touches his beneath the table. He leaves his there.

Across the room Sella is arguing with a carrier over an eastbound fare. He spreads both hands; she folds her arms and makes him start again. I listen longer than I mean to. Tolliver follows my glance.

“She'll get it down,” he says.

“Is she leaving?”

“If she finds the right work.”

I look back at him. “Everyone here has somewhere to go.”

His knee presses gently against mine.

Later he kisses me in the kitchen doorway while somebody behind us complains about drafts. I laugh against his mouth and let him draw me aside. He takes his time, and I forget the carrier until we part.

Upstairs, I lay Dain's corrected drawing beside Elena's. The sleeve is a small circle on both pages. Beyond it he has drawn blank space where her arch stands.

I hold a finger over that space. Light might be a mineral, a trick of water, something ordinary here that I haven't learned to recognize. My head knows this. My hand keeps trying to cover the distance between two bits of ink.

Before bed I write down the part Dain said twice.

*Nothing turns.*
