CHAPTER EIGHTEEN

The shield I can afford is green.

Under the dirt it may once have been an attractive green. Someone has painted a yellow bird in the middle, then painted over the bird, then worn through enough of the second coat to leave an eye watching me from beneath a smear of mud.

“It looks disappointed,” I say.

Harra turns it around. “Look at the straps before you worry about its feelings.”

We are in the stores shed, where retired equipment leans against things that have never been equipment and are presumably waiting for their chance. My reserve is finally full at five. Sella made me check before breakfast and then refused to let me use any of it carrying shields off the rack.

“This one?” I ask, lifting a larger round shield.

“No,” she says.

“You haven't seen me hold it.”

“I can see your wrist.”

I put it down before the wrist files a separate complaint.

The green shield is narrower, wood faced in hide, with a metal strip around the edge and a padded rest behind it. Harra shows me an old gouge that doesn't go through and makes me look along the boards for warping. The straps have been replaced. One buckle has three extra holes for an arm like mine.

“Three pieces, fitted,” she says. “Pell approved the stores sale. Yours afterward.”

Twenty-four bits. Nearly half of everything I own in a piece of wood that is visibly expecting to be hit.

“Can you do two?”

“No.”

“Two and four?”

“The straps cost me work.”

Sella says nothing. I look at her, hoping for the kind of insider signal that means an offer is secretly terrible. She lifts one shoulder. My decision, my money.

I slide my left arm through and settle the weight close. It is still heavy. It doesn't pull me apart the way the round one did. When Sella presses the face, I feel the force reach the floor before my shoulder tries to take all of it.

I take three pieces from my pouch.

Harra counts them and passes me the shield. Thirty bits left, and an object I can put beside my own bed.

Outside, sunlight finds the yellow eye beneath the paint.

“Do people name these?” I ask.

“Some.”

“What did you name yours?”

“Shield.”

“A strong family tradition.”

She smiles, catches my elbow, and turns it until the weight sits correctly. “Come on. Let's see whether you can keep this one.”

---

Before she teaches me anything, Sella has me lift my arm without the shield.

Forward. Out. Slowly over my head. I can reach high enough, but the last part draws an ache across the shoulder that makes me turn my face away.

“There,” she says. “Below that today.”

“It isn't sharp.”

“It doesn't have to stab you to deserve a vote.”

We work behind the kitchen, on a broad patch of packed ground away from the carts. The lesson is included in her preparation work today. She has asked a relief guard to take the boundary; there is nobody waiting for us to kiss quickly so she can abandon her post.

I think this and then immediately think about kissing her. My ability to create a problem out of a solved problem remains impressive.

She draws a straight line in the dirt with a stick.

“Brace will keep you in a doorway,” she says. “What happens when the doorway is the wrong place?”

“I stop bracing.”

“And then?”

“Something bites me while I reconsider my choices.”

“Sometimes.”

She stands with her shield facing mine and places one foot a little behind the other. “Push.”

I push. She gives a fraction, enough for my weight to settle. Then the feeling changes beneath my hands. The shield holds its line while she takes one short step toward me, forcing me back without a shove.

She lowers it.

I look at her boots. “Again.”

“That cost two.”

My excitement rearranges itself.

“Two?”

“And lasts two breaths. One short straight step, forward or back. You start it already knowing where the foot will go.”

“That's expensive.”

“So is falling with someone behind you.”

She calls it Stepguard. The pattern moves the support from one planted foot to the next without letting the shield fold during the transfer. At least one foot stays properly grounded. Turn, jump, reach for another step, and it comes apart. It will take pressure from the facing I've chosen. It will not make a circle around me because I would find that emotionally reassuring.

“Can I Brace at the same time?”

“Try standing still and walking at the same time first.”

“Fine.”

“Finish one. Set the other. Don't try to fix a broken Stepguard by pouring more into it.”

She draws a second line beside the first, wide enough for my feet, and has me walk it without the shield. Then with the shield. Then while she presses lightly against it. Each time I want to lift my foot high enough to feel brave, she tells me to make it smaller.

The movement is infuriatingly modest. I wanted to become someone who could leap through a wall of fire. Today I am learning to shuffle six inches without surrendering my elbow.

After a while my body begins to understand something my head has been arguing with. I can feel the weight stay connected if I don't hurry the back foot. The next patch of dirt becomes part of the movement before I reach it.

“There,” she says. “Remember that.”

I go still, trying to keep the sensation without squeezing it to death.

The shape under Warder answers when I reach toward it. Less settled than Brace, but present. An opening I hadn't known how to look for.

Sella watches my face.

“Found it?”

“I think so.”

“Two if you commit. Even if you fall out of it. We're keeping the push light.”

I nod, set my shield, and spend.

The hold catches. Pressure runs down the line, through the back of my arm and into my heel, then changes as I begin to move. For half a step I am doing it.

Sella's hand drifts toward the rim.

I turn the shield to follow.

The pattern collapses so abruptly that I stagger into her. She catches the top edge and lowers it between us while I hop once to save my balance.

“Why?” she asks.

“Your hand moved.”

“So did your facing.”

“I was keeping you out.”

“You were following me.” She taps the line in the dirt. “You chose there. I invited you somewhere else.”

I look at my boot, now well outside the line, and feel the exact quality of rage I used to reserve for boss mechanics described as simple by someone who had practiced them for six hours.

Three reserve left. The failed attempt took both points.

“Again,” I say.

“No. Walk it first.”

I nearly argue. Then she moves her hand toward the rim and I turn again without spending anything at all.

She raises her eyebrows.

“Oh, shut up.”

“I didn't say a word.”

We walk it first.

---

The successful step is small enough that I could have done it by accident while reaching for salt.

Sella presses straight into the center this time. I choose the patch of ground, let the front foot slide forward, and follow the pressure instead of her hand. Two points leave me. The shield stays where I intended while my weight moves beneath it.

One breath. Foot settles.

I end the hold before I can decide to improve it.

Sella takes her hand away.

For a second neither of us moves. Then she grins.

**[STEPGUARD]**

The word sits beneath Warder when I attend to it, beside Brace. I can recall the moving shape now without spending, imperfectly but distinctly. My measure shows three out of eighteen progress, one reserve out of five.

I have a second ability.

I keep looking from the line to my shield as though one of them might explain why this feels so large. Six inches of dirt. A whole new thing my body can do.

“Was that it?”

“That was one.”

“Don't qualify it yet.”

She laughs. “All right. That was it.”

I put the shield down carefully, straighten, and throw both arms around her before my shoulder reminds me to keep one lower. She catches me around the waist. I kiss her, badly at first because I'm smiling too hard, then properly when she turns her head and pulls me a little closer.

Her palm is warm through the back of my tunic. For several seconds I forget the ability altogether.

When we stop, she looks pleased in a way that has very little to do with the lesson.

“I was going to do that anyway,” I say.

“I hoped.”

She brushes a grain of dirt from my cheek. I want to follow her hand. Instead I lean into it until her thumb stills against my skin.

We stay there long enough for the kitchen door to open and a woman with a bucket to tell us we're standing in the drainage run.

Sella picks up her shield. I pick up mine.

The yellow bird regards the bucket with the appropriate suspicion.

---

Tolliver takes the finished levels to Dain at midday.

He spreads the survey on the wall while I eat. The north field collector stands higher than the abandoned wash channel, and that channel falls to the mill tailrace. He has walked the route from the upper bank. At its narrowest point, old masonry holds a mass of roots and silt above a low opening.

“Water gets through,” he says. “Very little. There are fresh slides either side. Reed-jack tracks under the willows.”

The bread in my mouth loses most of its appeal.

“How many?” Sella asks.

“Two sets I can distinguish. Could be more.”

She moves her cup out of the way so Dain can lay the plan flat.

The warm outlet from the earlier survey is somewhere else. Dain puts his finger on it, then takes the finger off. We are leaving that question where it is. This route would carry ordinary field water around the entire old junction.

A woman arrives while he is explaining, carrying a sack of clotted roots. I recognize her companion: the man who brought Pell drowned seedlings. Today his hands are empty, hanging stiffly at his sides.

“Bera,” Dain says. “Show her.”

The woman pours a little of the sack onto the wall. Pale roots, black rot, a bulb that gives under her thumb.

“That row stood through last year,” she says. “We raised it. Now the collector's backed over the path.”

“Your land?” I ask.

“Rented. My work.”

I look at the dead roots. So much of my idea of farming has been a square of green beside a road. Here is the part that comes apart between someone's fingers after she has already paid for it.

“If you cut toward the wash,” she tells Dain, “take the old barrow track. The soil beneath those willows won't carry you.”

Tolliver moves a mark on his sketch to show the track.

“Will it take your field?” I ask.

“The track? No. If you open it wrong and wash half the bank through, yes.”

She looks at my plate. I wait for her to object to the three.

Instead she asks, “Which bit are you doing?”

“The screen. On the prepared side. Keeping the space while Harra opens the trial cut.”

“Wear boots you can pull out of mud.”

She puts the roots back into her sack. It takes longer than pouring them out.

---

Sella sends her answer east that afternoon.

I see her at the carrier's cart while I am taking the copied contact sheets to Mara. She gives the driver a folded note, tells him which warehouse office, and waits while he repeats it. A routine message leaving with the house dispatches. No dramatic gallop. No reason for me to feel as though a road has closed under my feet.

When she turns, I am still standing there.

“You declined.”

“Yes.”

“Because of—”

“Several things.”

I stop.

She takes the sheets from me before their lower edge brushes a puddle. “The ridge job wasn't the coast. This is three paid days and a better chance of hiring east from here if the works open. I want to see the rescue through far enough to know what I'm being asked to do.”

“And?”

“And you are here.”

It is the part I wanted. Hearing it makes me wish she hadn't had to send the note.

“I can't make that up to you.”

“I haven't given you a bill.” She hands me back the sheets. “I do want to leave this yard eventually. Don't get comfortable with me always being on the other side of your lesson.”

“I'd like to go somewhere with you.”

“Somewhere you can name, when you can mean it.”

Her voice isn't angry. That makes it harder to supply a charming answer and leave the meaning to later.

I touch the folded edge of the survey in my pocket.

“Tonight,” I say. “The kitchen roof has a flat bit. I saw a ladder.”

She looks at me for a moment and begins to smile.

“Ambitious distance.”

“I can name it.”

“Ask the kitchen first.”

---

The second sluicewright reaches Rook before the evening meal.

Oret is a small man with a shaved head, spectacles tied behind his ears, and **[SLUICEWRIGHT, LV. 22]** above him. Dain meets him with the survey. Oret doesn't ask to see the mysterious door first. He asks where the field water comes in.

Within ten minutes they are arguing over the old wash channel.

I understand perhaps a third of it. Oret makes Dain show the actual fall instead of the convenient line on the page. Dain makes Oret look at Tolliver's measured points instead of assuming he has guessed them. By the end they agree to a narrow test cut tomorrow, with an upstream stop board ready to close it and everyone working from the barrow-track side.

Oret will watch the downstream outlet. Dain will control the inlet. Harra will lift the little screen and clear the notch. Tolliver and Sella will cover the two banks, with another house guard beside the workers. I will keep the movable screen steady at its end, behind my shield, while Harra gets her tool in. If the ground moves, the cut closes and we withdraw along the track.

Bera offers to show the sound path. Pell agrees to pay her for the morning and keeps the remaining field hands away from the draw.

It feels different hearing my name among the jobs. I try the position once with an empty frame. Harra corrects where I stand. Sella has me practice lowering the screen and leaving it behind, then walking backward along the line with my shield still facing her.

No reserve. I only have one left, and tomorrow needs more than my enthusiasm.

---

We get permission for the roof.

It turns out to be less romantic than I imagined: a shallow platform over the pantry, reached by a short outside ladder, with a rail on two sides and drying onions on the third. The kitchen woman makes us promise not to step on the onions. Sella brings bread, I bring sliced turnip and the heel of cheese left from supper, and neither of us makes a claim about the view.

My day's eight bits are in my room, bringing me back to thirty-eight. The shield is propped beside the bed. For the first time I have left something expensive there without wondering whether the room's owner can decide it is theirs.

Sella sits beside me with her boots stretched out, off duty and smelling faintly of the soap she used to wash the dust from her arms. She has a mending needle stuck through a strip of cloth.

“Really?” I say.

“My cuff is coming off.”

“We're on an outing.”

“Then it can come off somewhere new.”

I hold the cuff while she stitches. Above the yard the evening sky turns a color I don't have a useful name for, pale gold with a greenish edge. I can hear Dain and Oret still arguing below us. They sound happier than they did when they agreed.

Sella asks me about the gulls again. This time I tell her the part where my father lost the rest of his fries and tried to pretend that had been the plan. She laughs with the thread between her fingers, then waits while I remember something else.

I tell her about my mother's car smelling of sunscreen all the way home. About sand appearing in a shoe a week later. I have to stop once. She leaves the needle still until I can continue.

“What would you want to eat?” I ask. “When you get there.”

“To the sea?”

“Yes.”

“Something I can't get here.”

“That includes a lot of things you shouldn't put in your mouth.”

“I'll ask before the second bite.”

I lean against her, laughing. The cloth stays between our hands until she finishes the stitch and lays it aside.

The kiss this time comes without an announcement. She turns toward me, I meet her, and there is enough time to discover how much slower we can make it. When her hand settles at my waist, I move closer instead of trying to turn the feeling into a sentence.

We stop before either of us suggests a room. Tomorrow is waiting in the survey downstairs, and tonight I want this roof to have been a place we actually went.

Sella takes my hand for the ladder, lets me climb down first, and follows with the empty food cloth tucked through her belt.

In my room I place the survey beside the shield. I run one finger along the new strap, then leave both alone and go to bed.
