CHAPTER NINETEEN

Bera walks past her own gate without looking through it.

I look. There are rows under the water, visible as darker stripes where plants used to be. A bucket floats against a fencepost. Beyond it a child's red stocking hangs from a line with its toe almost touching the flood.

“Don't step left,” she says.

I return my attention to the path. My boot was about to go exactly there.

“The grass holds the top,” she says. “Nothing under it.”

Three reserve this morning. I have counted them twice, which hasn't produced a fourth. One Brace and one Stepguard, if I need both. The shield pulls comfortably enough against its new straps that I can briefly forget how much it cost.

My wool skirt is gathered clear of my boots with a borrowed tie. It feels ridiculous until I see Harra knot her own hem higher and stop worrying about it. She carries the tools. I carry a narrow end frame for the screen with my right hand, letting the shield rest against my left hip while we walk.

Ahead, Tolliver raises a hand.

We stop. Sella steps past me without touching my shoulder, moving toward him along the center of the old barrow track. Beyond them the willows grow crooked out of a low bank. The water beneath is almost black.

“Tracks?” Harra asks.

“Movement,” he says.

He points with two fingers. Something makes a low seam through the water, then disappears beneath a shelf of roots.

I remember claws on the cart rail. My fingers close around the screen handle until the edge hurts.

Sella looks back at us. “Stay on the boards when they're down.”

No one needs to explain what the boards are for again.

---

The wash channel looks too small to save anything.

It runs between steep banks toward a mouth of old stone, water slipping through a gap at the bottom. A willow root has lifted one corner of the top slab. Mud fills the rest. Downstream, where Oret and a house worker wait, the channel widens toward the mill tailrace.

Dain stands at the field collector above us. Four workers have stacked clay sacks and a spare screen section beside a stop board fitted into a temporary timber frame. The little trial notch will connect the collector to the abandoned channel. It is narrower than my shoulders. Nobody is opening the whole bank today.

Harra has us lay the two screen sections downstream of the notch, making a short barrier between the work ledge and the willow pool. Water can pass through the closely spaced bars. A reed-jack should have to go around them, where the guards will be waiting.

Should.

Sella watches me watching the roots.

“Your place is here,” she says, putting her boot on the packing board behind my end of the frame. “Harra moves that section, you keep the overlap. If you have to leave, call it and go uphill. Renn covers the opening.”

Renn, the house guard, lifts his spear in acknowledgment. He has a broad nose, a gray mustache and a very comforting lack of interest in whether I look impressive.

Harra takes my right hand off the frame and places it lower.

“Lift from here. Your shield stays between the gap and your face.”

“What a versatile purchase.”

“You should buy a hat next.”

Her tone is ordinary. I borrow as much of that as I can.

Tolliver takes the upper willow bank with his bow. Sella guards the downstream end. Bera has shown the workers the safe track and now waits beyond the clay sacks, where she can point out a change without being inside it.

Dain calls to Oret.

A raised arm comes back from the tailrace. Clear.

Harra settles her pry bar under the clotted edge of the notch. I plant my boots, bring the shield close and look at the place where her section overlaps mine.

“Ready,” I say.

It surprises me to discover that I am.

---

The first water is brown and slow.

It comes through the notch in a thin tongue, pushing a curl of dead leaves ahead of it. Harra works a knot of roots loose. I lift my end of the screen while she shifts hers into the next slot, then lower it again when the overlap is restored.

No reserve. Just work.

She nods once without taking her eyes off the bar.

The little stream reaches the old masonry throat, pauses behind the packed silt, and begins to rise. I can see Oret through the gap between two workers. He has one hand on a measuring staff downstream and the other raised to tell Dain to wait.

Dain waits.

A minute passes. My left forearm starts to ache in the way anything starts aching when I discover I'm expected to keep using it.

Then the mud beneath the throat puckers and lets go.

Water pours out around Oret's staff. He steps back, raises his arm higher, and calls something I can't hear over the sudden rush. The worker beside him repeats it uphill.

“Fall holds!”

Dain grins.

I have never been so pleased by water going downhill in my life.

Bera walks as close as the sacks allow, staring at the channel. She says something to the man beside her, and he bends to watch the mark on the collector staff. Even this small opening is beginning to move it.

“Hold that draw,” Dain calls. “No wider.”

Harra changes her grip on the pry bar. One root remains across the notch, catching everything the water brings. She doesn't need to take it all out. She needs the screen moved a hand's width so she can cut the part above the flow.

I check my footing. The board is firm. Renn stands beyond my right shoulder, spear facing the willow pool.

“Your end first,” Harra says.

I lift.

The scream from downstream is animal, high and horrible.

Something erupts out of the roots beside Sella.

---

The first reed-jack lands against her shield with its whole body.

She was already turning. The impact drives her back one step on the boards, then she catches its head beneath the rim and pushes it down. Tolliver's bow sounds from the upper bank. An arrow hits the water beyond her.

“Too close,” he calls.

“I've noticed.”

The animal twists. It is larger than the one on the cart, wet fur hanging in ropes, front claws hooked around the shield edge. Sella keeps it away from her sword arm, working for a space to strike.

I have turned my head. My screen tilts.

“Maya,” Harra says.

I pull my attention back just as the second reed-jack hits my section from the pool.

The frame slams against the shield. My right hand loses the handle. A mouth opens between two bars, teeth scraping iron, and the pressure drives straight up my left arm.

**[REED-JACK, LV. 6]**

I see the plate without wanting it. I set my boots against the raised back edge of the packing and reach for Brace.

One point.

The shield holds. The frame knocks once against its face, but the load runs through my arm instead of folding it. Harra drags her hand clear of the overlap. Renn's spear comes past my right side, aimed between the bars.

I know he is there. I don't flinch this time.

One breath.

The point catches fur along the shoulder. The reed-jack lets go with its mouth and pulls sideways, dragging the screen toward the deeper pool.

“Don't follow,” Harra says.

I don't. I keep the shield in the line I chose, and Renn drives the spear again. The animal drops beneath the water.

Two breaths.

Harra gets her section down. I end the hold while I still have the shape, then use my right hand to seat my end in its slot.

“Clear my side,” I call.

My voice works. I can hear it through the blood in my ears.

Downstream, Sella has the first animal on the bank. Her sword goes in beneath its jaw. Its hind legs beat against the board twice before stopping.

Tolliver has another arrow drawn. He isn't watching her victory. His gaze is on the root shelf beside my feet.

“The other one's under you,” he says.

The board tilts.

---

At first I think the animal has lifted it.

Then a line opens in the mud beyond Harra's boot. Water rises through it, carrying pale sand, and the whole lower edge of our ledge moves toward the notch.

“Ground!” I shout.

Dain orders the stop board down. The men above haul on its handles. It drops partway and catches on the root Harra hasn't yet cut.

Water continues through.

Harra pulls her bar free and steps uphill. I should follow. But my screen is leaning out over the pool and I still have my hand on it, as though the frame being assigned to me makes it part of my body.

“Maya, leave it.”

I let go.

The frame slides, hanging by one upper pin. Renn shifts uphill to cover us. Beneath the tilted board a narrow head rises, whiskers pasted flat, the spear scratch bright through its fur.

My way back is one short step to the next packing board. Harra has just crossed it. There is no room to turn without putting my back to the mouth.

I set the shield facing downhill, choose that step, and commit the two points I have left.

Stepguard catches.

For one breath I move exactly as Sella taught me. Shield facing the animal, one foot on the old board, the other reaching uphill. The reed-jack jumps. Its weight lands against the lower rim, and the pattern carries it through me while I shift uphill.

My left boot settles.

The board breaks through the ground beneath it.

There is nothing to pass the weight into. The hold comes apart. My left ankle rolls into the hidden hollow and the shield twists hard enough that a metal edge screams against stone.

Pain flashes up the outside of my leg. I fall to one knee with the animal still against me.

Harra catches the back of my tunic.

“Let the shield turn!”

I let my elbow bend. The rim scrapes across my boot as Renn puts his spear between the animal and my face. Its teeth snap closed on the green wood. A piece tears loose.

I can't find any reserve. I don't waste another second searching.

“Pin it there!” I yell.

Renn leans in. I pull my arm out of the loosest strap while Harra hauls me uphill. My ankle hits the edge of the hole and I make a sound I would like never to hear from myself again.

The reed-jack lands where I was kneeling.

Sella's boot comes down on the fallen screen, flattening it across the gap. She meets the animal above my discarded shield with her own. It has nowhere to climb. Her sword hits once, catches, comes free, hits again.

Harra keeps pulling until my hips are on the sound track.

I can see Dain above us, bent over the stop frame. The root is still jammed beneath the board. Water eats at the side of the notch, digging toward the worker beside him.

“The screen,” I say. Harra can't hear. I grab her sleeve. “Flat. Across the soft bit. Put the sack on it.”

She follows my pointing hand. The spare screen section lies beside the clay sacks, wide enough to spread the weight. She shouts to the workers. Two of them lay it over the crumbling edge and slide a sack across it, keeping their own boots back. Another sack follows. The water folds around them instead of stripping the side bank.

Dain levers the trapped root upward. Harra reaches him, cuts the exposed strand with her hooked blade, and the board drops the last few inches.

The rush fades.

I keep watching until the water stops eating the mud. Only then do I look down at my foot.

---

Nobody has been bitten.

Sella makes each of us say it and checks the people whose answers come too fast. Renn has a shallow cut where a splinter came through his sleeve. Harra has mud across her face and a strip of my tunic clenched in one fist.

“I may owe you a hem,” she says.

“You can keep that bit.”

She opens her fingers. The cloth hangs from the seam. We both laugh, briefly and badly, then stop because it hurts my ankle when I move.

Sella kneels in front of me. I watch her unfasten the boot and ease it off onto the mud beside us. She works gently enough that I know she thinks it might be worse than I want it to be.

“Can you feel this?”

“Yes.”

“This?”

“Yes. Fuck.”

“All right.”

She doesn't tell me it is fine. She lifts the foot onto a folded coat and calls for a cart from the field gate.

My shield lies beside her. The lower rim has peeled away for the length of my hand. The bite tore a chunk out of the wood below it, leaving the yellow bird with most of its eye and no apparent improvement in mood.

Yesterday I bought a thing. Today I have nearly fed it to an otter designed by someone who hated ankles.

I reach for it.

Sella puts it within my hand without making me ask again.

“You kept the facing,” she says.

“The ground went.”

“Yes.”

“I thought because Harra had—”

“I know.”

She looks toward the hole. Water is draining out of it through the undercut bank. The board had carried one quick footfall; mine arrived with my weight and an animal on the shield. I can see the difference now, which is an expensive way to learn anything.

“The first hold worked,” she says. “Renn had a place to put the spear.”

I remember the blade coming past on the road and how I broke the Brace myself. Today I knew where he was.

I hold that memory while the ankle throbs.

Tolliver comes down from the willow bank with his bow unstrung. He has checked farther than I could see. Two animals, no more movement found. He doesn't make that a promise about everything in the reeds.

He crouches beside me and puts his hand on the back of my neck. I lean into it without pretending to need help sitting up.

“Your arrow missed,” I say.

“Better than hitting Sella.”

“Yes.”

“Going to make a habit of this?”

“Buying shields?”

He looks at the torn edge and laughs through his nose. His fingers stay against my neck until the cart comes.

---

Oret brings the downstream staff before they lift me.

A wet mark stands well above his first notch. He has measured both the rise and how quickly it drained once Dain closed the cut. Ordinary water, with enough fall to move it through a separate route. The mill tailrace took the trial without backing up.

Dain puts the staff beside Tolliver's drawing. “It works.”

“Provided that stays up,” Oret says.

We all look at the old masonry throat.

The draw has washed mud from beneath the upper slab, exposing a crack that runs nearly through it. Its lower corner sits on roots. Enough flow to drain the fields would take those away too. The slab would drop across the outlet, trapping the water again or breaking the remaining wall downstream.

“We couldn't see that yesterday,” Tolliver says.

“We can today,” Dain answers.

Bera comes down the track, keeping clear of the torn ledge. She has brought my abandoned screen handle, though it isn't mine and I have no idea what she thinks I can do with it.

“How much?” she asks.

“To shore and lift?” Oret looks at Harra. Harra looks at the slab.

“Long legs,” she says. “Chain block. The little house tackle won't take it from this bank.”

Rusk's hook appears in my head, enormous and patiently priced.

Bera pushes the handle into the dirt beside the track as a marker for where the ground is bad.

“The far bed showed,” she says to me. “For a little. Before you shut it.”

I look toward her field. From here I can't see the rows.

“Will it help?”

“If you keep it going after you fix this.” She touches the rotted roots caught in the screen. “These won't come back. But I could put something else there.”

She isn't thanking me for saving her farm. We haven't. Her next sentence is about how many boards the damaged barrow track will need, and Dain writes the number on his plan.

Then she bends, picks my boot out of the mud and puts it in the cart beside me.

“Keep the other one on,” she says. “Road's not getting kinder.”

---

The ride back is worse than the ride from Greyward.

There is no monster, which I do appreciate. There are ruts. Each one finds the ankle no matter how carefully I arrange the folded coat under it. Sella walks beside the cart, and I can tell from the way she lets silence sit that she is exhausted too.

I open the measure when the road smooths enough to hold a thought.

**[MAYA SZCZEPANIAK, LV. 3]**

**[PROGRESS: 9 / 18]**

**[RESERVE: 0 / 5]**

**[RUN: WARDER]**

Halfway to the next level. I wait for disappointment about the zero to swallow it, and it doesn't. The points were there when I needed them. I used a thing I learned yesterday, survived the part it couldn't do, and left with everybody who walked down the path.

I want to do it again better.

The thought arrives so clearly that I almost laugh. My ankle is swelling against a folded coat and I want another chance. My mother would make a face if I tried explaining this. My father would ask whether the next chance could perhaps involve a chair.

At the gate Sella leans on the cart rail.

“What?”

“Nine of eighteen.”

Her mouth curves. “Look at you.”

“I am. Extensively.”

She kisses my forehead before helping me sit up. I don't care who sees it.

---

The house mender wraps the ankle after examining it and making me move my toes several times.

She finds no sign of a broken bone, tells me that is not permission to test her judgment, and orders two days off rough ground before she looks again. No practice tonight. No walking to the gallery because I am bored. If the pain sharpens or the toes lose feeling, somebody fetches her.

Pell pays for the examination and the linen as a work expense. The ankle remains hot and swollen, and my reserve stays empty.

Harra removes the bent strip from the shield before it can cut me. The wood needs a patch and a new length of rim. Pell agrees to cover that too, but Harra needs the shield until tomorrow. I make myself hand it over.

Then the pay clerk arrives with eight bits, and I almost laugh at the timing.

Forty-six. Second preparation day paid. One remains under the present agreement.

I put the pouch away and listen to people carrying the day's tools back through the yard. Some of those tools are broken. All the voices I know are still attached to people who can walk through the door.

---

They hold the discussion at the end of the kitchen table, where I can sit with my foot up on a bench.

I suspect Sella arranged it. She denies nothing and steals half my bread while Dain pins the new drawing to a board.

Pell listens to the report. The independent route has enough fall. The throat needs lifting and rebuilding before a sustained draw. The damaged work ledge needs proper decking. No further trial tomorrow.

Oret places the wet staff beneath the drawing. He has carried it all the way back, proof that doesn't require anyone to trust how excited Dain sounded.

Rusk comes in with her gloves tucked through her belt.

She has finished the third day's redirected work. The outer bank is shored, the upper carrier cleared as ordered. Her crew is paid for that portion, and from tomorrow the rig costs standing time.

Harra shows her the exposed slab dimensions.

Rusk studies them. “I can lift it.”

“Price?” Pell asks.

“A piece per crew member per day. Two for me and the rig. Materials yours. Minimum two days.”

Sixteen pieces. One hundred twenty-eight bits. I know the conversion before my head has stopped resisting the number.

“And your other terms?” Pell asks.

“The access offer remains if you'd prefer that payment.”

“No custody,” Mara says from the door.

Rusk turns. “Then pay in money.”

Nobody answers immediately. The silence makes clear how different this is from having won an argument yesterday.

Vey looks at the drawing. Pell looks at the staff. Dain rubs his shortened fingers against the seam of his trousers.

“The field tenants can provide labor,” Bera says. She has come in behind Mara, leaving mud on the threshold. “Not sixteen pieces.”

“I need trained hands on the lift,” Rusk says. “You can save on carrying stone afterward.”

She isn't wrong. I would like her to be wrong about something cheap and useful.

Pell asks for the cash terms in writing. Rusk agrees, then orders her crew to secure the tackle for the night. Through the window I can see a man fastening the chain chest. The long legs stay assembled, but the operating handle goes into the captain's locked box.

She has left us a way to buy what we need. She has also made very sure we cannot borrow it by accident.

---

After supper, Tolliver and Sella help me upstairs. I keep my weight off the bad foot, an arm around each of them, and discover how much staircase I have been taking for granted.

Mara brings Iven's afternoon reply once I am settled on the bed.

I missed the contact. She tells me he asked why the reader wasn't there, and she told him I was hurt during the drainage test but back at the house. I am glad she didn't make it sound worse. I am glad she didn't decide to hide it.

“He got the joint apart,” she says.

“The bed frame?”

“With one of the tools upstairs. He says he can put a light line over the break now. He wants to know when to try.”

I look at my wrapped ankle, then at the window where Rusk's crew is putting away the last of the chains.

“Tools first,” I say. “We still haven't passed anything through.”

“Dain said the same.”

She unfolds another sheet. Iven has drawn the doorway from his side, including the thick stone around the gray frame. At one edge he has copied a little cluster of local letters uncovered when he moved a loose piece of trim. Below them, in a different hand, are English capitals he has tried to reproduce.

I lean forward until the ankle reminds me.

Some letters are clear. Others could be two different things. I can't make a useful sentence yet.

“He can show it closer tomorrow,” Mara says. “Harra can bring the mirror view to the stool inside the gallery. After the mender agrees to the stairs.”

“Or you can copy it again.”

“Yes.”

The answer feels new in my mouth. I can want the door badly enough to hurt and still let someone else look through the glass for a day.

Mara leaves the drawing on my table. When she goes, Sella comes back with the rest of my bread and sits on the floor beside the bed, carefully clear of the injured foot.

I tell her about the root, the instant before the board failed, the ridiculous conviction that I could finish the step if I wanted it enough. She listens without turning it into another lesson. Then she tells me the first reed-jack nearly took her sword when it twisted, and I listen to her.

Outside, someone hammers the lid onto a packing crate. Rusk is prepared to leave. Iven is preparing a line. The field water is rising again behind the closed trial board.

Sella lays her hand palm-up on the blanket.

I take it and keep talking.
