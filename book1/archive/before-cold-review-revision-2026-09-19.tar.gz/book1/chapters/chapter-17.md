CHAPTER SEVENTEEN

The captain arrives holding a horse's face.

One hand on its cheek, the other curled into the head strap, her shoulder nearly against its mouth. Behind it, a cart leans in a rut with two long timber legs lashed above the load. Every time the horse tries to back, the upper end of a leg swings toward the gatepost.

“Hold your brake,” she says.

The driver holds. A man at the rear starts pushing.

“Not you, Bren. You'll put it over.”

He stops. She waits until the horse's feet settle, then walks it sideways while two other crew members put a plank under the wheel. The cart comes level with a long, unhappy wooden noise.

Only then does she let go.

I have spent part of breakfast picturing someone I could immediately dislike. This is inconvenient.

**[SALVAGER, LV. 23]** hangs above her head. She is thick through the shoulders, with close-cropped brown hair going gray over one ear. A white scar pulls down a corner of her lower lip without making her expression look mournful. She wipes horse spit on her trousers and walks toward Pell.

“Rusk.”

“Pell.”

They shake hands as though testing a fitting.

Six crew members follow her into the yard. One limps off the driving board, stretching a stiff knee. Another checks every rope on the long timbers before allowing anyone to unload. Their chain tackle has a metal casing the size of a bucket and a hook that makes the rest of the yard's hooks look decorative.

Dain comes out of the workshop before the cart has stopped.

“That will fit the upper carrier?” he asks.

“If your dimensions are honest.”

“They were when I sent them.”

“Most are.”

She looks toward the headwall. Her gaze travels past the gallery door to the locked lower cover, then up to the indicator housing. She doesn't ask where the valuable thing is. Someone has already put it on paper for her.

Mara stands beside me with the last tray of labels. My sixth reading day has begun. Four reserve out of five after sleep and breakfast; the empty fifth mark bothers me more than it should. I keep expecting three to feel different in my legs.

Rusk sees us watching.

“The reader?”

“Maya,” I say.

“I'll need half an hour when you've finished.”

“What for?”

“To hear what I'll be lifting.”

Before I can answer, one of her men calls about the tackle. She turns back to work. I am left holding an objection intended for a conversation she has already moved out of.

---

The last English label says *wrong jar*.

There is no jar.

I sit with it for a while, elbows on the records table, enjoying Elena's ability to make trouble four years after leaving a building. Mara matches its string to a stain on the tray and finds nothing conclusive.

“Keep it loose,” I say. “We can't attach it to a sample because it looks lonely.”

She puts it into a folded sleeve.

The notebook's remaining pages are mostly accounts and half-finished observations. I work through them from the numbered slips, compare my copies with the originals, and read back the places where my translation still has gaps. A torn word stays torn. A column of numbers may be measurements, but neither Dain nor I can supply the missing heading.

On the last written page Elena has crossed out a purchase twice. Beneath it is a short list in English: thread, soap, pears if any.

I stare at the pears.

Until now I have met her through arguments with the works, through the card, through evidence that she came from a place I understand. Here she is trying to remember fruit. I wonder whether she found any. I wonder whether she got to eat one before the day with the rope.

“Read it?” Mara asks.

I do.

She turns the book carefully and compares the local amounts below. “This was early. Before the winter.”

“Then maybe she got them.”

“Maybe.”

We finish the thirty-six written pages before midday. Every legible English passage has a translation beside its page number. The unresolved words and missing samples have a separate sheet. The small labels have been compared and copied; none has obligingly turned into a final instruction for fixing the world.

Mara puts the notebook in its tray. Elena's card lies in its own paper sleeve beside it.

“Pell hasn't ruled?” I ask.

“No. She wants the old inventory witnesses. One is upriver.”

“She has time for a salvage captain.”

“The salvage captain is standing in her yard.”

I rub my thumb over a dried spot of ink. Mara takes a fresh sheet, copies the outstanding request's date onto it, and lays it on top of the tray.

“There,” she says. “Now it's standing in her room.”

---

Iven meets the boys through paper again.

This time the elder brings it himself.

I find him outside the records door while Mara fetches the afternoon contact sheets. He is taller than she is and has the same square fingernails, bitten too short on one hand. His brother waits several paces away with his arms folded. Both look at the tray, then at me.

“I'm Teren,” the elder says. “This is Lio.”

“Iven's—”

“We know who our father is,” Lio says.

Teren closes his eyes briefly. I decide not to make him apologize for a sentence I probably deserved.

“Maya.”

“We know that too.” Lio's gaze goes to my plate, then away. “Is it wide enough today?”

“We haven't opened the shutter yet.”

He presses his arms harder against his chest. Teren holds out the folded sheet.

“He asked about the boat. Tell him we sold it before the winter after he went. I wrote it down. I don't want Aunt Mara to leave that bit out.”

Mara has stopped in the doorway behind me.

“I wouldn't,” she says.

“You left out the roof.”

“I couldn't put four years on the first slate.”

Lio looks toward the gallery. “Can we just see him?”

There is a pause in which nobody quite wants to say how small the room is.

Mara glances at Dain coming from the workshop. He listens, looks at the two brothers, then tells them one at a time when the apparatus is settled. No one argues further. Teren's fingers finally loosen from the paper.

I spend most of that contact outside.

For a few minutes I am needed to compare a new scrap of packet writing. Then Dain takes my place at the hood, Mara brings Teren in, and I go sit beside Lio on the wall. Through the doorway I can see only the hem of his aunt's skirt and Harra's hand on the frame.

“How does it look?” Lio asks.

“Small. Through the glass.”

“Does he look old?”

“I didn't know him before.”

He scrapes his boot along the ground. “Everyone keeps doing that.”

“What?”

“Answering something they can.”

I look at his face. There is so much of his father in it that I have to stop myself from saying so. He has probably had enough strangers giving him back pieces of a man they didn't lose.

“Yes,” I say. “He looks tired and older than in the little drawing Mara showed me. His hair is gray. He's been cutting his beard badly.”

Lio looks down. After a while he nods.

When his turn comes, he gives Teren his coat and goes up the stair without it.

---

Rusk has set up her demonstration before she asks for us.

Two timber legs rise over a sling full of stone. Her crew has spread the feet on packing boards. The chain runs through the casing at the top and down to a handle one woman works without visible effort.

The sling comes off the ground.

Rusk walks beneath the outer end of a timber, staying clear of the hanging weight, and points to the bridle.

“Two supporting lines for a person. One fails, the other keeps them out of the hole. My people know the changes. Does your man?”

Dain studies the chain block. “Iven does. Whether his hands still will is another question.”

“We can use a seat sling.”

She motions to the operator, who lowers the stones gently enough that the top one doesn't roll.

I can imagine it too easily. Iven sitting inside a wide band of canvas, the broken stair dropping beneath his boots. The hook here, carrying him toward people who know his name. For a moment I feel such violent gratitude toward this equipment that I have to stop looking at it.

Rusk takes us to the upturned crate where she has laid her terms.

She offers the rig, her six crew, and herself for the retrieval. Rook supplies timber, food, access, and the ordinary works. In return her company gets a season's exclusive use of the opening once it is made workable, first claim on unattended recoveries, and custody of everything brought out until it has been examined.

“Everything?” I ask.

She lays one finger on the page. “Persons housed separately, supplied and cared for during questioning. Goods held against the inventory. Thirty days at most.”

Mara reaches for the paper. Rusk lets her take it.

“He has a home,” Mara says.

“He may also have brought something we can't afford walking into yours.”

Dain looks up at that. She has chosen a sensible fear, and I hate her a little more for choosing it well.

“A mender can examine him,” he says.

“A mender can answer a mender's questions. I need to know what moved, what he touched, what he left. My crew will be hanging above the place that took him.”

“So ask him,” I say.

“I intend to.”

“And if he wants to leave before you've finished?”

She looks at me directly. “Then the thirty days settle that disagreement.”

There it is. On the table with the good sling and the careful knots.

I picture Tolliver standing at a gate, knowing which answer will get me a bed. It is easier this time to see the hand that will close the door because it belongs to someone I don't want to kiss.

“What happens to somebody already living in those rooms?” I ask. “They go for a walk, you find their tools unattended. Do you own them?”

“Established claims can be heard.”

“By whom?”

“My factor and the holding that grants access.”

Pell has been silent until now. She takes the paper from Mara and reads the clause again.

“We can arrange payment for rescue work,” she says. “I won't grant this.”

“You've already granted salvage.”

“Removal of specified iron. Not a season's road through the wall, and not my people.”

Rusk's jaw shifts. Her voice stays level.

“The iron was to pay part of my costs. You have stopped the cut and discovered something you say is vastly more valuable. Now you're offering wages as though I've come with shovels.”

“I have offered no amount yet.”

“You haven't the amount.”

The yard continues around us. Someone drops a bucket. A horse shakes its harness. Pell doesn't deny it.

Vey has been watching the load demonstration from the shade. Rusk turns toward him.

“Master Vey understands the return on an undertaking.”

He steps forward, adjusts the paper so he can read without lifting it, and takes far too long.

I want him to be better now because it would be convenient. I want his money without having to feel what it costs to accept it.

“The season could pay the repairs,” he says.

Mara turns away.

“But this custody clause would have kept Elena here after her wages were settled.” He looks at Rusk. “I supported enough of that.”

“You supported closing a dangerous site. I've been asked to open one.”

“Yes,” he says. “And I'm declining your proposed return.”

The words cost him something before any money moves. I see it in Pell's face: relief, followed by an assessment of what she can now ask of him.

Rusk folds her copy.

“I'll do the redirected work through the third day. After that I charge standing time or I take the rig elsewhere. The original iron claim remains.”

Pell nods once.

The captain calls to her crew. The chain starts moving again, drawing the empty sling up out of my reach.

---

There is no better offer waiting in the records room.

We have a drawing of a broken stair, a possible way to pass a messenger line, and no proof that anything can safely cross the bright edge. We also have flooded fields, a captain who owns the best lifting rig in the yard, and three days of work that won't fix either problem.

Dain rolls Tolliver's survey across the table. The old wash channel runs north of the dangerous works and rejoins the mill tailrace downstream. Its levels are incomplete. Someone abandoned it for a reason.

“If it still falls,” he says, “we can take the field collector that way. Separate from the junction.”

“What do you need?” Pell asks.

He tells her. A second set of levels. Inspection of the old masonry throat. A controlled small draw, with protection against reed-jacks in the banks. More contact with Iven before anyone discusses putting a person through.

Useful jobs. Jobs small enough to fail without taking the entire plan with them.

Pell counts workers on the edge of a scrap. Vey offers three pieces now toward the preliminary work, with no claim on any recovered item. Mara writes that down before he has finished offering it. He gives her the coins.

I look at the north channel. My place in this drawing is not reading an English word somebody else can't read. Dain needs someone holding the screen while his fitter works at the trial notch. A shield, a prepared footing, an instruction to withdraw if the bank moves.

“I can learn that,” I say.

Sella, standing behind my chair, makes a small noise.

“With practice,” I add.

“With a shield that fits you,” she says.

Pell offers three paid preparation days beginning tomorrow. Eight bits a day for my translation, contact records and the agreed trial support; the same meals, room, copies, possessions and return-cart protection. No debt if the rescue fails, no requirement to enter the lower works. Actual retrieval remains a separate decision after the tests.

I read the short addition and sign it. It takes less time than the argument in my head.

Tolliver confirms that his two eight-bit survey days are finished and paid, then accepts ten bits a day for those same three days, with meals and a bunk, for survey and field protection. Sella takes twelve for guard work and the trial. Her pen stops over the final date.

“That overlaps the eastbound job,” I say.

“I can read too.”

She says it gently enough to hurt.

“I'm taking these three days. I'll send the other answer tomorrow.”

I want to ask what answer. Her hand closes around the pen, and I wait while she writes her own name.

---

The clerk gives me my last reading piece at the kitchen door.

Six paid days completed. Fifty-four bits of my own, before I buy anything. I press the coins through the cloth of my pouch, surprised by their weight.

From tomorrow, some of this money will come from standing in the place where trouble arrives. I used to have very strong opinions about people who picked tank because the queue was shorter.

Sella catches me looking at the survey.

“You can still change your job before the trial,” she says.

“I know.”

“Good. Now come eat.”

In the yard, Rusk's crew has built a fenced rack for its chains. The captain is kneeling beside an apprentice, showing him how to find a damaged link by feel. She takes his hand and puts his thumb on the flaw, patient as Sella is when I finally pay attention.

Behind them the great hook hangs from the beam.

I stop long enough to watch the apprentice find the next bad link himself. Then I go inside, carrying the sketch of a way around the water.
