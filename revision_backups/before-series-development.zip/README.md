# Maya — active novel project

Continue from **[book1/WORKING_DRAFT.md](book1/WORKING_DRAFT.md)**, currently through Chapter Fifteen. Individual chapters are in [book1/chapters](book1/chapters).

The latest pass resolved the marked early chronology inconsistencies and added **Chapters Thirteen–Fifteen (10,533 words)**. The full working manuscript is **52,093 words**. See the [continuity review](book1/CONTINUITY_REVIEW.md) for fixes, verification, and the recovery archive.

The two supplied export directories and their ZIPs remain preserved as source snapshots. Their old 200,000-word target is superseded by the author's instructions and the active [project notes](book1/PROJECT_NOTES.md).

Read these before continuing:

1. [Project notes and binding author preferences](book1/PROJECT_NOTES.md), including how to apply the supplied writing system.
2. [Cumulative story overview](book1/STORY_OVERVIEW.md).
3. [Chapter ledger](book1/CHAPTER_LEDGER.md), especially the current endpoint.
4. The complete latest chapter and relevant earlier scenes.
5. [Editorial direction](book1/EDITORIAL_DIRECTION.md), which is provisional planning, not established canon.

Chapters One–Five originated in `maya-project-through-chapter-05/chapters/`; Chapter Six originated in `Nora_Whitcomb_MD_Files_Partial/Pasted markdown.md`. Chapters Seven–Fifteen are the continuation. Chapters One–Twelve previously received a targeted prose pass; its historical scope and counts remain in the [revision report](book1/WRITING_SYSTEM_REVISION.md). The later chronology repair edits Chapters Two–Six without adding an unshown journey night.

The supplied [Nora Story Ledger skill](Nora_Whitcomb_MD_Files_Partial/SKILL.md) governs the overview and ledger. The [writing-system directory](writing-system/README.md) contains all six imported writing-system files, unchanged. Read its prose specification, development state, and anti-patterns for future drafting and revision, subject to the book-specific author preferences. Its voice-development handoff is reference material, not a request to develop new categories. Route Five, Compass, and Zippy remain unavailable.
