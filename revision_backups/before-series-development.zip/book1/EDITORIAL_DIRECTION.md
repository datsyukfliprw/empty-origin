# Editorial direction — provisional, not canon

## Book promise

A nineteen-year-old raid leader arrives in a world where people can inspect her level before learning her name. To survive and investigate a way home, she must learn its progression system, build relationships she chooses, and stop confusing somebody's protection with their right to decide her future.

The voice remains first-person present, profane, observant, funny under pressure, and emotionally tethered to an ordinary family on Earth. Maya's retail and gaming experience are useful skills, not proof that everyone native to the world is stupid. Other people retain expertise, motives, livelihoods, and competence.

## Debut shape

Working center: 105,000 words. Revision range: 95,000–115,000 words. At an illustrative 250–300 words per typeset page, the center is about 350–420 story pages. Layout, trim, font, scene breaks, and front matter will change the actual count. Page count is an estimate, never a drafting quota.

At roughly 52,000 words, Maya has established responsive contact with a man Mara recognizes as Iven, seen Earth-like infrastructure through the arch, and begun a second romantic relationship. The next movement must turn observation into a materially difficult rescue/investigation while preserving the drainage conflict and the limits of Maya's present abilities. Avoid another cycle of orientation, permissions, or conveniently discovered warnings.

No length guarantees bestseller status. Aim for a compelling opening, a clear promise, escalating choices, memorable relationships, and a complete first-book payoff. The Manuscript Academy's agent-informed [2026 word-count guidance](https://manuscriptacademy.com/word-count-by-genre-literary-agents-2026) lists 90,000–110,000 words for romantasy and 90,000–120,000 for fantasy. The 105,000-word center is an editorial choice within those overlapping ranges, not a finding that one length sells best. Publication route is not yet specified.

## Next chapter obligations

- Begin from Maya's question about Iven's needs and the next contact, not another explanation of mirror feasibility. Contact windows have varied without wheel motion; first daylight is an agreed attempt, not a proven timetable.
- Develop the broken stair, rooms, supplies, boarded windows/noises, and workable communication into choices. Distinguish what Maya sees from Iven's account. No safe route, Earth location/date, or elapsed-time conversion is established.
- Respect Mara's strong recognition of Iven and the exchanged family letters. Do not reset his identity to an anonymous sighting or turn his sons into props. Names/ages and exact living arrangements can develop on page.
- Crew due in two days; first work redirected to outer bank/upper carrier. Inner assembly preserved pending rescue/drainage plan; second sluicewright requested. New arrival and rescue approval have not occurred. Pell's drainage obligations continue.
- Upper gallery/sleeve observation authorized voluntarily with Dain/Harra; no lower entry, crossing, or wheel turning. Clamp secures displaced mark, missing tooth remains absent. House owns apparatus. Never equate a restraint with a guaranteed destination or safe crossing.
- Maya: LV. 2, 13/14, 4/4, Warder, Traveler, blank origin. Brace only, now better at deliberate early release/reset, no owned shield. A near level-up should arise from meaningful work and have clear consequences, not a filler exercise.
- Four reading days paid, 38 personal bits, two days left. Original contract protections/copy rights remain; extension or rescue duty requires new voluntary terms. Keep unfinished notebook/labels and unresolved card/chest claim active without redoing completed checks.
- Shoulder/arch soreness and healing knuckles persist; sack and possessions intact. Training and reserve do not erase injury.
- Maya/Sella have kissed, ages nineteen/twenty-one established. Develop consequence and reciprocal interest outside instruction. Sella is paid through crew arrival and considering a later eastward job; no acceptance yet.
- Tolliver twenty-two, both survey wages and escort paid, no further hire. He can afford one more day. His nonexclusive understanding with Maya includes advance discussion if expectations change; do not flatten his emotional response or repeat the initial permission conversation.
- Elena remains missing after historical departure. Her same-mark/different-water observation and uncertain chronology constrain rescue planning but do not explain the whole mechanism. Vey's earlier choices still matter.

## Flexible middle and ending

Maya has chosen to follow the Earth evidence through a limited hire at Rook House. Preserve a credible means to leave, and let what she discovers change the risks of staying. Greyward relationships should continue to matter after her departure.

Develop the chosen Warder run through practical exposure and decisions with costs. Do not award a rare class solely because Maya comes from Earth. Her emerging strengths are attention under pressure, coordination, bargaining, and deliberate use of limited resources. A combat-capable direction can grow from these without turning her instantly into Nyx.

Use gains often enough that the LitRPG promise stays active. Show what changed, how she earned or discovered it, what it costs, and what it cannot do. Alternate training, investigation, dangerous application, and consequences. Avoid serial errands that exist only to increase a counter.

By the middle, the Earth investigation and the institution controlling access to it should create a concrete conflict she can no longer solve by remaining useful and polite. Romance should affect decisions and expose competing wants, rather than occurring in isolated interludes.

The final movement should pay off an earned combination of abilities and trusted allies in a specific conflict over the Earth evidence or access to it. Book One must resolve its central external confrontation and give Maya a durable, chosen position in the world. If marketed as genre romance, deliver an emotionally satisfying happy-for-now or happily-ever-after relationship endpoint; a continuing portal mystery cannot substitute for that payoff. A complete return to Earth is not yet promised or ruled out.

## Romance direction and author insertion points

Keep the genre emphasis on adventure, progression, the Earth mystery, and romance. Treat Maya's attraction to women as an ordinary part of her characterization. The author's requested female relationship should not redirect the novel into a coming-out plot or identity/political instruction. Let attraction emerge through character-specific scenes; identity labels and speeches are not required. Preserve both partners' agency and emotional significance.

The author wants Maya to have a female romantic/sexual partner in this book. Build the attraction through specific interactions, mutual interest, and choices, with emotional consequences after intimacy. Maya's attraction to Tolliver remains part of her story. Her attraction to a woman does not require invalidating that attraction or assigning her an identity label before she expresses one. Give the woman her own aims and a continuing place in the story.

Sella is now an established romantic interest: she explicitly gives her age as twenty-one in Chapter Thirteen and shares first kisses with Maya in Fifteen. Their shared humor and work coexist with Sella's independent eastward ambitions. Develop the relationship's emotional and physical consequences on page; do not reduce her to an instructor or a way to complicate Tolliver.

Maya and Tolliver acknowledged their lack of an exclusivity promise before Maya kissed Sella. They agreed to discuss changes beforehand, while Tolliver admitted needing to adjust his expectations. Sella knows about their arrangement. This establishes the present understanding, not an effortless or final multiple-partner resolution. Preserve each person's agency. Use the same natural fade to black and author insertion convention for all partners.

Maya is nineteen. All sexual partners must be close to her age; the current working range is nineteen to twenty-three, with ages established before intimacy. Tolliver is explicitly twenty-two in Chapter Seven. His suitability as a final partner remains a story question: attraction does not settle his accountability for withholding information or profiting from her vulnerability.

Eiran Hale (thirties) and Master Vey (approximately forty by Maya's estimate) are excluded as sexual partners. Do not introduce a centuries-old character who merely appears young as a workaround. Any new romantic lead must actually fit the close-age constraint.

Write adult attraction, mutual interest, vulnerability, kisses, and emotionally consequential romantic scenes. When a freely chosen encounter moves into sex, use a natural fade to black and leave the explicit passage for the author. Resume with the changed relationship, emotional aftermath, and any relevant continuity. Do not jump to intimacy to meet a heat quota or use rescue, lodging, training, debt, or a contract as payment for it.

At a real insertion point, an unobtrusive Markdown comment may mark the location: `<!-- AUTHOR INSERT: intimate scene. Continue from the established choice; preserve ages, consent, location, injuries, and the following aftermath. -->`. Keep such markers out of scenes that do not reach that point. Chapters Seven–Fifteen contain tension, boundaries, accountability, hand-holding, and first kisses, but no sexual encounter or explicit-scene placeholder.

## Craft checks

- Keep the ratio of action, dialogue, reflection, and description responsive to the scene. Avoid copying the opening's rhetorical habits mechanically: repeated 'That is the thing,' numbered observations, and aphoristic paragraph endings lose force when used everywhere.
- Let conversations change information and choices. Tolliver cannot remain an endless dispenser of partial answers without a cost to his relationship with Maya.
- Preserve uncertainty. Maya's interpretation, a character's account, a System display, and independently corroborated facts are different kinds of evidence.
- Full name: Maya Szczepaniak; source pronunciation: Sheh-PAN-yak. Nyx is her Earth avatar/handle, not her current body or an automatically unlocked identity.
