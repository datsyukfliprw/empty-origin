# Maya — active novel project

Continue from **[book1/WORKING_DRAFT.md](book1/WORKING_DRAFT.md)**, currently through Chapter Twelve. Individual chapters are in [book1/chapters](book1/chapters).

The two supplied export directories and their ZIPs are preserved as source snapshots. Their old 200,000-word target is superseded by the author's instructions and the active [project notes](book1/PROJECT_NOTES.md).

Read these before continuing:

1. [Project notes and binding author preferences](book1/PROJECT_NOTES.md), including how to apply the supplied writing system.
2. [Cumulative story overview](book1/STORY_OVERVIEW.md).
3. [Chapter ledger](book1/CHAPTER_LEDGER.md), especially the current endpoint.
4. The complete latest chapter and relevant earlier scenes.
5. [Editorial direction](book1/EDITORIAL_DIRECTION.md), which is provisional planning, not established canon.

Chapters One–Five originated in `maya-project-through-chapter-05/chapters/`; Chapter Six originated in `Nora_Whitcomb_MD_Files_Partial/Pasted markdown.md`. Chapters Seven–Twelve are the continuation. All twelve active chapters have now received a targeted prose pass using the supplied writing system. See the [revision report](book1/WRITING_SYSTEM_REVISION.md) for scope, counts, and the pre-pass backup.

The supplied [Nora Story Ledger skill](Nora_Whitcomb_MD_Files_Partial/SKILL.md) governs the overview and ledger. The new [writing-system directory](writing-system/README.md) contains all six files from `nora-whitcomb-writing-system.zip`, unchanged. Read its prose specification, development state, and anti-patterns for future drafting and revision, subject to the book-specific author preferences. Its voice-development handoff is reference material, not a request to start developing new categories. Route Five, Compass, and Zippy remain unavailable.
