# Book One — completion plan

## Status and controlling direction

This plans the unwritten second half. It does not report completed chapters. The manuscript currently ends at Fifteen, after Maya's fourth reading day. The author wants a longer ongoing series in which Maya **never returns to Earth**. See the [series bible](../SERIES_BIBLE.md).

Keep the flexible 95,000–115,000-word range, centered near 105,000. The revised fifteen chapters contain about 51,000 words. There is room for approximately fourteen or fifteen further chapters of varying length, not a requirement to write every beat as a separate chapter. Combine scenes that repeat a result. Give the rescue, reunion, intimacy aftermath, and ending the space they earn.

## The complete story this volume owes the reader

Maya begins unable to support herself, dependent on someone who withholds information. She ends as a useful novice Warder with her own equipment, chosen allies, paid work she can refuse, and a future here that she actively wants.

The external question is: **Can Maya and her allies bring Iven back without sacrificing the people living beside the broken sluice or handing the route to someone who will exploit it?** Answer yes through a difficult, costly, technically legible rescue. Do not move Iven's rescue to Book Two.

The personal question is whether she can choose obligations without giving someone ownership of her. She must make a choice with a cost to herself. Saying no to another unfavorable contract is no longer enough to complete her arc.

The emotional ending must include Iven's reunion, a meaningful romantic commitment, and a concrete step into Maya's new life. Save space after the confrontation. A map or threat is an invitation to the sequel, not the final substitute for those scenes.

## The opposition

Introduce one sustained human opponent at the start of the next movement: the incoming salvage crew's captain, who has a paid claim to recover the inner assembly and seeks exclusive control of a newly valuable route. Name and characterize this person on introduction. The captain should have a workable proposal, useful equipment, a finite crew, and a financial or professional reason to resist Maya's independent rescue.

Seed the claim in a dispatch before the crew arrives on local Day 12. Pell can suspend local cutting but cannot casually conjure a replacement crew or the claimant's specialized rigging. The captain's opening offer is to help retrieve Iven in exchange for custody and exclusive access. The risk is visible before Maya agrees to anything. After losing the argument, the captain acts through a concrete attempt to take control, not another meeting that ends with everyone reasonably agreeing.

Do not retrofit this opponent into the cause of every earlier accident. The first bypass failure and the old retaining tooth already have causes. No secret mastermind needs to have arranged Maya's collapse, Tolliver's encounter, and Elena's departure.

Pell remains responsible for drainage and the people relying on it. Dain remains the technical authority on the works, not all aspects of transit. Vey must take a position on the proposed concession openly. He can help at a cost later, but another extracted admission cannot stand in for that choice.

## Sequence for the remaining chapters

Numbering is a drafting aid. The cause-and-effect chain matters more than the count.

| Chapter | Objective, obstruction, and Maya's decision | Result and obligation carried forward |
|---|---|---|
| 16 | On reading day five, ask Iven what he needs. He contributes a practical idea for reaching the broken stair, based on materials he has actually found. Maya helps test a small delivery/measurement rig from permitted access. An inadequate support forces her to release and reset instead of pulling harder. | Earn the imminent level-up through successful application under a real constraint. Record its exact consequences without a refill. Recover enough geometry to make a rescue design possible. A dispatch introduces the salvage claim. No automatic permission to enter below. |
| 17 | On Day 12, finish the sixth paid reading day and account for the remaining labels. The crew arrives as scheduled. Its captain offers the missing equipment in exchange for access and recovered materials. Maya identifies what the offer would cost Iven and any other arrivals. | First direct confrontation with the continuing opponent. A replacement rescue arrangement is negotiated once, using a concrete plan. The reading hire ends paid: 54 personal bits before any new purchases or spending. New duties and funding must be established on page. |
| 18 | Maya needs equipment and a technique that lets her move under pressure. She purchases or explicitly borrows a correctly fitted shield, using a named price or recorded loan. Sella teaches a moving hold after assessing the shoulder. An early attempt fails in a controlled drill. | The new ability has a clear limit and a reason to practice. Tolliver's lodging/work and Sella's eastbound offer require present decisions; neither stays free indefinitely. A candidate drainage route emerges from the actual survey, not another miracle English warning. |
| 19 | Test the ordinary drainage alternative in a field operation. The team meets difficult terrain and an established local creature threat; Maya has a specific job she can do. Her plan succeeds in one respect and exposes a weakness in another. | First satisfying field victory since the road attack, with a useful reward and a lasting cost. Show the damaged fields' human stakes through somebody affected. The drainage fix becomes feasible but requires labor or equipment the captain controls. |
| 20 | During a bounded observation window, Iven and the team test the route at both ends with tools before people. Maya helps distinguish imported fittings from the structure holding them. Evidence establishes a receiving station within this world. | Pay off the English-door question honestly. Maya grieves the loss of this apparent way home; the rescue retains its purpose. Demonstrate a rule for the changing interval that can later be used, with measured limits rather than certainty by assertion. |
| 21 | With the night's immediate work finished, Maya and Sella have time they choose for themselves. Sella presses for an answer about a shared future or job that Maya has avoided because she expects to leave. Maya gives an honest, limited answer she can act on. | If the relationship has earned it, the first intimate encounter reaches a natural fade and author insertion point, then an actual aftermath. Both retain their plans and agency. Do not interrupt it with an arbitrary alarm to avoid completing the scene. |
| 22 | A first limited entry becomes possible only after an access decision, physical safeguards, and an abort condition established in prior scenes. Maya participates for a specific reason, alongside more capable people. The prepared route fails at its known weak point. | Get everyone out without rescuing Iven yet; lose a tool, material, or opportunity that cannot be reset overnight. Maya learns why the shortened rope matters. Avoid adding a gratuitous casualty solely to prove danger. |
| 23 | The captain exploits that failure to press the exclusive plan and offers Tolliver profitable work or information money. Vey must say which arrangement he supports. Maya is tempted to hide a discouraging observation from the team to keep the rescue alive. | Her own controlling impulse costs trust before she corrects it. Tolliver's response has an observable price. The antagonist takes a defined action—seizes necessary rigging or begins a contested removal—rather than merely threatening vaguely. |
| 24 | Recover access or needed equipment through a plan using the settlement, local routes, and skills already shown. Maya contributes tactical direction; Sella, Tolliver, Harra, and others retain indispensable jobs and the right to reject her proposal. | A decisive nonfinal win changes the power balance. Maya masters the limited moving hold through application, not a surprise rare-class notification. Drainage and rescue now have an executable shared plan. |
| 25 | Prepare the final operation with the resources actually obtained. Iven solves a far-side problem instead of waiting to be carried. His sons have their own wishes and boundaries. Maya and her romantic partner or partners settle what they are choosing together. | Make the final division of labor, costs, timing, and abort point clear in one scene. The team knows enough to act; no final hidden warning can replace earned judgment. Let anticipation and some pleasure coexist. |
| 26 | Execute the first stage: relieve the ordinary water load and reach the retrieval position. The captain makes the previously established attempt to take control. Maya must keep her assignment while more powerful allies are occupied with different indispensable work. | A cost she accepted now becomes real. The plan survives because it distributes work. Maintain reserve, injury, equipment, and position continuity through the action. |
| 27 | Retrieve Iven during the demonstrated interval. The changing boundary makes holding harder the wrong answer. Maya releases Brace deliberately, moves under the trained hold, and coordinates the next support while Iven and the crew act. | Iven reaches this side alive. The captain's immediate bid fails conclusively. Maya gives up valuable recovery or access to save a person; she cannot buy a second attempt with a surprise refill. She does not visit Earth. |
| 28 | Treat injuries, settle the immediate works state, and reunite Iven with Mara and his sons. Show one remembered family detail that has changed while he was absent. | The rescue receives its emotional reward. Establish the drainage remedy operating, its cost, and who will maintain it. If a larger reconstruction remains, its interim protection must actually work. |
| 29 | Resolve wages, custody, the card classification, and the captain's disposition in the shortest scenes that carry real consequences. Maya and the relevant romantic partners follow through on their commitment privately. | Show a paid or earned material gain, useful progression, owned possessions, and reciprocal attachment. Elena's property stays hers; Maya is not entitled to it for being another arrival. She obtains lawful copies or an authorized lead, not effortless ownership of the whole collection. |
| 30 | Maya buys or secures something for a life that extends beyond her next bed: a place to leave belongings, a training arrangement, or a share in an expedition with a known destination. She accepts a specific regional undertaking with willing companions. | End on chosen forward movement. The recovered record gives a route relevant to the next job and Elena; the mission's purpose is local. Maya can miss her parents while packing for a journey she wants. No final paragraph promising that the next gate might take her home. |

## Keep the calendar and money honest

The current endpoint is local Day 10. Two reading days remain. Day 11 is the fifth; Day 12 is the sixth and the scheduled crew arrival. Sella's possible escort begins five days after Day 10, therefore Day 15; her guard work is currently secured only through crew arrival. Resolve that offer by its date or explicitly show a changed agreement.

Tolliver said on the evening of Day 9 that he could afford to stay **tomorrow**, Day 10. That day is already over at the current endpoint. His next paid work, departure, or personally affordable stay needs establishing; the statement does not grant a fresh day each time the ledger is read.

Maya currently has 38 bits. The next two full reading days would bring that to 46 and 54 before new spending. The plan must subtract equipment and other purchases when they occur. Meals, bed, and the return cart to Greyward remain covered under the existing agreement and are entirely separate from returning to Earth.

No new duty can be smuggled into the reading contract. Settle the rescue arrangement once after a plan exists, then let its consequences appear through action. Summarize routine payments and unchanged conditions. Explain them at length only when they alter a choice.

## Progression design before drafting Sixteen

1. Decide the next capacity and threshold consistently with the existing 3→4 capacity change and 10→14 progress threshold. Record the new display only in the chapter that earns it. An increased maximum does not fill spent reserve.
2. Define the proposed moving hold separately from Brace. It should permit a brief controlled step while maintaining protection along a chosen line; changing direction, losing a support, or exceeding the duration breaks it. It cannot hold a portal open. Set the cost before the first use and keep it.
3. Show instruction, imperfect practice, an intelligible failure, and later success. No missing training montage immediately before the climax.
4. Work toward a capable novice, provisionally level five or six by the finish if the actual events earn it. At least one advancement should arrive early enough for Maya and the reader to enjoy using it before the finale.
5. Keep stronger companions strong. Maya becomes essential through assigned work and coordination, not because every professional suddenly forgets how to rescue somebody.

## Structural risks still to solve

The first fifteen chapters contain only one level-up and one acquired ability. The second half must deliver more frequent meaningful progression. It must also contain sustained opposition and several fully dramatized adventure sequences. Trimming words alone cannot supply either.

The first major Earth-object hook arrives in Chapter Eight, and much of the first act concerns dependence and work. Preserve the excellent market arc, but test the opening sequence with readers after the full book exists. If readers repeatedly stop in Chapters Three–Five, combine or compress a journey scene before inventing another prologue or portent. Keep an intentional early slow burn only if readers experience tension rather than delay.

The final relationship structure remains a creative decision. Finish a coherent emotional arc before choosing retail categories, a romantic tagline, or cover cues that promise exclusivity or a particular configuration.

The private mystery solution requires a simple physical layout and timing model before the rescue chapters are written. Make a working diagram for the writer, then reveal only what Maya needs to act. A complex mechanism explained after the climax would not make the climax fair.
