# Editorial direction — provisional, not canon

## Book promise

A nineteen-year-old raid leader arrives in a world where people can inspect her level before learning her name. To survive and investigate a way home, she must learn its progression system, build relationships she chooses, and stop confusing somebody's protection with their right to decide her future.

The voice remains first-person present, profane, observant, funny under pressure, and emotionally tethered to an ordinary family on Earth. Maya's retail and gaming experience are useful skills, not proof that everyone native to the world is stupid. Other people retain expertise, motives, livelihoods, and competence.

## Debut shape

Working center: 105,000 words. Revision range: 95,000–115,000 words. At an illustrative 250–300 words per typeset page, the center is about 350–420 story pages. Layout, trim, font, scene breaks, and front matter will change the actual count. Page count is an estimate, never a drafting quota.

At roughly 42,000 words, Maya has reached Rook, verified records, completed a first paid reading day, and helped expose a live waterworks hazard. The next movement should turn the proposed observation into a concrete investigative choice, deepen her Warder competence, and make the removal deadline and growing relationship matter together. Avoid prolonged institutional orientation or a succession of emergencies solved only by reading another conveniently placed warning.

No length guarantees bestseller status. Aim for a compelling opening, a clear promise, escalating choices, memorable relationships, and a complete first-book payoff. The Manuscript Academy's agent-informed [2026 word-count guidance](https://manuscriptacademy.com/word-count-by-genre-literary-agents-2026) lists 90,000–110,000 words for romantasy and 90,000–120,000 for fantasy. The 105,000-word center is an editorial choice within those overlapping ranges, not a finding that one length sells best. Publication route is not yet specified.

## Next chapter obligations

- Follow Maya's plan to ask Dain about safe observation. Establish physical layout and constraints clearly enough for a later attempt to be understandable. Elena's mirror question is a proposal, not a ready-made solution. Maya has no obligation under the reading contract to enter closed works or operate mechanisms.
- Keep the removal conflict concrete: crew due five days after first reading day, cutting conditional on Dain's clearance, bypass test suspended, lower path/pump barred. Pell has a credible drainage responsibility. Do not require her or Dain to become incompetent to create danger.
- Make the notebook yield further substantive information without making Maya an engineer by translation alone. Distinguish observations, experiments, historical statements, and deductions. Original notebook has 36 written pages; full translation and label work remain unfinished.
- Iven Orrel has two sons and a sister, Mara; uncertain hope has consequences for them. Neither the six-word note nor the lights proves survival or Earth access. Elena's whereabouts and destination after west-gate departure remain unknown.
- Card now in Mara's recorded custody. Maya's personal-identification finding is submitted to Pell, not decided. Retained chest/materials remain under unresolved ownership claim. Vey's intentional recruitment omissions are established and should affect how Maya works with him.
- Maya: LV. 2, 8/14, reserve 4/4, Warder, Traveler, blank origin. Brace only; no shield. Sella taught that skin/materials can fail despite a hold. Advance competence through practice and cost; avoid instant new abilities or unexplained equipment.
- Money: one piece plus six bits. First of six reading days completed and paid; five remain. Contract copy verified, entry/departure/closure records inspected. Food, bed, return wait/passage and copy rights persist. Never re-stage fulfilled requirements as outstanding tasks.
- Knuckles closing, shoulder sore; older injuries not silently erased. Sack repaired. Existing possessions and copies retained. No reserve spent in the last two chapters.
- Begin developing Maya's attraction to a woman through specific, reciprocal interactions. Sella is a provisional candidate, not yet a romantic partner in canon; preserve the investigation's momentum and each woman's independent aims.
- Tolliver and Maya have shared their first kisses and then separated for the night. Attraction does not erase accountability. He accepts her desire to seek home while disliking the possibility of losing her. Build on that specific emotional tension rather than repeating the original consent conversation.
- Tolliver's escort wage paid, finding fee inapplicable. Two survey days hired at unspecified rate, not yet shown paid; first is tomorrow, on outer banks, with intended evening return. Sella guards the closure. Keep their independent work visible.

## Flexible middle and ending

Maya has chosen to follow the Earth evidence through a limited hire at Rook House. Preserve a credible means to leave, and let what she discovers change the risks of staying. Greyward relationships should continue to matter after her departure.

Develop the chosen Warder run through practical exposure and decisions with costs. Do not award a rare class solely because Maya comes from Earth. Her emerging strengths are attention under pressure, coordination, bargaining, and deliberate use of limited resources. A combat-capable direction can grow from these without turning her instantly into Nyx.

Use gains often enough that the LitRPG promise stays active. Show what changed, how she earned or discovered it, what it costs, and what it cannot do. Alternate training, investigation, dangerous application, and consequences. Avoid serial errands that exist only to increase a counter.

By the middle, the Earth investigation and the institution controlling access to it should create a concrete conflict she can no longer solve by remaining useful and polite. Romance should affect decisions and expose competing wants, rather than occurring in isolated interludes.

The final movement should pay off an earned combination of abilities and trusted allies in a specific conflict over the Earth evidence or access to it. Book One must resolve its central external confrontation and give Maya a durable, chosen position in the world. If marketed as genre romance, deliver an emotionally satisfying happy-for-now or happily-ever-after relationship endpoint; a continuing portal mystery cannot substitute for that payoff. A complete return to Earth is not yet promised or ruled out.

## Romance direction and author insertion points

Keep the genre emphasis on adventure, progression, the Earth mystery, and romance. Treat Maya's attraction to women as an ordinary part of her characterization. The author's requested female relationship should not redirect the novel into a coming-out plot or identity/political instruction. Let attraction emerge through character-specific scenes; identity labels and speeches are not required. Preserve both partners' agency and emotional significance.

The author wants Maya to have a female romantic/sexual partner in this book. Build the attraction through specific interactions, mutual interest, and choices, with emotional consequences after intimacy. Maya's attraction to Tolliver remains part of her story. Her attraction to a woman does not require invalidating that attraction or assigning her an identity label before she expresses one. Give the woman her own aims and a continuing place in the story.

Sella is a plausible existing candidate: shared humor, practical trust, and work at Rook give them opportunities to develop beyond instruction. This is a provisional possibility, not established attraction or a selected partner. Her stated work history suggests approximately twenty-one; establish her exact age before intimacy if this direction is chosen. Develop reciprocal interest outside lessons as well as within their shared work. A new woman within the nineteen-to-twenty-three range remains an option if the story supports her better.

Begin laying this thread into the upcoming Rook chapters without forcing an immediate encounter. Maya and Tolliver have kissed but have made no exclusivity agreement. Let the people involved articulate expectations as relationships develop; neither exclusivity nor a multiple-partner arrangement is predetermined. Preserve the woman's importance regardless of the eventual romantic endpoint. Use the same natural fade to black and author insertion convention for all partners.

Maya is nineteen. All sexual partners must be close to her age; the current working range is nineteen to twenty-three, with ages established before intimacy. Tolliver is explicitly twenty-two in Chapter Seven. His suitability as a final partner remains a story question: attraction does not settle his accountability for withholding information or profiting from her vulnerability.

Eiran Hale (thirties) and Master Vey (approximately forty by Maya's estimate) are excluded as sexual partners. Do not introduce a centuries-old character who merely appears young as a workaround. Any new romantic lead must actually fit the close-age constraint.

Write adult attraction, mutual interest, vulnerability, kisses, and emotionally consequential romantic scenes. When a freely chosen encounter moves into sex, use a natural fade to black and leave the explicit passage for the author. Resume with the changed relationship, emotional aftermath, and any relevant continuity. Do not jump to intimacy to meet a heat quota or use rescue, lodging, training, debt, or a contract as payment for it.

At a real insertion point, an unobtrusive Markdown comment may mark the location: `<!-- AUTHOR INSERT: intimate scene. Continue from the established choice; preserve ages, consent, location, injuries, and the following aftermath. -->`. Keep such markers out of scenes that do not reach that point. Chapters Seven–Twelve contain tension, boundaries, accountability, hand-holding, and first kisses, but no sexual encounter or explicit-scene placeholder.

## Craft checks

- Keep the ratio of action, dialogue, reflection, and description responsive to the scene. Avoid copying the opening's rhetorical habits mechanically: repeated 'That is the thing,' numbered observations, and aphoristic paragraph endings lose force when used everywhere.
- Let conversations change information and choices. Tolliver cannot remain an endless dispenser of partial answers without a cost to his relationship with Maya.
- Preserve uncertainty. Maya's interpretation, a character's account, a System display, and independently corroborated facts are different kinds of evidence.
- Full name: Maya Szczepaniak; source pronunciation: Sheh-PAN-yak. Nyx is her Earth avatar/handle, not her current body or an automatically unlocked identity.
