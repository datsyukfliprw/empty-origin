CHAPTER TWELVE

Mara asks me to read it again.

I do.

She draws the scrap closer with one finger. Her nail has a split near the edge. I watch it catch on the paper because looking at her face feels like something I should ask permission to do.

“When did she write that?” I ask.

“The morning she signed the statement. She handed it to me afterward.”

“What did she tell you it said?”

“Nothing. I thought she had written his name.”

There are six words. Even if you can't read them, there are six distinct pieces of writing.

Mara sees me look.

“I wasn't examining it very closely.”

“I'm sorry.”

She shakes her head once. “So am I.”

Vey stands by the window with his hands behind his back. For once he has nothing to contribute.

I turn the scrap without lifting it. Blank on the other side.

“It doesn't say when the pulling stopped. Or why. I don't know if—”

“I know what you don't know.”

The words come sharply. She shuts her eyes.

“I know,” she says again, quieter.

We sit until a clerk arrives with paper. Mara takes it from him, sets out a ruler and a little pot of ink, and shows me how to keep my copying sheet from sliding. The ordinary instructions make it possible to start.

I copy the records, including the crossed-out sentence and the six English words. Mara watches me reproduce Elena's signature as a labeled copy rather than as my own attempt at signing it. When my hand cramps, she tells me to stop. I am finished anyway.

At the door she says, “He had two sons.”

I turn back.

“Iven. One was small enough that we had to explain more than once.”

“I'll be careful what I say.”

“Yes,” she says. “Please.”

---

My room is above the west kitchen. It has a narrow bed, a peg, and a shutter opening onto a roof where someone has planted herbs in broken pots. The door bolts. I test it twice, then put my copies beneath the folded Earth shirt in my sack.

Supper is downstairs with people who have opinions about flour deliveries. Nobody asks whether Iven is alive. Nobody knows that I have spent half the afternoon considering a length of rope with a person at the other end.

Tolliver is at the far end of the table. He moves a jug so I can set my bowl down, but doesn't turn the empty place beside him into an invitation I have to refuse. I sit there because I want to.

“Paid?” I ask.

He taps his purse. “Two pieces. Sella too.”

“Are you going back?”

“Eventually. Dain wants someone to walk the lower channel with him the day after tomorrow. Tracks, bank damage, animal holes. I've taken two days, paid by the day. After that I haven't decided.”

“You don't have to stay because I'm here.”

“I know.” He tears his bread. “I like knowing where you are. I also need wages. Both can be true.”

I stir my bowl. It contains beans, onion, and something that was probably a bone's most successful ambition.

“I don't know what I want you to do.”

“You don't have to hire me.”

It is funny enough that I smile. He sees it and smiles too, briefly, before someone asks him to pass the jug.

After supper I mend the tooth holes with a needle borrowed from the kitchen. The stitches are uneven and much too close together. They hold. For tonight that is a reasonable standard.

I sleep with the repaired sack under the bed instead of beneath my head.

---

The notebook arrives in a shallow wooden tray.

Mara puts it on the records-room table the next morning, then sets a separate dish beside it containing a pen cap, a rusted metal clip, and two tags tied to lengths of cord. Vey places Elena's card in the dish and Mara records its return in front of me.

I want to take it. Put it with my shirt. Have one more object on my side of the room that comes from a world with traffic lights.

I keep my hands on the table.

The notebook is local paper stitched into a soft leather cover. Some pages have warped where they were wet. A corner near the front is missing, neatly cut rather than torn. Mara says it was like that when she received it. She counted thirty-six written pages, leaving blanks out of the tally.

“Today begins the six?” she asks.

“Yes.”

She writes the date. I have already seen the records. I have slept on the decision. There is no one left to blame for this part being mine.

I open the cover.

The first page contains a list of measurements, a rough conversion between local units and meters, and an English sentence boxed in the margin.

*Do not trust the old map's north.*

“Oh, good,” I say. “She's been here.”

Mara's mouth moves.

“She said that often. Usually with worse words.”

The next pages are drainage notes. Culvert widths. A badly drawn beetle beside a calculation. A list of people owed meals for holding the end of a measuring line. Elena's handwriting grows small when she is thinking and large when she is angry. At least that is how it looks to me. I don't know her. I need to keep remembering that.

Some technical words slow me down. Reading English does not make me an engineer. I write *head* on my paper and explain to Mara that here it seems to mean something about water height or pressure, not a body part. She fetches Dain before I turn an uncertain definition into a confident mistake.

He arrives with a wooden cup and a limp that takes a moment to settle after he sits. **[SLUICEWRIGHT, LV. 24]**. His beard is short and almost entirely white. Two fingers on his left hand end at the first joint.

“That Elena's?”

“Yes,” Mara says.

He sets down the cup with unnecessary care.

I show him the sketch. He traces the lines with a clean sliver of wood, keeping his hands off the page.

“Water stacked above you,” he says. “More stack, more shove. What's she arguing about?”

“Whether the water on this side can get high enough to do what she saw.”

He studies the numbers.

“It couldn't. I told her that.”

“She wrote it down.”

I point to his name in local script, followed by an English note.

*Dain checked twice. Stop asking him the same question.*

He makes a small sound through his nose.

For the next hour he helps us separate things Elena measured from things she guessed. I read each page aloud in pieces, and Mara writes the local version. I keep my own notes and check the copies against each other. It is slow work. It is also work I can do, which steadies me more than I expect.

There is no welcome message for the next person from Earth. No explanation of how to get here or how to leave. Elena has recorded wages in the back, crossed out a shopping list, and spent nearly half a page trying to describe coffee to someone who recommended burnt barley.

I run a finger along the edge of that page.

My first closing shift, I spilled a pitcher of steamed milk down my apron and had to stand in the walk-in because I couldn't stop crying. The manager thought I'd burned myself. I let her think it because explaining that I was tired and eighteen and couldn't do a single fucking thing correctly seemed more embarrassing.

Elena wanted coffee badly enough to make notes about it.

I can tell Mara the words for that. I cannot give her what they mean to me.

Near the middle we find the original of the tracing.

The lines are darker here. One of the apparent circles is a wheel seen from above. The other is a ring around an opening drawn in section. Beside it Elena has made three observations on three different dates.

Cold water, mineral smell.

Warm water, fine pale grit.

Air moving inward when the lower pool is still.

Underneath:

*Changing the setting changes the source. It does not tell us where that source is.*

I read the sentence twice before translating it aloud.

Dain leans forward.

“She did tell me the first part. Thought she meant an old feeder we'd never found.”

“Did you see the grit?”

“Yes. Cleaned it out myself. Twice.”

“Was it different from what's in your river?”

“Different from what comes down here. That doesn't tell you how far it traveled.”

I nod. He has seen what is written on my face and is being careful with it.

Lower on the same page is the rope warning. Beneath the main diagram, a smaller sketch shows something I took for a handle in the tracing: a metal tongue sitting in a notch.

Dain recognizes it immediately.

“The retaining tooth.”

“The one that broke?”

He nods.

There are two sets of writing beside it. Local dimensions in a tidy hand that may be Mara's. An English annotation crammed between them and the binding.

*Secondary inlet still under load with first gate shut. Closing upstream does not isolate. Lock inner wheel before bypass test.*

Dain holds the sliver of wood motionless above the page.

“Read that again.”

I do, more slowly. Then I explain isolate as best I can. Stop something from still getting into the place you're working.

He gets up.

“Where are you going?” Vey asks.

“To stop the test.”

---

Outside, the mill makes enough noise that I have to hurry to hear him.

“What test?”

“Bypass draw. Tomorrow we have the lower bank survey. Today they check how far the surface channel can take the head down.”

“You said the sluice was closed.”

“The sluice is closed. Nobody's supposed to touch the inner wheel.”

He takes the corner beside a stack of tiles faster than his limp ought to allow. I slow to keep from slipping in the mud.

“Is somebody touching it?”

“No. But its tooth is in a cupboard, and everyone thinks shutting the river gate took the weight off it.”

The watercourse leads us past the mill to an open gravel yard. Sella stands by a rope stretched between two posts, redirecting a boy with a basket. Beyond her, two workers are hauling on a long lever. Water foams from an opening in the side of the raised channel and races toward a ditch.

It looks purposeful and expensive. I would have assumed it was fine.

Dain puts his fingers in his mouth and whistles.

Both workers turn. One lets go of the lever; the other keeps it where it is.

“Hold there,” Dain calls. “Don't move it back yet.”

He walks to a narrow sight box set into the stone. A little iron rod protrudes from the top, marked with pale lines. It shakes hard enough to make a ticking sound.

I stop beside Sella. The rope is waist-high. Beyond it a stair leads down to an iron-covered opening in the bank. I can see a lock. Nobody is standing on the stairs.

“Problem?” she asks.

“Maybe.”

Dain crouches at the sight box. He says something to the worker holding the lever. The worker answers. The ticking speeds up.

I cannot read a water gauge. I cannot fix a sluice. I can feel Brace waiting under the thought of my run, absurdly available, as though the world has presented a familiar button beside a problem it will not solve.

Dain looks over his shoulder.

“Sella, clear the towpath below the outlet. Everybody up to the yard. Walk them. No running.”

She is moving before he's finished. She hands me the end of the rope as she unhooks it from the nearest post.

“Across the path behind me. Let the workers come up. Don't let anyone down.”

I take it in my good hand.

There are five people below, two of them carrying a long rake between them. Sella calls them by their work rather than their names. They know she means them. She gets the pair turned first so they don't swing the rake into anyone else.

A woman approaches from the yard with a bucket.

“Not that way,” I tell her.

“I use the lower pump.”

“They're clearing it.”

She looks over my head at my plate.

For one exhausting second I prepare to argue about level two.

Then Dain calls, “Pump as well, Tessa,” and she turns around.

Fine. I will take having an organization behind me for once.

The ticking becomes a rattle. A worker comes up the path too quickly, sees the rope, and hesitates.

I lower it all the way to the ground. He steps across. The next person follows. I count them because counting is available. Three. Four. The last man has stopped for the rake.

“Leave it,” Sella tells him.

He leaves it.

“All up,” she calls.

Dain raises his hand. The worker on the lever eases it back while the other man puts his weight on a second bar. The water leaving the side opening narrows, then surges once before shrinking to a dirty ribbon.

Under the gravel, something knocks.

It is one deep impact. I feel it in my boots.

Everyone stops speaking.

The iron rod gives three more little tremors and settles.

Dain stays where he is for a long time, watching it. Nobody congratulates anybody. One of the workers wipes his mouth with the back of his hand.

Eventually Dain stands.

“Posts stay. No one uses the lower path until I say.”

“What was that?” I ask.

“A gate taking weight.”

“Which gate?”

“That's what I'm going to establish before anyone puts a hand near it.”

Sella takes the rope back from me and knots it to the post. My hand has gone stiff from holding it, although I haven't pulled against anything at all.

“You spent?” she asks.

“No.”

“Good.”

It is the first time anybody has sounded pleased that I didn't use my magic.

---

The argument happens in the yard because Dain refuses to go far enough away that someone might mistake his departure for permission.

A woman in a green coat arrives carrying a rolled plan. Her plate reads **[STEWARD, LV. 27]**. Vey introduces her as Steward Anja Pell, then gives her the shortest version of the discovery he can manage.

She asks Dain whether the test caused damage.

“I won't know until the indicators stay quiet and we check the outer fittings.”

“Was anybody below the closure?”

“No.”

“Then keep it that way. The test is suspended.”

I had been assembling a speech. It has nowhere to go. I stand with my mouth slightly open while she asks who needs to be told about the lower pump.

Only after those instructions are settled does she look at me.

“You read the warning?”

“Yes.”

“Can you show me precisely what it says?”

“It's in the records room.”

“Mara can bring the copy.” She turns to Vey. “You said six days.”

“For the whole notebook. We can prioritize the works pages.”

“What happens in six days?” I ask.

Pell unrolls her plan on a crate. One corner has been patched with a different color of paper. The lines show the mill channel, the bypass, and three fields beyond the low wall.

“In five, a crew arrives to remove the inner wheel and its spindle. We need the lower chamber safe before they cut out the assembly. The bypass is meant to carry drainage permanently.”

“You're taking it apart.”

“It has been shut for four years. We still have fields under water twice a season and a works budget paying men to inspect a lock.”

“It may go somewhere.”

“So does every culvert on this land.”

“That's not what I mean.”

“No,” she says. “I understand what you mean. Vey has explained what you recognized.”

The mill wheel groans behind us. I hate hearing that he has explained me to another person even when this time it's probably part of the job I agreed to.

“What if taking it apart opens it?” I ask.

“Then you and Dain have just given me a reason to change how we remove it.”

“Or not remove it.”

“That will require more than a possibility.”

I look down at the map. The flooded fields have names. Someone has drawn small marks for houses along their edges. Whatever this mechanism might mean to me, other people have been trying to grow dinner beside it.

Dain puts his cup on the corner of the plan. Somehow he brought it all the way from the records room.

“No cutting until I understand what took that load,” he says.

Pell considers him.

“Agreed. But tell me what you need to understand it. Don't hand me another four years.”

Mara arrives with the copied page. Pell reads it, asks me about three words, then has Mara add the suspension to the works instructions in writing. The removal crew is still due in five days. Cutting now depends on Dain's clearance.

The distinction is small enough to fit into two lines and large enough to make me want to sit down.

Before Pell leaves, I ask whether Elena knew they might remove it.

“The present order is mine. Elena left before I became steward.”

“So you're not the person who kept her chest.”

“No. I'm the person with the unresolved claim in my accounts.”

“It's her identification in there.”

“Then submit that finding with the item number. I can review it.”

She rolls the plan up and goes to speak to the miller. I watch her leave, wishing she had either laughed at me or handed me everything. Having to persuade her sounds like a lot of work.

---

By evening, I have a headache behind one eye and a list of words I will never again assume I understand merely because they're English.

Dain returns to say the visible fittings are intact. The inner wheel's indicator has moved a fraction from the mark recorded before the draw. The lock on the access cover remains untouched. He has witnesses for all three observations and refuses to tell me what they prove beyond movement under a change of water level.

I like him more every time he disappoints me accurately.

We finish copies of the warning and its adjoining pages. Mara records which uncertainties need Dain and which need me. I ask for the card's item number and write a short statement identifying it as a personal driving credential, including why the photograph, dates, and address matter. Mara accepts it for Pell's review. Nothing is released today.

At the pay desk, a clerk gives me one piece.

It is heavier than a bit and still ridiculously small for how much I have thought about it. I put it with my six bits. Fourteen bits if I need to make change. Five reading days left.

My measure, when I check in my room, has changed too.

**[MAYA SZCZEPANIAK, LV. 2]**

**[PROGRESS: 8 / 14]**

**[RESERVE: 4 / 4]**

**[RUN: WARDER]**

I don't know when the two progress arrived. The practice at the wall, the work, the yard. Maybe some combination. There is no helpful receipt listing approved activities.

I write the numbers on my copy paper, with the date Mara taught me. My knuckles are closing. My shoulder hurts when I reach too high. Leveling has not filed a repair request on my behalf.

After supper I find Tolliver on the outside stair, replacing the binding on an arrow. There is room beside him, and I sit.

“I heard about the test,” he says.

“I held a rope with absolutely nothing pulling on it.”

“An advanced road skill.”

“Apparently.”

He turns the arrow slowly between his fingers. Below us the kitchen door stands open, letting out light and an argument about who took the clean pot.

“Dain's changed tomorrow's work,” he says. “We're checking the outer banks only. Sella's on the closure path. I'll be back before the evening meal unless he finds a problem.”

“Thank you for telling me.”

He nods, looking at the thread.

For a while I watch his hands. I have watched those hands do a lot of things: draw a bow, count money, take mine without closing too tightly. Knowing what they can do is becoming a problem for my concentration.

“I got paid.”

“How much did they try to deduct for frightening the steward?”

“She frightened me.”

“She's had practice.”

I laugh. He sets the arrow aside before turning toward me.

There is a pale line of old scar near his mouth. I noticed it before, but I have never been this close with nothing happening that requires him to help me stand.

“I still want to go home,” I say.

His expression changes. Not much. Enough.

“I thought you would.”

“If there's a way, I want to find it.”

“I know.”

“I don't want you agreeing because you think I'll stop wanting it later.”

He looks down into the yard. A kitchen worker crosses with a covered bucket, balancing it against her hip.

“I'd be lying if I said the thought pleased me.”

My stomach tightens.

“But I don't want you stranded for my convenience,” he says.

That gets under my ribs in a place I haven't protected very well.

He turns back. I put my good hand against the side of his face. His breath changes beneath my thumb.

“I'm going to kiss you,” I say, which is possibly the least mysterious thing anyone has ever said on a staircase.

“Yes,” he says. “Please.”

The first touch is softer than I expect. I have been imagining him with so much confidence that the small hesitation undoes me. He lets me choose the pressure, then answers it, his hand settling at my waist. Warm through the wool. Careful of the arm tucked between us.

I move closer. The step edge digs into the back of my thigh. He tastes faintly of the mint someone put in the supper water, and for a few seconds my whole ridiculous situation narrows to the fact that I can make him breathe like that.

When I draw back, he doesn't follow until I touch my forehead to his.

“Okay,” I say.

His laugh is quiet. “Okay?”

“I had better words planned.”

“Were there many?”

“An embarrassing amount.”

He strokes the wool at my waist once with his thumb. I feel it much farther away than his hand.

I kiss him again, briefly, because I can. Then I sit back enough to have thoughts.

“I'm going upstairs alone.”

“All right.”

“I wanted that. I want to be clear.”

“You were fairly clear.”

His smile goes crooked. I touch it once before getting up.

In my room, I lean against the bolted door with my face hot and my shoulder reminding me that romance is not an approved treatment. I let myself stand there grinning. Nobody is watching. I don't have to make the moment practical immediately.

Eventually I wash, set out tomorrow's clothes, and take the notebook copies from my sack.

The work is waiting where I left it. So is the part about home. Kissing him has rearranged neither of those facts, although I suspect it will make both of them harder.

On the last page we copied, below a set of measurements, Elena has drawn the stair again. I hadn't looked closely while we were racing the test. Four steps, a flat place, then an empty square outlined twice.

Beside it are three English lines.

*No view of the far side from the wheel. Do not let them call turning it a search.*

*Need a way to see before we cross.*

*Mirror?*

The last word has a question mark large enough to take up its own line.

I pull my blank sheet closer. Tomorrow I can ask Dain whether there is any safe way to look from this side. He may say no. Given the available evidence, no would be a reasonable answer.

Under the question I write another one.

*What would have to be true for yes?*
