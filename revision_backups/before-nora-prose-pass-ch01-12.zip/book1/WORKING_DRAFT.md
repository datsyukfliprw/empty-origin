CHAPTER ONE

“HE’S DOWN! HE’S FUCKING DOWN!”

The scream detonates through my headset half a second before six other voices pile on top of it, and Discord stops being a conversation and becomes weather. Somebody wants the timer checked. Somebody is already clipping it. Somebody keeps saying my handle like a chant, Nyx, Nyx, you beautiful bitch, and I’m laughing too hard to answer any of them.

On my monitor, Vharos the Undying collapses to his knees in a storm of black fire, his enormous health bar finally, finally empty. His sword hits the obsidian floor first. His body follows with enough force to shake the camera.

[VHAROS THE UNDYING: DEFEATED]

[MYTHIC CLEAR]

[NEW SERVER RECORD: 06:42]

For one perfect second nobody says anything. Then Discord becomes completely unusable.

“Six forty-two!”

“Somebody send it to Derek.”

“No. Don’t send him anything. Let him find it.”

That gets me. I fold forward over my keyboard, laughing, one hand clamped over my mouth because the walls in this apartment have roughly the soundproofing properties of wet toilet paper. “Do not message them,” I manage. “Nobody message them. Let them log in tomorrow and see it naturally.”

“Nyx.”

“I mean it.”

“Nyx. They’re online.”

I stop. Someone starts cackling in my headset, which makes everything worse, because now I have to slap my hand back over my mouth before I wake whoever lives on the other side of my bedroom wall. A notification flashes in the corner of the screen.

Derek: fuck all of you

I shove away from my desk and wheeze silently while everyone else loses their shit.

There are eleven people watching my stream. Eleven. Not exactly the screaming stadium I picture whenever I tell myself NyxLive is going to take off someday, but eleven people just watched us beat Derek’s group by thirty-seven seconds, so tonight those eleven beautiful bastards are enough.

pixelwitch: LMAOOOOOO

BoredAtWork88: DEREK IN SHAMBLES

ManaAddict: nyx carried

Derek: banned

I lean toward my mic. “Thank you, ManaAddict. Finally, someone recognizes talent.”

“You died twice,” Liam says.

“Mechanics.”

“You blinked into lava.”

“Advanced mechanics.”

My chat fills with laughing emotes and I grin at the monitor, because this stupid, perfect little pocket of the night is why I keep doing it. I want eleven thousand someday. Enough that NyxLive stops being the thing I squeeze between classes and closing shifts and becomes the thing that pays rent, enough that I can hand in my apron at Brewed Awakening and never again ask another human being whether they want room for cream. But for six hours tonight I wasn’t Maya Szczepaniak, nineteen-year-old community-college student and professional cleaner of espresso machines. I was Nyx.

And Nyx just killed Vharos the fucking Undying.

My stomach growls loudly enough that Liam hears it through the mic.

“What the hell was that?”

“Betrayal.” I pull the headset off one ear. “I need food.”

“At two thirteen in the morning?”

“Yes, Mom.”

“You have food?”

I look toward the kitchen. Technically. “Fuck you.”

More laughter follows me as I go, headset hanging off one ear so I can still hear everyone talking shit. My apartment is small enough that reaching the kitchen takes seven steps, eight if I avoid the floorboard near the bathroom that makes a noise disturbingly similar to a dying goose. I avoid it. The refrigerator hums beneath a cabinet door that hasn’t closed properly since I moved in three months ago, and when I pull it open, cold white light reveals the current state of my independence: half a bottle of ranch, a carton with three eggs left in it, a jar of pickles, one slice of American cheese in a plastic wrapper, and a takeout container I no longer remember purchasing and am therefore unwilling to acknowledge as mine. Behind the milk sits my emergency energy drink.

I stare into it for a while. It offers nothing.

You know you can still come home.

Mom said it in almost this exact spot on move-in day, when the shelves were empty instead of merely depressing. I’d been sweating through an old T-shirt, surrounded by boxes, while she stood with both refrigerator doors open like she was examining evidence at a crime scene.

“You know you can still come home, right?”

“I know.”

“You don’t have to prove anything. You could save money.”

“I know, Mom.”

Dad had appeared behind her carrying a box marked BATHROOM that very obviously contained my gaming speakers. “Your mother means please come home before this building kills you.”

“This building is fine.”

Something crashed upstairs. All three of us looked at the ceiling.

Dad waited a beat. “Convincing.”

I laughed then. I laugh now, quieter, with one hand still on the refrigerator door. They were right, obviously. Living here is financially idiotic. My bedroom at home is still sitting there, probably cleaner than this entire apartment, and Mom would feed me, and Dad would pretend he wasn’t checking the oil in my car every time I visited. Another year with them and I could save enough to transfer somewhere better than community college.

But it would be their house, and this disaster is mine. My rent, my crooked cabinet, my possibly sentient bathroom fan.

I take two of the eggs, reconsider what remains of my standards, and reach back for the ranch, because independence apparently tastes like bad decisions.

My phone lights up on the counter while I’m cracking them.

MAYA SZCZEPANIAK

My college email insists on displaying my full name in aggressive capital letters, which makes me smile despite myself. I used to hate that name. Every first day of school came with the pause, the teacher moving cleanly through Stewart and Turner and Williams before hitting mine and slowing down like someone had dropped a roadblock across the attendance sheet.

Mrs. Henderson in fourth grade made it farther than most.

“Maya… Szz… Chep… an…ick?”

Nine-year-old me looked up from my desk. “Sheh-PAN-yak.”

Twenty-five heads turned. Mrs. Henderson blinked at me over the sheet. “I’m sorry?”

I sighed with the exhaustion of a woman who had already endured nine long years on this earth. “Sheh. Pan. Yak. Like chef, but he lost the F. Then pan, like you cook eggs in. Then yak. Like the hairy cow.”

A few kids giggled. Mrs. Henderson stared at me. “Chef without the F. Pan. Hairy cow.”

“Yes.”

“Sheh-pan-yak.”

I gave her a slow, solemn nod. “You may continue.”

The whole class cracked up. Even Mrs. Henderson had to hide her mouth behind the attendance sheet. Back then I would have traded Szczepaniak for Brown or Miller or Smith without hesitation, anything a substitute could glance at without experiencing an existential crisis. Now I kind of love it. There are eight billion people on the planet, and disappearing into them sounds worse than correcting somebody’s pronunciation.

The eggs hiss in the pan.

“Shit.”

I rescue them a few seconds before they become charcoal, dump them onto a plate, and head back toward my desk with the food in one hand, the ranch bottle tucked against my ribs, and my phone gripped in my teeth, because I am not making two trips.

The boss’s corpse still sprawls across my screen. Discord is still going, my stream is still live, and Nyx stands in the center of the shattered throne room looking fucking immaculate. Long pointed ears rise through silver-white hair. Her fitted black spellblade armor catches the dying glow of Vharos’s flames in sharp lines of dark metal, with just enough exposed skin to make it abundantly clear that whoever designed the female elf armor understood their audience. I made her face as close to mine as the character creator would allow, same cheekbones, same mouth, same slightly upturned nose.

Better hair, obviously.

I set the plate beside my keyboard, drop the phone faceup next to my mouse pad, and fall back into my chair, settling the headset over both ears while somebody argues about whether Derek’s group is going to pretend they weren’t trying tonight. The eggs have gone cold already. I chew anyway. At two fifteen in the morning eggs have stopped being food and become a responsibility I created for myself a few minutes ago.

“So are we running it again?” Liam asks.

“Absolutely fucking not,” Derek says.

“We have the strat now.”

“We have jobs tomorrow.”

“I have class at nine,” I say around a mouthful.

Discord goes quiet for a beat. Then Liam laughs. “Nyx, it’s two fifteen. You’re going to get, what, five hours of sleep?”

“Six.”

“That is not how math works.”

I’m smiling when I take another bite, which costs the insult some of its authority. The adrenaline from the clear has finally started to drain, and my body is taking the opportunity to file six hours’ worth of complaints at once: shoulders aching from the hunch, eyes dry every time I blink, a dent in the top of my head deep enough to qualify as character customization. Tomorrow is going to suck. Today, technically. Whatever. Vharos is dead, and that improves most things.

His corpse is still sprawled in front of his throne, one enormous armored hand hanging over the edge of the dais while embers drift through the room. Five minutes ago all twelve of us were screaming over each other while his health bar crawled toward zero. Now half the raid is discussing sleep like we’ve recently discovered the concept.

I drag my mouse over his body and open the loot window. Three items. The first is useless to me, the second is useful to somebody else, which makes it almost as boring, and I’m already moving toward the third when I read the name.

My fork stops halfway back to the plate. “Oh, you have got to be kidding me.”

“What?” Liam asks.

I click it.

[VHAROS’S EMBERGLASS SABER]

The preview opens across the center of my screen. The blade is long and narrow, black enough that the edges almost disappear against the interface, and translucent fractures run through the metal from hilt to tip with something molten glowing beneath them in slow golden pulses.

Discord detonates.

“That’s spellblade.”

“You already got the shoulders.”

“You’re insufferable.”

“I know,” I say, and hit Need.

The roll spins. Ninety-eight.

“Oh, fuck off,” Liam says, and I laugh hard enough that I almost choke on cold egg.

pixelwitch: RIGGED

ManaAddict: streamer loot

Derek: i hate this game

I equip the sword before anyone can suggest something stupid like letting it sit in my inventory for thirty seconds. Nyx’s old weapon disappears from her hip and the Emberglass Saber replaces it, black blade against black armor, the golden fractures brightening and dimming with her idle animation, light catching along the silverwhite strands of her hair and turning the edges warm. I rotate her once. Then again.

“Okay,” I murmur.

Liam groans. “You’re doing the thing.”

“I’m looking at my sword.”

“You’re checking whether it matches.”

He’s exaggerating. Mostly. The saber looks incredible; the problem is my shoulder enchant, which throws a faint violet particle effect that worked fine with my old weapon and now, beside all that molten gold, makes the whole outfit look like two separate people designed it without speaking to each other. I rotate her back. I could ignore it. I couldn’t possibly ignore it.

“I might need to change my shoulders.”

The silence that follows is a specific one. There’s someone forgot they were muted silence, and there’s everyone is reading the mechanic guide silence, and then there’s this.

“Nyx,” Liam says carefully. “Didn’t you change your mog between pulls?”

I look at my character. She offers no assistance. “…Maybe.”

Someone chokes on a drink. “We were wiping for three hours!”

“I changed one piece.”

“You changed your chest too.”

“It gave me confidence.”

Derek launches into a speech about how people like me have destroyed gaming, and I’m still laughing when something slips sideways inside my head.

The laugh fades on its own. For a second I can’t identify what changed. Derek is still talking, chat is still moving, Vharos remains dead, which feels important enough to verify. Then my chair seems to lean beneath me and my stomach rolls.

I set the fork down before my hand can decide otherwise and wait for the sensation to pass. It does, leaving behind a faint uneasiness that could be exhaustion, hunger, too much caffeine, or any of the other excellent decisions I’ve made since waking up yesterday morning.

“You okay?” Liam asks.

“Yeah.”

I rub beneath one eye and look back at the monitor. The screen seems painfully bright now. Discord’s white lettering glares against the dark interface and the embers drifting through Vharos’s throne room have sharpened into little orange needles of light. Squinting takes the edge off, though it makes reading chat harder. Six hours staring at a monitor probably has consequences. That would be annoyingly reasonable.

A high ringing tone begins somewhere inside my ears. I shift the headset, wondering if one of the speakers is feeding back, but the sound stays exactly the same.

My stomach turns again, slower this time.

I look at my plate. Two eggs stare back at me with all the innocence of people who have recently hired lawyers. When did I buy them? I can picture the carton in the refrigerator, white cardboard, blue label, three left when I opened it tonight, but the actual purchase refuses to materialize. Last week, maybe. Was it last week? I poke a piece with my fork and lean down to smell it. Butter, pepper, egg. Nothing that screams impending organ failure.

“Nyx?” Liam says.

“Hold on.”

I lift one earcup away from my head. The ringing gets no quieter.

“I think I poisoned myself.”

Discord pauses. Somebody laughs.

“With what?”

“The eggs.”

“You can’t poison yourself with eggs.”

“That is not how salmonella works, Liam.”

“I don’t think that’s how salmonella works either.”

“I work at a coffee shop, not the CDC.”

The room lurches. My hand hits the edge of the desk hard enough to rattle the keyboard, the fork jumps against the plate with a metallic clink, and for a few seconds the apartment keeps moving even though nothing in it does.

Nobody laughs this time.

“Nyx?”

I hold on until the floor feels trustworthy again. “I’m…”

The word sticks. I move my tongue across the back of my teeth and it feels thick, slow. Swallowing should happen without instructions. Instead I have to think about it, and even then there’s a delay before my throat obeys.

“Maya?”

That gets my attention. Almost nobody here calls me Maya. Nyx is easier, Nyx is the name over my character and beside my messages and under my stream, and Liam knows my real name but uses it so rarely that hearing it through my headset changes the shape of the room.

I reach for my phone. My hand lands beside it.

The phone is right there, faceup near my mouse pad, and my fingers missed it by maybe two inches. I reach again, and my knuckles catch the case and knock it farther across the desk.

“Shit.”

“Maya, what’s happening?”

“I don’t know.”

The voices in Discord have begun to stretch. Everyone is still talking, but distance has crept into the sound and turned familiar voices thin around the edges. Liam asks me something. Derek says my name. Somebody talks across both of them. I catch call someone and lose the rest.

I push my chair back because I need to do something, and getting water is the first useful idea that survives long enough to act on. The wheels roll backward. The entire apartment rolls with them. Both hands lock around the edge of the desk while nausea sweeps through me, heavy enough to make my mouth flood.

“Maya, call somebody.”

“I’m fine.”

“You are clearly not fucking fine.”

The kitchen. Water. I know that was the plan, but looking toward the doorway makes the plan less convincing, and the distance between my chair and the sink has acquired the complexity of a raid mechanic nobody bothered to explain.

“Maya, call your parents.”

“I’m nineteen.”

“What the fuck does that have to do with anything?”

There should be an answer. Normally, Liam handing me a line that easy would be practically charitable. I can feel the shape of a response somewhere in my head, but every time I reach for the words they slip away.

My eyes drift back to the monitor. Nyx stands exactly where I left her, silver-white hair, black armor, new saber burning gold at her hip, Vharos on the dark floor behind her. Chat keeps moving. I focus on a message long enough to recognize my own name. The rest smears.

The ringing has swollen until it seems to occupy the space where everyone’s voices used to be. My arms are getting harder to move, the weight settling through them so gradually that I only understand how bad it is when I reach for my headset and my hand rises halfway before stopping.

I try again, catch one earcup with my fingers, and drag it off. It lands beside my keyboard, and Discord becomes a faint spill of voices through the speakers.

“Maya? Can you hear me?”

My phone is less than a foot away. I know what to do. Pick it up. Call somebody.

I extend my arm across the desk. It moves several inches before the muscles give out, and my fingertips scrape uselessly against the surface. The phone doesn’t move. For a few seconds I keep looking at it as though the problem might correct itself, the black screen reflecting a warped strip of light from my monitor.

I try again. My elbow trembles. Nothing.

The eggs are irrelevant. That much arrives with perfect clarity. Whatever is happening has moved beyond food poisoning and into a category I have no clever theory for.

I open my mouth. “Mom.”

The word comes out quietly. I picture her asleep with her phone charging on the nightstand, the volume too low, the way I complain about every time she misses one of my calls.

I’ll call twice. If she doesn’t answer the first one, I’ll call twice.

I plant my palm against the desk and try to push myself closer. My arm folds. I catch myself on both forearms before I can slide out of the chair, and the movement sends another slow wave through the room. Lowering my forehead onto my arms eases it a little. The skin there is cool against my face.

Just until the room stops. Then the phone.

Liam’s voice leaks from the headset beside me, joined by several others now, the urgency legible even where the words aren’t. Someone says ambulance. Someone asks where I live.

I know my address. Of course I know my address. I try to give it to them, and nothing useful leaves my mouth.

My head has become too heavy to lift. The fact enters my mind without much reaction, as though it belongs to somebody else and I’m only responsible for observing it. From where my head rests on my arms I can see part of the monitor. Nyx’s boots. The lower edge of her armor. A wash of firelight across the obsidian floor. I try to lift my head enough to see the rest of her, and nothing happens.

Class at nine. I need to call Mom. My phone.

“Maya?”

The last thing I know about Earth is the hiss of my headset, the smell of overcooked eggs, and eleven people watching Nyx stand victorious over a dead king.

Cold touches my cheek.

I flinch away from it without opening my eyes, turning my face into something soft and damp, and another drop lands near my temple and slides into my hair. For a while I lie there trying to understand why my ceiling is leaking on me. The thought doesn’t survive long. My ceiling is six feet above my bed, for one thing. Also I’m not in my bed. I wasn’t even in bed. I was at my desk.

My eyes open.

Gray fills my vision, enormous and shifting. It isn’t drywall and it isn’t the weak predawn light that leaks through the bent blinds in my bedroom. It moves, clouds folding over one another across a sky so wide my brain refuses to make sense of it.

A raindrop hits me directly in the eye.

“Fuck.”

I squeeze it shut, turn my head, and grass brushes my lips. Actual grass.

I go still. Rain taps against leaves somewhere nearby, thousands of soft impacts gathering into a steady whisper. Something cold has soaked through the side of my shirt. Damp earth presses against my hip and shoulder, and the air smells green and wet, rich with soil and crushed plants and something faintly sweet I can’t place.

I push myself onto one elbow, and the world tilts hard enough that I stop there, breathing through a wave of nausea that brings the eggs back with unfortunate clarity. The eggs. My desk. Liam saying my name through the headset. My phone sitting just out of reach. Mom. I remember trying to get to it, and then nothing.

“What the fuck?”

My voice disappears into the rain. I sit up, and forget about the eggs.

I’m in a clearing. Tall grass bends beneath the rain in every direction, silver-green blades brushing my bare legs, tiny white flowers clustered among them with their petals folded tight against the weather. Beyond the clearing a forest rises beneath the bruised sky, and for several seconds all I can do is stare.

The trees are enormous. Their pale trunks climb straight out of the dark undergrowth, broad enough that I couldn’t get both arms around one even with three people helping, smooth ivory bark darkening in the rain, the lowest branches beginning high enough to scrape the roof off my apartment building. The leaves are wrong too, long and narrow and almost blue beneath the clouds, overlapping in dense layers that turn everything past them into shadow. Rain catches along their edges before spilling toward the ground in shining streams, and mist moves slowly between the trunks.

It’s beautiful. The kind of beautiful I’d stop scrolling for, the kind somebody would post with dramatic music and a caption insisting the picture hadn’t been edited, and I’d immediately assume they were lying.

Then I turn my head.

The clearing slopes gently downward before disappearing into another stretch of forest, and beyond that, through a break in the trees, mountains cut across the horizon. Jagged black ridges spear up through banks of cloud, their highest peaks lost completely inside the storm. Waterfalls thread down the nearest slopes in thin white lines, too distant to hear, bright enough to see whenever the clouds shift.

I have never seen those mountains.

I get to my feet too fast. Blood drains out of my head, the clearing lurches sideways, and I stagger before catching myself with one hand against the wet ground.

“Okay.”

My breathing sounds too loud out here. I straighten more carefully and look down at myself. Bare feet planted in wet grass. Black sleep shorts plastered against my thighs. An oversized T-shirt with CRIT HAPPENS printed across the chest. No bra. Apparently whatever catastrophic medical event occurred at my desk respected neither dignity nor footwear.

I pat my pockets even though I already know what’s going to happen. Nothing. Of course nothing, they’re sleep shorts. I check again anyway, then turn and scan the grass around me, because my phone could have fallen somewhere, except I remember it sitting on my desk, and my desk isn’t here. Neither is my chair. Or my computer. Or my apartment.

I look toward the forest. There has to be something beyond it. A road. A campground. A house. Some asshole with a camera about to leap out from behind one of those trees and explain whatever elaborate prank I’ve somehow become important enough to deserve.

I turn the other way. More forest. Behind me, the same. To my left, mountains. To my right, the clearing narrows between two walls of pale trunks and disappears downhill. No roofs break the canopy, no telephone poles, no road, no distant smear of headlights or power lines or contrails. Nothing moves across the sky except rain and cloud. I listen harder and get rain, leaves, and wind somewhere high in the canopy.

That’s it.

I turn slowly back toward the mountains.

Kansas City doesn’t have mountains.

The thought arrives with terrible clarity, and no shit follows right behind it. Maybe I’m not in Kansas City. People wake up in strange places. People get drugged, kidnapped, lose time, wake up hundreds of miles from where they started with no idea how they got there. Horrifying, but a thing.

Except people don’t get kidnapped barefoot out of locked apartments while eleven people watch them livestream.

I look down at my hands. Same short nails. Same tiny white scar beside my left thumb from opening a can when I was twelve and refusing to wait for Dad to find the proper opener. I touch my face, fingertips moving over my nose, my cheek, my mouth, then shove wet hair away from my forehead.

I’m me. So where the fuck am I?

Something clamps around my chest. I drag in a breath and it stops halfway. I try again, harder, and somehow get less air.

“No.”

My hands are shaking. I press them against my thighs. There is an explanation. Hospital, except obviously not. Coma, except people have dreams in comas, and I don’t know whether they know they’re in comas. Hallucination. Poisoning. Brain damage. Jesus Christ.

I squeeze my eyes shut. My heart pounds harder in the darkness, and when I open them there are pale trunks and blue-black leaves and mountains and rain.

A sound slips out of me, small and thin, and I don’t recognize it as mine until another one tries to follow. My lungs start working too fast. Air keeps stopping high in my chest, each breath arriving before the last one has finished, and my fingers are tingling, and then my lips. I know this. I’m breathing too fast. Slow down.

I can’t.

I wrap my arms around myself and turn, searching the clearing again, though I’ve stopped knowing what I’m searching for. A road. A person. My apartment.

I want my phone. The need hits so hard my hand goes to my empty pocket again. I want my apartment. I want the stupid cabinet that doesn’t close unless I kick the bottom corner. I want Liam yelling through my headset. I want my desk, my bed, my fucking shoes.

I want my dad.

Everything stops.

For a heartbeat I’m nine again, staring at a difficult last name on an attendance sheet while Dad waits outside school in his truck. Then I’m nineteen and barefoot in the rain, with mountains that shouldn’t exist in front of me and no phone and no road and no idea how to get home.

“Dad?”

It comes out before I can stop it, too quiet, and nothing answers. Of course nothing answers.

Rain slides down my face. I wipe at it, and my hand comes away wet, and I don’t know how much of it is rain anymore.

“Dad!”

My voice cracks across the clearing. The forest takes his name and gives nothing back.

“Dad!”

I claw at the collar of my shirt and drag it away from my throat. It doesn’t help. Air keeps coming in tiny useless pieces, my lungs fluttering faster while my heart hammers so violently that for one insane second I’m certain I died at my desk and I’m dying again now.

Liam saw me collapse. He’ll call someone. They’ll find my apartment, and they’ll call my parents, and Mom is going to think I’m dead.

That one gets me all the way to the ground.

I make a strangled sound and clamp both hands over my mouth, which only makes the next breath worse, so I rip them away. My vision pulses at the edges. Some part of me keeps waiting for reality to snap back into place, for my bedroom to appear around me, for Liam’s voice to come through the headset, for Dad to answer.

The rain thickens instead. Drops strike hard enough now to flatten the little white flowers around my feet, and wind pushes through the clearing, cold against my soaked shirt, carrying the smell of stone and leaves and distant water.

Then the sky growls, low and far away.

I freeze. The sound rolls across the mountains, deep enough that I feel a faint vibration beneath my bare feet. A pale flash flickers somewhere behind the clouds, and the answering crack comes harder.

Every hair on my arms rises.

For one beat, I forget to panic. Then something simpler shoves its way through: I am standing in an open field, barefoot, in a thunderstorm, surrounded by a forest I know absolutely nothing about.

“Okay.” My voice shakes badly enough that the word barely exists. I swallow. “Okay, Maya.”

I don’t have to understand where I am. Not right now. I don’t have to understand how I got here. Another flash turns the clouds white and the thunder answers sooner, and the only thing I have to do is get out of the open. One thing. I can do one thing.

I look toward the nearest trees. The forest that seemed beautiful ten minutes ago now looks deep enough to swallow me, darkness gathering between the pale trunks, mist crawling low through undergrowth I can’t identify. I have no idea what lives in there. Snakes. Bears. Wolves. People. Something I don’t have a name for.

My feet won’t move.

Thunder rolls again, closer, and I force one foot forward, then the other, and somewhere between the middle of the clearing and the treeline I start counting the way Dad taught me on the porch the summer I was seven. One thousand one. One thousand two.

The thunder comes before I reach three.

I go in.

CHAPTER TWO

Ten steps into the trees the rain stops falling on me, which is the last good thing that happens for a long time.

Under the canopy the downpour turns into something slower and heavier, water gathering somewhere far above and coming down all at once, so that instead of being rained on I’m being ambushed at irregular intervals. The ground is worse. Whatever grows here has spent centuries composting itself into a black spongy layer that swallows my feet past the ankle, and there’s no way to tell which parts of it are soft and which parts are hiding something with edges. Ferns as high as my hip slap wet across my thighs. The air smells like rot and green sap, colder under the trees than it was in the open, and every few steps a bead of water finds the back of my neck and runs the whole length of my spine.

Thunder cracks behind me. I flinch hard enough to put my shoulder into a trunk, and the ivory bark turns out to be rough as concrete.

“Okay,” I tell the tree.

Talking helps. It shouldn’t, but it does, so I keep doing it, narrating like I’m on stream with eleven people watching, because the only other thing to listen to is how quiet a forest gets between thunderclaps.

The plan, such as it is, lasts about as long as it takes to say it out loud. I’d meant to go downhill, since water goes downhill and rivers go past towns and towns have people in them, which is the kind of reasoning that sounds excellent right up until you try to execute it barefoot. The slope keeps folding into little ravines full of standing water. Twice I get turned around badly enough that I have to stop and find the mountains again through a gap in the branches, and the second time I can’t, because the cloud has come down into the trees and the world has shrunk to forty feet of dripping gray.

My foot finds something buried and sharp, and my weight is already on it before I understand what’s happening.

The pain arrives a full second late, bright and specific along the arch of my left foot. I go down onto one knee in the muck, grab my ankle with both hands, and haul my foot into my lap. It’s too dark to see much. What I can see is a clean line about two inches long, open, filling slowly.

“No no no no.”

Some part of me observes that I’m bleeding, that bleeding is a debuff, and that debuffs tick, and I laugh once at how useless six years of raid logic has turned out to be. The sound comes out ugly enough that I stop.

The hem of my shirt tears easier than I expect once I get my teeth into it, which is the only skill this entire night has actually asked me for. I get a strip three fingers wide, wind it twice around the arch, knot it on top of my foot, and pull the knot tight enough that my eyes water. Cold air moves across my stomach where the shirt used to be. That seems like a fair trade for about ninety seconds.

Standing up is a negotiation. The foot holds. It holds badly, and it’s going to keep getting worse, and knowing both of those things doesn’t change what I do next, which is put weight on it and keep walking.

The light goes while I’m still walking. It doesn’t set so much as drain, gray thinning down through the trunks until I’m navigating by the paleness of the bark, and by then the shivering has started.

It comes in waves, jaw and shoulders and hands all going at once, and at first I’m almost relieved, because shivering is a thing bodies do and I recognize it. Then it stops for a while. That’s the part that frightens me. It stops, and I feel warmer, and some slow flat voice in the back of my skull points out that I have absolutely no business feeling warmer. Off the wet ground. Under something. I say it out loud twice while I look, because the space between having the thought and doing anything about it keeps getting wider.

I find the fallen tree by walking into it.

It came down a long time ago, one of the pale giants pulled over at the root, and the plate of roots it dragged out of the earth stands higher than my apartment ceiling, a wall of dirt and wood and hanging stones. Beneath it the trunk has rotted back into a hollow, dry-ish, floored with years of shed leaves. Something could live in there. Something probably does. I crouch at the opening with my heart going and listen for as long as I can stand to, which is not very long, and then I climb in, because the alternative is not climbing in.

The hollow smells like a wet basement. I rake leaves over my legs with both arms until I’m buried past the waist, then keep going until the pile covers my stomach and my chest and everything but my face. The leaves are cold. They stay cold for a long time. Eventually they stop stealing from me and start giving a little back, and somewhere in there the shivering comes back hard enough to knock my teeth together.

I lie in the dark of a dead tree with my foot throbbing in time with my pulse, and I let myself think about my mother.

She’ll be at the hospital by now, or standing in my kitchen with a police officer explaining that nobody has found anything yet. I can see her hands. She does this thing where she holds one wrist with the other when she’s frightened, like she’s taking her own pulse. Dad will be driving. Dad drives when he can’t fix anything, and this is the most unfixable thing that has ever happened to our family, so he’ll drive very carefully and very slowly and he won’t say one word the entire way.

I press the heels of my hands into my eyes until colors come.

Then a branch snaps outside, and I stop with my hands still over my face.

It’s close, close enough that I can hear the separate pieces of it: the suck and release of something heavy pulling its foot out of wet ground, a pause, another step. Whatever it is, it isn’t in a hurry. It moves the way a thing moves when nothing in the forest has ever made it hurry.

Through the gap between the leaf pile and the lip of the hollow I can see maybe eight feet of the outside world, and after a moment part of that world darkens.

A leg comes into view. That’s all I get. It’s grayish and long and it bends in a place legs do not bend, and the foot at the bottom of it splays wide across the mud, four toes, no claws I can see, the skin cracked and pale like something left too long in water. It stops. It stands there. Rain runs off it without any of the flinching that rain causes in things I know.

I don’t breathe.

Then, above the leg, four or five feet higher than the top of my sightline, something glows.

It’s faint, and green, and it hangs in the air the way nothing hangs in the air. I can see the underside of it as a soft smear of light on the wet bark near the creature’s shoulder. It flickers once. The leg lifts, splays down again farther on, and the light goes with it, sliding between the trunks until the mist takes both.

I stay where I am for a long, long time.

At some point I fall asleep, which frightens me more than anything else that night, because I don’t decide to do it. I simply stop, and then the world is gray and the rain has quit and my whole body has locked into one enormous ache.

I don’t get up right away. I lie in my leaf pile and take stock the way I would after a bad wipe, when everyone is dead on the floor and somebody has to say something useful before Derek starts assigning blame. The foot is bad and getting worse. The cold turned out to be survivable, apparently, since I survived it. I’ve been drinking off leaves, which is probably how you contract whatever the fantasy version of giardia is, and I haven’t eaten since the eggs, and I am sharing this forest with something whose knee opens backward.

Also there had been a light. I have been carefully not thinking about the light.

I crawl out into a forest gone soft and pearly with dawn, mist lying in the hollows between roots, water still coming down off the leaves in bright irregular ticks. It’s beautiful. I have room to notice that it’s beautiful, which tells me something about how far I’ve come since yesterday.

The animal notices me at the same moment I notice it.

It’s rabbit-shaped in the loosest possible sense, sitting up on its haunches in a patch of low ferns thirty feet away, gray-brown, ears lying flat along its spine instead of standing up. Its eyes are set on the front of its skull, both of them facing me, the way eyes are arranged on things that hunt.

Above it, hanging in the wet air, is a line of pale green letters.

I stop moving. So does it. I look at the words floating over its head, and I know exactly what I’m looking at, because I have looked at ten thousand of them. It’s a nameplate. There is a nameplate hovering over a rabbit in a forest, holding perfectly level and perfectly legible no matter which way the head underneath it turns.

The letters are not English. They aren’t anything, a dense little run of hooks and strokes, and I stare at them the way you stare at a word you’ve forgotten how to read, and then they slide sideways in my vision and settle.

**[BRIAR-SKIPPER, LV. 3]**

“No,” I say.

The thing bolts. Its nameplate goes with it, the ferns swallow both, and I’m left standing barefoot in the mist with my hands out in front of me like I’m about to catch something.

I look at my hands.

Nothing hangs over them. Nothing hangs over me at all. I turn in a full slow circle, and the forest offers me one more nameplate, small and dim, over something moving high up in the blue-black leaves, and then nothing else. I hold my palm out and say, feeling like the stupidest human being ever to draw breath, “Status.”

Water ticks off the leaves.

“Menu. Inventory. Help.”

I say a few other things after that, none of them commands, and when I’ve run out I sit down on a root with my bad foot stretched in front of me and my arms wrapped around my ribs, and I make myself say the true thing plainly, because when I don’t say the true thing my mind starts building nicer ones.

There’s a system here. Everything in this forest is inside it.

I’m not.

Nyx had a health bar. She had a resource bar and cooldowns and a little icon that told her when she was bleeding and exactly how long it would last, and Nyx is a set of files on a server in a country I have never visited, standing where I left her in a dead king’s throne room with a sword she won on a ninety-eight roll.

Something moves downhill.

It’s faster than the wind in the leaves and lighter than whatever walked past my tree in the dark, and there’s a rhythm to it, an even one, the kind that only comes off two legs. I’m up off the root before I’ve finished hearing it, weight on the wrong foot, pain climbing my shin.

Down the slope, through the mist, a nameplate kindles.

It’s brighter than the rabbit’s. It comes up out of the gray in clean pale letters, and it holds steady, and it climbs. Whoever is carrying it is walking straight up the hill toward me and making no effort at all to be quiet about it.

The hollow is four steps behind me. The leaves in there are still shaped around where I slept, and I stand with my weight on my good foot and don’t take a single one of those steps, because I have been alone in this forest for one night and I already know what a second one would do to me.

The letters come clear about twenty feet out.

**[TRAVELER, LV. 11]**

CHAPTER THREE

He stops farther out than he needs to.

Twenty feet was where the letters came clear. He gets to something like fifteen and then his boots quit moving, and everything above them keeps its shape, hands loose, shoulders easy, weight settled back off the balls of his feet the way you stand when you have decided not to be anywhere in particular for a while. Water comes down through the canopy between us in slow irregular strings, and he lets it.

Somebody who wanted to hurt me would have closed the distance. That is the entire argument, and it holds together about as well as anything else I have built since yesterday afternoon, and I let it hold, because four steps behind me there is a rotted hollow with a pile of leaves still shaped around my body, and I would rather be wrong about him than sleep in it twice.

The decision takes me under two seconds. I set that aside to be disturbed about later.

He is young, not a teenager but not far past whatever this place does instead, and my brain starts handing me observations in an order that has nothing to do with survival. Dark hair pushed back wet off his forehead. A coat that fits like somebody measured him for it. The fact that he is standing in a soaked forest at dawn looking like he slept somewhere with a roof over him. There is a bow across his back and something shorter riding his hip and a strap running diagonal over his chest, and I get to all of that a solid two seconds after I get to his mouth.

Nineteen years of judgment, and it dies in a wet forest at sunrise.

He is not looking at my face. His eyes sit higher, angled at a spot somewhere above my head, and they stay there while the rest of him does nothing at all. I put a hand up into my hair, which is currently a knotted disaster with actual forest in it, and his attention does not follow the movement even a little.

Then he says something, and it lands wrong.

It arrives as sound before it arrives as language, dense and clipped, a run of syllables my ear cannot file. I am already opening my mouth to tell him I don't understand when the sound slides sideways behind my eyes, the way the letters over the rabbit did, and settles.

"You're a long way from a road."

His mouth has already stopped by the time I hear it. The gap is small, half a second at most, and I reach for it and come back with nothing useful, because I have not slept, and because sound does strange things under a canopy this thick, and because I am so relieved to be receiving whole sentences from another human being that I would forgive that voice almost anything.

"Yeah." Gravel comes out with it. "I've been having a night."

His head tips a fraction. Whatever he heard in that is apparently worth more than the words, because his attention finally comes down off the thing he was studying and lands on my face, which turns out to be worse. He looks me over thoroughly and without any rudeness in it, the shirt with CRIT HAPPENS half erased under the mud, the torn hem, the bare stretch of stomach where the strip came off, the shorts, my legs, my feet. At the foot he stops.

"Is there anybody with you?"

"No."

"Was there?"

"No."

He takes that in. Behind him the mist is coming off the slope in pieces now, and somewhere below us a bird is making a noise like a spoon dragged round a pot, and I stand there on one foot understanding that everything I say is evidence in a case whose rules nobody has explained to me.

"What do you run?"

I have all the words. Every one of them came in clean and settled and I can hold them in my head, and I do not know what he is asking me. It isn't that I don't know the answer. I don't know what shape the answer is supposed to be. He might be asking my job. He might be asking my religion. He might be asking something so ordinary that a child here would answer it around a mouthful of breakfast.

"Sorry. What?"

He waits. He has a patient face, and it occurs to me that patience is a thing a person can do at you.

"What do you run," he says again, identical, no help added.

"I don't understand the question."

Something moves behind his eyes, small, and it is not confusion. He files it the way I would file a healer standing in fire.

Fine. Two can be strange at each other. I lift my palm, feeling like the single stupidest human being to draw breath on any world, and say, "Status."

Water ticks off the leaves. Down the slope the bird works through its material.

He laughs. Barely, a breath out through the nose and a shift at one corner of his mouth, and there is nothing cruel in it, which is somehow more insulting, because cruel would mean I had registered as a threat. He looks like a man watching somebody try to open a door by asking it politely.

"Great," I say.

"You're bleeding through."

I follow him down to my own foot. The strip of shirt around my arch has gone from gray to a color I would rather not name, and while I was up here conducting first contact, a thin dark line has been running the outside edge of my sole into the mud. It does not hurt any more than it did an hour ago. I have a strong feeling that is not the good news it sounds like.

He crosses the distance without asking, which after all that careful fifteen feet happens fast, and then he is crouched in front of me with a hand hovering near my ankle. "Can I."

"Yes."

His fingers close around my heel and lift, and I have to grab his shoulder or fall over, so I grab his shoulder. He is warm. He is so warm that touching him actually hurts, a deep ache spreading up through my palm into my wrist, and that is when I understand how cold I have been since yesterday, not as a fact I have been reciting at myself all night, but as something my body has been screaming about underneath the recitation.

He turns my foot toward the light and peels the knot up with a thumbnail. Whatever is under there he does not editorialize about, though something happens along his jaw.

"How long?"

"Last night. Early."

"You slept out here with this."

"I slept in a tree." Out loud that sounds worse. "Inside one. It was already down."

He sets my foot back into the mud with more care than the rest of him has shown so far, stands, and looks at me from a foot and a half away, and I get the whole effect at once: gray eyes, a scar cut through one eyebrow, leather and wet wool and old woodsmoke. Close enough that I can watch him make a decision.

"Close it," he says.

"Close what?"

The pause after that is the longest one yet, and he spends all of it completely still.

"Your foot." Slower. "Close it."

"I don't." My throat clicks. "I don't know how to do that."

I wait for him to explain. He doesn't. He stands in the gray light and looks at me and arrives somewhere, and the arrival is neither kind nor unkind. It is the face of a man who came up this hill expecting one thing and has been handed something considerably more valuable.

He reaches past me instead, unhooks a skin from his belt, works the tie loose and puts it in my hands, then goes into the pack at his hip for a folded square of cloth that is clean in a way nothing in my life has been clean in twenty-four hours. He kneels again and rewraps the arch, tight, then tighter, and I hiss through my teeth and dig into his shoulder and he does not apologize.

"Drink that," he says, without looking up. "All of it."

I drink it. It is water, faintly of the skin it lives in, and it is the best thing that has ever entered my body.

"There's a village." He ties off the wrap. "Not close. Keep walking on this the way you've been walking on it and you get about a day before it stops being about the foot."

"Okay."

"You want to come."

It is not a question, but there is a hook set in it somewhere. He is still crouched, forearms across his knee, looking up at me, and I understand that I am supposed to say yes, and that yes has a price on it I cannot read from here.

"Yes," I say anyway.

He nods once and rises, and then, easy, brushing dirt off his knee, in the voice you would use about weather: "Who set your plate?"

The word comes through like all the others, clean and settled and completely empty. Plate. My head offers me a dinner plate, a license plate, the great disc of roots standing on end behind me where the tree came down. I look at him and wait for the rest of it and the rest of it does not come.

"I don't know what that means."

Not a flicker. He puts a hand under my elbow and my whole arm goes hot where he touches me, and I resent my body for its scheduling.

"Then don't say that again until we're inside," he says. "Not to anyone. Can you manage that?"

"Say what?"

"Any of it." He starts us downhill, taking my weight on the bad side before I can ask, his voice dropping in low beside my ear. "You've got a face people want to help. Let them."

I should ask his name. I get halfway into it and he is already talking about the creek at the bottom and where the crossing is, and the question folds up behind my teeth, because I am being carried down a mountain by somebody warm who gave me water, and asking for more feels like ingratitude.

He never asks mine, either.

He does not ask where I came from, or how I got up here without shoes, or what happened to the rest of my clothes, or who I have lost. He asks about the foot twice and the water once, and then he tells me a long and genuinely funny story about a mule, and I laugh in the wrong places because I am shaking too hard to time anything. It is not until we are through the creek and up the far bank that I notice how much he knows about me now, and how little of it he had to ask for.

By then the sun is properly up, and his coat is around my shoulders, and I am so grateful I could put my face in my hands.

CHAPTER FOUR

He makes me eat before he lets me ask anything.

What he puts in my hand is a strip of dried something the color of an old belt, and it takes three tries to work out that I am supposed to gnaw at it rather than bite through it. Salt arrives first, then smoke, then an animal I decide not to identify. By the fourth mouthful my jaw aches. I keep going anyway, because sometime around dawn my body stopped making requests and started issuing instructions in a voice I have never heard it use.

He watches me get through half the strip and then holds the water out again without being asked.

"Slower," he says.

"I'm going slow."

"You're going fast in small pieces."

We follow the creek down for most of the morning. It is easier than the slope was and worse than it looks, because the bank is all rounded stone and my left foot has an opinion about every single one of them. He sets a pace that seems lazy for about ten minutes and then reveals itself as the exact speed at which I can keep moving without stopping. He does not comment when I fall behind, and he does not slow down either. He simply drifts wider on the bad side, so that every time my ankle rolls there is a shoulder somewhere in the vicinity of my hand.

Around the second bend the creek widens and the trees pull back off the water, and light comes down into the channel the way it has not since I got here. Steam lifts off the wet stones. Small brown things with too many legs skitter into the cracks when my shadow crosses them, and none of them have letters over their heads, which is the first thing I have learned about this place by looking instead of by being frightened.

He stops at a flat shelf of rock and crouches to refill the skin. While the water runs he presses two fingers into the notch at the base of his throat and holds them there, eyes gone middle distance, the way you check a phone at a stoplight.

"Are we close?" I ask.

He takes his hand down. "Tomorrow."

By midmorning the creek meets something that people made. It is not a road yet, only a groove worn into the turf by a hundred years of the same cart, grass standing up between the ruts and a stone at the fork with marks cut into it that slide sideways in my vision and settle into a word I do not recognize as a place. My chest does something complicated at the sight of those ruts. Somebody drove here. Somebody had somewhere to be.

I have been walking behind a man for four hours and I still do not know what to call him.

"What's your name?"

He is a few steps ahead. He does not stop or turn, but the answer takes long enough that I hear him decide to give it.

"Tolliver."

"Tolliver."

"Toll, mostly. Tolliver's what my mother uses when I've cost her money."

That gets a laugh out of me, and the laugh surprises me more than the joke did, because it is the first one since the eggs and it comes out sounding almost like something I would recognize on a stream. "Maya," I say. "I'm Maya."

"Maya," he says, and keeps walking.

That is all of it. He does not repeat it back wrong or ask me to spell it or make the face people make, and I am so pleased by what he does not do that I never once look at what he does.

The lessons start after that, and they come the way he does everything, sideways and without warning. Do not sit with my back to the road. Do not accept a first price. If somebody asks where I have come from, name the last place the two of us have actually walked past and let them do the rest of the work themselves. Do not touch anyone's shoulder. That last one arrives with no explanation, and when I ask for one he says, "It's a shoulder," in the voice of a man being asked why you should not put your hand in someone's mouth.

Then he says, "And when we get in, keep your plate shut."

I stop walking.

He goes another three paces before he notices, and when he turns there is nothing at all on his face, which is worse than if he had looked caught.

"What's a plate," I say.

The creek fills the gap. Somewhere behind us a bird works through the same four notes it has been working through for an hour.

"You've seen one," he says.

"I've seen a lot of things since yesterday."

He lifts two fingers and taps the air above his own head, twice, without looking up, the way you would point at a hat you were already wearing. "There."

And there it is. Where it has been since he came up out of the mist, where it was over the rabbit and over the thing high in the leaves and over whatever walked past my tree in the dark on a knee that bent the wrong way. Pale letters holding perfectly level while he moves underneath them.

**[TRAVELER, LV. 11]**

"That's not your name," I say.

"No."

"So it's what, a title? Something you picked?"

"Something I set." He is watching me the way he watched me yesterday, and I know now that the look means I have handed him something again without meaning to. "Everybody sets one. You set it to whatever gets you through a gate with the fewest questions attached. Mine says traveler because traveler is the most boring word in the world and nobody has ever followed a traveler home."

"And underneath it there's."

"What you'd rather not give a stranger."

The creek goes on doing what creeks do. I look at his letters and my mouth dries out in a way the water is not going to fix.

"What does mine say."

Tolliver does not answer straight away, and I have known him for a day and a half and I already understand that his pauses are not hesitation. They are pricing.

"Your name," he says.

"My name."

"All of it."

I put my hand up over my own head. Nothing. Of course nothing. I did this yesterday. I stood in a dripping forest and turned all the way around and found nothing over myself, and I sat down on a root and told myself the true thing plainly, and the true thing I came up with was that I was outside the machine.

"I can't see it."

"Nobody sees their own." He says it patiently, and the patience is what gets me, because you are only that patient with a person who is missing something enormous. "You'd go mad. It would be like a word stuck to the front of your eye."

"Then how do you know what yours says?"

"Because I set it."

Cold climbs my chest and it has nothing to do with the water or the shirt. I have been in this world for one full day. I crouched in a rotted trunk and bled into the mud and stood in a clearing screaming for my father, and every second of it happened underneath my own name, hung in the air over my head in letters bright enough to read across a clearing, in a place where every living person learned to cover theirs before they learned to read them.

"How far away can you see it?"

He looks off down the ruts toward the mill we have not reached, then back at me, and he tells me the truth, which I will be turning over for a long time.

"I read yours from the bottom of the hill."

The bird runs its four notes again.

He came up that slope already knowing. He walked fifteen careful feet of politeness at a woman he had already read, and asked what I ran, and who set my plate, and whether there was anybody with me, and I stood barefoot in the mud and answered all of it like somebody being handed a glass of water.

The thought gets exactly that far. Then my foot throbs, and I remember his hands turning it toward the light, and the clean cloth, and the skin held out this morning before I knew I wanted it, and the thought folds itself up small and goes somewhere I can find it later if I ever need it.

"Okay," I say. "Show me how to close it."

Something in his shoulders comes down half an inch.

"Two fingers." He puts his own to the hollow of his throat, and my stomach drops, because he has done that a dozen times since dawn and I filed every one of them as a nervous habit. "Here. Press until it goes soft. Then don't take them off, or you'll lose it."

I press two fingers into the notch above my collarbone. Skin. It stays skin long enough that I begin assembling the joke I am going to make about it.

Then it goes soft.

There is no better word. The pressure under my fingertips stops being flesh and turns into something with give in it, like pushing up on the underside of water, and the creek and the ruts and Tolliver all slide back half a step without moving at all, and hanging in front of my face, close enough that I flinch, is writing.

The letters do what they always do, a dense little run of hooks and strokes my eye refuses and then abruptly accepts.

**[MAYA SZCZEPANIAK, LV. 1]**

**[ORIGIN: ]**

I stop breathing.

Not the clearing thing. Not the fluttering, useless, top of the chest thing. I simply stop, standing in a cart rut with two fingers at my throat, looking at my own name.

Nobody here has ever heard that name. There is no country in this world that made it, no great-grandfather who carried it across an ocean in a coat with the buttons cut off, no attendance sheet that ever broke against it, no paper cup with SHEP written on the side by a manager who gave up halfway. It has no business being in this air. And it is here, spelled right, in a script I cannot read, hanging over a barefoot girl on a road nobody drove her to.

Something has been keeping track of me.

"Level one," I say. My voice comes out wrong.

"Yes."

"Is that bad."

"On a child it's nothing." He has come closer without my hearing him. "On you it's a story, and every person who reads it will write a different one, and none of them are good."

Underneath the level there is a colon and then a clean pale gap where a word should be sitting, and it frightens me more than the number does, because a number can at least be argued with.

"What goes there?"

"Where you're held. Where you're from, if you'd rather have it that way. A holding, a house, a company, a temple. Something answerable." He says it flatly. "Everyone has one. Foundlings have one. The man who clears the ditch outside the wall has one."

"Mine's empty."

"Mine isn't." He waits until I look at him. "That's what turns you away at a gate, Maya. Not the level. The level makes them curious. The gap makes them careful."

"Read it to me."

"You're looking right at it."

"I know."

He does not ask why, which is its own small mercy, and he does not make a performance of it either. He just reads it out. Maya Szczepaniak. Chef who lost the F, then pan, then the hairy cow, every consonant landing where my father lands them, the whole ridiculous machine of it running clean off the tongue of a man who has never heard of any of those things.

Nobody gets it the first time. In nineteen years, nobody has ever once gotten it the first time.

Some small clean part of me, the part that reads a boss's cast bar while the rest of the raid is screaming, notices that he never looked up to do it.

I let it go. I am cold and I am hungry and there is writing in the air with my name in it, and I have exactly one person.

He talks me through the rest with a hand on my elbow. There is a place inside the panel that gives the way my throat gave, and behind it a short list of plain words, which must be the reason every plate on this road says something boring. He tells me not to take traveler. Two travelers walking in together invites the sort of question he has spent his life not being asked. He runs through others. Laborer. Pilgrim. Hand.

"Household," he says, and stops there.

"What's that one mean?"

"That somebody's answerable for you." He is watching the letters and not me. "Out here that beats being nobody's."

I take it.

My fingers come off my throat and the writing folds down out of the air, and his eyes track up and to the left, to the place above my head he has been reading since the bottom of the hill.

He nods once.

"What does it say now?"

"Household. Level one."

"It still shows the level."

"It always shows the level. That's what it's for." He is already moving, already turning us back down the ruts with his hand under my arm, and his voice drops low and close and easy the way it did yesterday. "Which is why you're going to let me do the talking at the gate. All of it. Even if they put the question straight to you. You look at me and you let it be rude."

"They'll think I'm simple."

"They'll think you're mine," he says, "and simple, and nobody has ever been hanged for either."

There is a place where a reaction is supposed to go. I can feel the shape of the hole. What actually arrives is the enormous animal relief of a person who has spent twenty-six hours in a wet forest and has just been handed a plan by somebody who sounds like he has made one before.

"Okay."

We walk. The ruts deepen and firm up, and after a while there is a fence, a built thing, split rails gone silver with weather, and beyond it a field with rows in it. I have to stop and put my hand on the top rail, because rows mean somebody knelt down and made them.

Tolliver waits.

"Sorry," I say. "It's a fence."

"It is."

"You don't understand. It's a fence."

Whatever crosses his face is gone before I can name it. He starts us walking again, and I am four or five steps along before I hear my own voice ask the thing I have been carrying since yesterday afternoon.

"You asked me what I ran. Twice. I never answered you."

"You answered."

"I didn't say anything."

"I know," Tolliver says.

Ahead of us the ruts run down toward a line of smoke standing straight up out of the trees, and he tells me the name of the mill we are about to pass, twice, until I can repeat it. So that when somebody asks me where I have come from, I will have somewhere true to say.

CHAPTER FIVE

The first person we pass is a woman with a goat.

She comes up the road in the other direction not an hour after we start walking, one hand knotted in a rope, the goat entirely uninterested in the arrangement, and I see her plate long before I see her face, riding in the air over her head at the exact height Tolliver's rides over his.

**[CARTER, LV. 8]**

She nods at Tolliver. Tolliver nods back. She looks at me for slightly longer than she looks at him, and her eyes go up and to the left, and then she is past us and the goat has won something and she is swearing about it, and my heart is going like I have been caught shoplifting.

"She read me," I say.

"Everybody reads everybody. It's the same as looking at a face." Tolliver does not turn his head. "You're going to have to stop doing that thing where you brace."

By the middle of the morning the road has become a road, packed and cambered and wide enough for two carts, and there are people on it. Not many. Enough. A boy driving four pigs. Two men with a barrow of cut stone who argue the entire time they are in earshot and the entire time they are out of it. An old man walking with nothing at all, going somewhere with the patience of a person who has already done the hard part.

**[HAND, LV. 4]**

**[MASON, LV. 14]**

**[PILGRIM, LV. 6]**

Not one name. Not one. Every plate on this road is a plain little word that tells you a job and nothing else, and I walk under my own borrowed word with my two fingers itching toward my throat, doing the arithmetic that Tolliver has apparently been doing since he first saw me. In a world where everyone covers, uncovered means one of three things. Stupid. Proud. Or not from here.

Around noon I smell it before I see it, and the smell is the thing that undoes me. Woodsmoke and animals and bread and a sourness underneath like a wet basement, and something frying, and I stop in the middle of the road with my eyes streaming, because for one whole second it is the alley behind Brewed Awakening at six in the morning with the bakery two doors down running its first bake.

Tolliver lets me stand there. He does not ask.

"Sorry."

"Come on."

Greyward is not a village.

He called it a village yesterday and I built something in my head with eight houses in it, and what comes up out of the fields is a wall. Not a castle wall. A working one, timber over earth, twice my height, running off in both directions until the land takes it, with roofs stacked up behind it and smoke standing over the whole thing in a hundred separate columns. There are two towers at the gate and men on both of them. Beyond the wall a bell starts up and then stops after three strokes, the way a bell does when it is telling people something practical.

"You said village."

"It's got a wall and no lord in it. That's a village." He does something to the set of my coat, tugs the collar of it closed at my throat, adjusts the way it sits on my shoulders. His knuckles brush under my jaw, and I look at the wall until that has finished happening. "Listen to me."

"I'm listening."

"At the line, everybody opens."

The queue is maybe thirty people long, carts and foot traffic separated, and it takes me a minute of watching to understand what he means, and then I cannot see anything else. There is a place ten feet short of the gate, marked by nothing I can see, and every single person crossing it blooms.

The plain little words go, all at once, and names come up in their place. A woman ahead of us who has been [WEAVER, LV. 9] for the whole hour I have been standing behind her turns into somebody's whole daughter, three lines of her hanging in the air, name and level and a word underneath that must be her holding, and she does not so much as glance up at it. She holds the fingers at her throat, the warden's eyes go up, the warden waves, and by the time she is six feet inside the gate she is a weaver again.

Thirty strangers, one after another, walking naked past two bored men and then getting dressed.

"They can make you," I say.

"Nobody makes you. You just don't come in." Tolliver moves us up two places. "It's older than the wall. Fifty men can hold a gate. Nobody can hold a road."

"And they'll see the gap."

"They'll see it."

"And then what?"

"Then I talk," he says, "and you look at me."

The line eats an hour and then most of another. My foot has gone from a pain to a heat that runs up the inside of my calf, and there is a smell coming off the wrapping now that I have decided to deal with after the gate. I lean on him. He lets me. Ahead of us the two masons go through, and the boy with the pigs, and then there is nothing between me and the mark on the ground except air.

"Now," Tolliver says.

I put two fingers to my throat and press until it goes soft, and I walk into Greyward wearing my own name.

The warden is a heavy man in his fifties with a strap of rank over one shoulder and the face of somebody four hours into a six-hour shift. His eyes come up, off Tolliver, over to me, and stop.

They stay stopped.

"Sir," Tolliver says, pleasant as bread.

The warden reads my three lines. I can feel him doing it. I have never in my life been so aware of the top of my own head, and I have to lock my knees to keep from putting a hand up there, and the only thing in the world holding me on the ground is Tolliver's forearm under my elbow.

"Level one," the warden says.

"She is."

"She's grown."

"She is that too."

"Origin's empty, son."

"It is." Tolliver says it like a man agreeing that the weather has been poor. "Skell's Holding took a fever the winter before last and the man who kept the book went with the rest of them. There's no book. There's no holding. There's about four of them left and she's the one who could walk."

I keep my eyes on the side of his jaw and I do not move a muscle, because he has just built a place out of nothing, given it a name and a season and a dead clerk, and he has done it at conversational speed without one flicker, and some cold clear part of me understands that he did not compose that in the last ten seconds.

The warden's mouth works. He looks at me again, at the coat, at the shorts under it, at the strip of shirt gone black around my foot. "She got no shoes."

"No."

"She walked in with no shoes."

"She did."

"From Skell's."

"From what's left of it," Tolliver says, and his voice has gone somewhere quieter and kinder, and it works on the warden the way it worked on me in the mud at the top of the hill. "Look at her feet, sir, and then ask me again if she walked."

The warden looks at my feet. Something in his shoulders lets go, and he reaches for a slate at his hip, and I am about nine seconds from being a person with permission to exist.

"Hold it open."

The voice comes from the left, from the gatehouse wall, where a man has been leaning in the shade for the whole time I have been standing here and I have not looked at him once.

He is not in the line. He is not in a uniform. He is somewhere in his thirties, dressed like weather, with forearms crossed and a hat pushed back and a beard three or four days past being a decision. There is a bow across his back the way Tolliver's is, except that where Tolliver's looks like a thing he owns, this one looks like a thing that has been repaired more than once and will be again.

He is unmasked.

**[EIRAN HALE, LV. 26]**

His name is just hanging there in the middle of the day in front of everybody, and after an hour of watching thirty people get dressed as fast as they could, it hits me like somebody walking through a church whistling.

"Hale," the warden says, and there is something in it I cannot read, but he does not tell him to move along.

Hale comes off the wall. He does not hurry. He stops at a distance that is exactly polite and looks up over my head, and I stand there with my two fingers at my throat and every syllable of my name held open in the air, and he takes his time.

Nobody has taken their time. Not one person in that whole line. Even the warden read me in a second and a half like a man checking a stamp.

The heat goes up my neck and into my ears. It is not fear. It is the specific, particular, incandescent humiliation of the customer who reads the whole menu board while nine people wait behind him, and it burns off some of the terror, and I lift my chin and I look right at him while he does it.

He notices. His eyes drop off my plate and onto my face, and if I got anything out of that it does not show.

"How old are you?"

"She's..." Tolliver starts.

"I asked her."

The world holds still. Every rule I have been given in a day and a half says look at Tolliver and let it be rude, and I intend to obey it right up until I don't.

"Nineteen."

Hale takes that. He does not glance up again, and somehow it is worse that he does not need to, because we both know what the second line over my head says and we both know that a nineteen-year-old who has never done one single thing does not exist.

"Somebody's kept you very safe," he says.

There is no question anywhere in it, so there is nothing to answer, and I stand in a gateway with my mouth open like a fish while the pigs go on making noise inside the wall.

He turns away before I can put anything together. "She's fine, Bertran. Let her in."

The warden scratches the slate and waves us through, and my fingers come off my throat, and my name goes down out of the air, and I am inside.

Behind us, not quietly, Hale says: "She's yours, then."

"She's mine," Tolliver says.

And we are ten steps into Greyward before the front of my brain catches up with the back of it, and by then it has already been sanded down into something I can carry, because a man just stood between me and a gate and I have nowhere else on this planet to go.

Greyward from the inside is a great deal of everything at once. The street is packed earth gone hard and shining, running between buildings that lean their upper floors out over it until the sky is a strip. There are chickens. There are three separate people shouting prices at me personally. A dog with no plate at all trots past with something in its mouth that I choose not to examine, and the smell of the tannery finds me from four streets away and stays.

And over all of it, everywhere, at head height, in every doorway and window and stall, the plain little words. Baker. Hand. Carter. Hand. Cooper. Widow. Hand, hand, hand.

Not one name in the whole town.

Tolliver spends money on me for two hours.

That is the part I will remember. He puts me on a stool in a room off the market that smells of vinegar, and a woman with [MENDER, LV. 22] over her head cuts my wrapping away and makes a noise about what is under it, and I look at the ceiling while she does whatever she does. It takes a long time and it hurts more than the cut did. When she is finished the skin along my arch is closed and shiny and hot, a new pink seam where the split was, and my leg feels like somebody has taken a weight off it that had been there so long I stopped believing in it.

"You should have closed that the first hour," she says.

"I know," I say.

Tolliver counts small metal into her palm. Not a lot. Enough that she counts it back.

Then a stall for boots, and he pays. Then a woman with a chest of secondhand clothes, and he pays, and a skirt and a shift and a woolen thing with sleeves come out of it, none of which fit, all of which are dry. Then bread, and something hot in a folded leaf, and he pays for that too, and I eat it standing up in the street with tears going down my face and I do not care in the slightest who is watching.

I have no money. I have no way to get money. I have nothing whatsoever to trade except a nineteen-year-old body and a level one plate, and every single thing I have eaten or worn or bled on since yesterday morning came out of this man's hand.

I do the arithmetic. I am not stupid and I have never been stupid. I just do it very quietly, off to the side, and then I put it away.

The room is above a tavern at the end of a street that gets no sun. It has a bed with a straw tick, a shutter that closes, a stub of candle, a basin, and a door with an iron bolt on the inside of it. He pays for that too. He tells me to sleep, and that he will be back, and that I should not go down into the taproom, and then his boots go away down the stairs and I am alone for the first time in a day and a half.

I stand in the middle of the floor for a while.

Then I sit on the bed, and it holds me up, and that turns out to be the thing that does it. A bed. A roof. A door. My mother is somewhere with a police officer in her kitchen, holding her own wrist. My father is driving. There are two cold eggs going hard on a desk in Kansas City and eleven people who watched me go down, and not one of them will ever know, not ever, not if I live to be a hundred in this place.

I put my face in the blanket and I make a sound I have never made before.

It does not last long. I have no idea how these things are supposed to go and mine seems to be short, and when it is finished I sit up and wipe my face on the sleeve of somebody else's woolen thing and look at what I own.

The shirt is on the floor where I stepped out of it. Mud to the shoulders, the hem hacked off, CRIT HAPPENS mostly gone, the whole thing smelling like the inside of a dead tree.

I pick it up, and fold it, sleeves in, the way my mother folds things, and put it under the straw tick at the head of the bed.

Then I bolt the door.

The iron is heavier than it looks and it goes across with a sound that I feel in my teeth, and I stand there with my palm flat against the wood and understand that this is the first thing since the clearing that is between me and the world.

The knock comes maybe an hour later.

I am off the bed and across the room and my hand is on the bolt before I have decided anything at all.

"It's me," Tolliver says through the door.

"I know," I say, and let him in.

CHAPTER SIX

The bolt is open when I wake up.

That is the first thing I have, before the light or the ache in my hip from the straw tick or the sound of somebody below us dragging benches across a floor: the iron is drawn back in its bracket, and the door is shut, and Tolliver is sitting on the boards beside it with his boots on and his pack across his knees.

I sit up too fast. "You opened that."

"Went out. Came back." He does not look up from the strap he is working. "You want to know what should be bothering you about that."

"That you can."

"That you slept through it." He pulls the strap through and sets it. "Both times."

The room in daylight is smaller and browner than it was by candle. There is a stain on the ceiling the shape of a bad country. My foot has stiffened overnight into something I am going to have to negotiate with, and when I put it down on the boards the new seam along my arch takes my weight and gives it back, hot but holding, which the mender told me it would do and which I did not believe until now.

The boots he bought me at the stall by the market are by the wall. They are somebody else's boots and they were somebody else's before that. They are also the first shoes I have had in three days, and I put them on before I do anything else, including think.

Tolliver stands, and the room gets appreciably smaller.

"I'll be out today," he says.

I wait for the rest of it. Where. How long. Whether out means the market or the road or something with a name. He crosses to the sill instead and counts small metal onto it, four of the thin ones, laid down separate so that I can see there are four.

"That's bread and it's a bowl of something at midday and it's enough left over that nobody thinks you're desperate," he says. "Don't spend it all in one place, and don't let anybody see the rest of it after you've paid."

"Tolliver."

"Bolt it behind me. If somebody knocks and it isn't my voice, you don't open it, and you don't answer either, because answering tells them there's a woman in here on her own." He shoulders the pack. "The taproom's fine in daylight. Don't sit with your back to the door."

"Where are you going?"

He stops with his hand on the latch, and for a second I think I am going to get something, because the pause has the shape of one of his pauses, the kind where he is pricing what a piece of information costs him.

"Out," he says. "I'll want you here at dark."

And then his boots are going down the stairs, and the taproom takes him, and I am standing in a rented room in borrowed clothes looking at four coins on a windowsill and waiting for somebody to tell me what happens next.

That is what does it. Not the coins. The waiting.

Because I am doing it the way I do it now, automatically, the way my hand goes to my pocket for a phone that has not existed for three days. One night alone in that forest taught my body a single lesson and it learned it all the way down: the man knows things, and I do not, and if I stand still and keep my mouth mostly shut he will hand me the next thing I need before I have finished working out that I need it. Water before I asked. Cloth before I asked. A wall, a mender, boots. A dead clerk in a holding that has never existed, invented at conversational speed in front of a gate warden while I stood there with my name hanging over my head like a flag.

I do the arithmetic again, since I have nothing else to do with the morning. Mender. Boots. This skirt, this shift, this woolen thing with sleeves that hangs off me like it was cut for a bigger woman, because it was. Bread. Whatever was in that folded leaf. The bed under me. The roof over that. The door I bolted last night and felt so proud about, which he opened and closed twice while I slept through it with my mouth open.

Every single item on that list came out of one man's hand, and I have nothing to put against it except a nineteen-year-old body and a level one plate.

I am not going to declare independence. It is nine in the morning in a world with no plumbing, my foot has one day of healing on it, and I would not survive a night outside that wall on principle. Principle is for people with options.

But there is a difference between all of it and some of it, and I sit down on the edge of the straw tick to work out where the smallest possible version of that difference lives.

One thing. That is all it has to be. One thing today that I buy with money that came from me.

I reach under the tick and find my shirt where I put it, folded, sleeves in. The mud has dried and gone pale in the creases. CRIT HAPPENS is down to CRI HAPP and a shadow. I do not take it out. I just put my hand on it for a second, the way you touch a doorframe on the way past.

Then I leave the four coins on the sill, exactly where he set them down, exactly four, and I go out to find work.

---

Greyward in the morning is a town with its sleeves up.

Last night it was noise and smell coming at me sideways while I concentrated on staying upright. Today the street is somebody's job, all of it, in every direction. A woman throws a bucket of gray water into the gutter without looking and a man walks through where it went without looking either. There are two boys carrying a door. A cooper's yard has four barrels out front and a fifth coming apart under a mallet, and the whole street smells of wet oak and old piss and bread, in bands, so that walking down it is like scrolling.

And over all of it, the plain little words.

**[BAKER, LV. 12]**

**[HAND, LV. 6]**

**[COOPER, LV. 30]**

I stop being frightened of them somewhere around the third street, which is not the same as getting used to them, and start doing something else with them, which is counting. Because that is what I do. Six years of raid logs and two years of a register drawer and my brain wants columns, and the columns it makes this morning are these: everybody in this town is inside the machine, the word a person picks lines up with what they are for closely enough to plan around, and the number after the word is not decoration, because the number changes.

Hand, six. Hand, nineteen. Hand, four.

Hand is everywhere. Hand is on the boy walking pigs and the man rolling a cask on its rim and the girl slinging washing over a line above the street, and Hand does not say a trade, it does not say what you were apprenticed to or who your father was, and if there is a word in this town that means I have got two arms and I will do what you tell me for money, that is the word.

That is the entire theory. It takes me most of an hour to find somewhere to test it, because I do not know where anything is, and asking gets me pointed by people who are already walking away, and twice I end up somewhere that is clearly a yard and clearly nobody's business but the people in it. Then I follow a wagon.

It ends at a store by the north wall, a long building with a plank running up into a loft door, and there is a crew of five moving sacks off the wagon bed and up the plank in a slow rotation that does not stop for anything, one man on the bed, three on the plank, one in the dark of the loft.

The one on the bed is broad and gray-bearded and has the flattest word over his head that I have read yet.

**[HAND, LV. 21]**

I wait for the rotation to come round and put me in front of him, because standing in the middle of it would be like standing in a fire lane, and when he glances down I say, "Are you taking anyone on?"

He looks at me for about as long as it takes to look at a bill you are not going to pay.

"No."

"For today."

"No."

The rotation goes past me. A sack goes up. Nobody looks at me.

Here is the thing about two years at Brewed Awakening: I have said no to eleven thousand people. I know exactly what no sounds like when it is the end of a conversation and I know what it sounds like when it is the first price.

"You've got five men and a full wagon and a sky that's going to open on you," I say. "I'll do an hour for nothing. If I'm useless you've lost an hour of nothing."

He looks at me properly for the first time, and then his eyes go up over my hair the way everybody's do, and whatever he reads up there, he does not do with it what the warden did.

"Sacks are on the bed," he says. "Don't stand on the plank when it's got two on it."

I am so pleased with myself that I nearly say thank you twice.

The sacks are milled barley, half my height, tied at the neck, and the first one comes off the bed and onto my shoulder in a way that hurts less than it should because I am doing it wrong and my body has not yet been informed. Then I get four steps up the plank with it, and the plank flexes, and my whole plan stops being a plan.

Heavy I know about. I have carried a keg of syrup up the stairs behind the shop and I have wrestled a mattress into a fourth-floor apartment with my father on the other end of it going slow, slow, slow. This is the load and me arriving at a total. There is no more of me anywhere. My arms quit, both of them, at the same time and without any drama at all, and the sack comes down off my shoulder into my hands and I go with it onto one knee with the whole thing across my thighs, and the plank bounces under somebody's step behind me.

"Off," a voice says.

I try to stand with it. That is the part I will be embarrassed about later. I get halfway up, I change my grip, I try to lever it against my hip the way the man on the bed does it in one motion like he is closing a door, and my knee goes down on the wood again.

Then a hand comes past my ribs and takes the sack out of my arms.

She is smaller than me. She is a head shorter and forty at the least and there is nothing about her arms that would make you look twice at them in a queue, and she takes the sack off my thighs with one hand under the belly of it, turns, puts it on her shoulder, and walks up the rest of the plank without adjusting anything.

Her word hangs over her the whole way up.

**[HAND, LV. 14]**

I stay on my knee on a plank in the middle of a working town with my arms shaking and my ears going hot, and I look at that number for as long as it takes her to get to the top, and something arrives that I have not had yet in three days.

Until now, level one has been a thing over my head. A number that made the warden's mouth work. Something other people read and made faces about, a story every one of them writes differently and none of them writes well.

It is in my arms now.

The woman comes back down the plank. There is no contempt anywhere in her, and no interest either, and I would take contempt.

"How," I say.

She looks at me. She looks at the sack going up on the next shoulder, and at my hands, and I watch her try to find the beginning of an answer to a question nobody has ever asked her.

"You just do," she says. "You'll get it."

"Get what?"

But she is already reaching past me for the next one, and the man on the bed says something about the plank, and the rotation closes over the gap where I was standing the way water does.

I get off the plank. Nobody says anything about that either. I stand in the yard for a minute working my fingers open and shut and thinking about the two men at the gate yesterday with a barrow of cut stone between them, arguing the entire time they were in earshot and the entire time they were out of it, cut stone, up a road, arguing.

I have not eaten since the thing in the folded leaf last night and I left four coins on a windowsill this morning like a woman in a story. That is real and it is not the answer. She is a head shorter than me and she took it one-handed after four hours of doing it.

Does the number make her stronger. Does the word do it, is a Hand a Hand the way a mender is a mender, is there something under the panel behind the little list of plain words that I have never been shown because nobody has ever needed to show anybody. Is it years. It could just be years.

I do not know. There is nobody in this town I can ask, because the question itself is the thing that gives me away, and the one person who answers my questions has gone out.

So I put that where I put everything, and I go back into the market to sell my brain instead.

---

The market is two long rows and a middle, and the middle is where everything goes wrong, because that is where the people are who have not decided yet. I walk the whole length of it once, and by the end of the row I have stopped looking at goods and started looking at queues.

Because a queue tells you everything. A queue tells you who is understaffed.

The stall I stop at is dry goods, which in a world without plastic means about forty separate small hells in one place: salt in a covered tub, thread on cards, needles in paper, tallow, hard soap in bricks, dried peas, buttons of horn and buttons of bone, small nails in a bin. There is a woman behind it built like a fence post with a scale at her elbow and a wooden till box under her hand.

**[SELLER, LV. 19]**

There are five people in front of her and one of them is a man with a cart of salt who wants to be paid and gone, and she is trying to weigh out peas for a woman who has changed her mind twice while a boy at the end of the table has been holding up two cards of thread for long enough that he has stopped believing in adults.

I go around to the end of her table and stop beside it, out in the open where the man with the cart can see me and she can see me and neither of them has to wonder what I am doing.

"Do you want the salt off him or do you want the peas," I say.

She turns her head about four inches.

"I've done two years of this," I say. "Not salt. This." I put my chin at the five people and the boy with the thread. "Give me the ones who already know what they want and tell me your prices and you can go and argue about salt."

Everything I have is in the ten seconds after that, and I know it, and what comes up in me while she looks at me is the thing that used to come up when a manager watched me on bar during a rush, which is the good kind of sick, the kind with *watch this* underneath it.

"Peas is two the pound, four the three," she says. "Salt's off the tub, a bit the scoop, don't heap it. Thread's a bit the card, needles is three the paper and they walk, so they don't leave your hand until the money's in it. Soap's four. Nails is by the handful and the handful is mine, not theirs." She has already turned toward the salt man. "You touch that till box and I'll have your wrist."

"Fine by me."

"A piece when I close the middle out. I don't feed you and I don't lend you anything."

I have no earthly idea whether a piece is a fortune or an insult, and *do not accept a first price* is a rule I have been carrying around for a day and a half like a stone in a pocket, and I accept the first price in something under two seconds.

"What's the boy want."

"Two cards of thread and he's got the money in his fist and he's been standing there since I got here."

Her mouth does something small and she puts it away again. "Ordway," she says, which turns out to be her name and turns out to be how I get called for the next two hours, along with several other things.

The first ten minutes are a disaster held together with string. The prices are simple and the coins are not, and coins are the whole job. The little ones are copper and thin and they come in one size, and I decide inside the first two minutes to call them bits because I have to call them something. The fat dull ones are worth more and I do not know how much more until a woman buys soap and salt and gets change and I watch Ordway's hand make it, and then I do the sum backward and get eight.

Eight bits to the fat one. Bits and pieces. I do not have time to be pleased about that and I am pleased about it anyway.

After that it is a job. It is such a job. It is the same job. A man wants a bit's worth of salt and wants to know if I will heap it, and the answer is no, and he tries the answer again on me in a different voice, which is a thing men do at counters in every universe that has counters. A woman with a baby on her hip wants three papers of needles and I get all three into her hand and her money into mine in one exchange because she does not have a spare hand and I can see that she does not. The boy with the thread turns out to be buying for his mother and comes back forty minutes later for a second errand and asks for me specifically, which is the first time anybody in this world has asked for me specifically.

I keep the queue in order. I hold four prices and two people's changes of mind in my head at once and I do not lose the salt scoop, and when a man in a good coat wants to pay for soap with a bit that has been shaved down one edge until it is a crescent, I put it on the table in front of him and put my hand next to it and wait, and he laughs and takes it back and gives me a good one, and behind me Ordway says nothing at all, which I understand perfectly, because saying nothing was the highest thing my manager had.

The salt man wants to be paid for eleven scoops and Ordway is elbow-deep in a card of buttons, and I count the tub with the scoop myself and get nine, and I say so, and he says the tub settles.

"Then it settled two scoops on the road," I say. "Nine."

He looks at Ordway. Ordway does not look up from the buttons.

"Nine and I'll take the broken card off you at a bit," I say, and it turns out his rules work perfectly well on somebody else's behalf, and it turns out I am going to be using that man's lessons all day whether or not I am spending his coins.

The salt man takes nine and the bit. Ordway sells the broken card twenty minutes later for two.

Somewhere in the middle of the second hour the rush thins and I straighten up and my back informs me about the plank, and I look down the row at all of it, the boards and the scale and the small covered tub and the till box, and I have to put both hands flat on the table for a second.

Another universe. Actual magic. Words hanging in the air over people's heads. Somebody's whole daughter turned into a Weaver at a gate. A thing with a knee that bends backward walked past my tree in the dark and went away.

And I am running a register.

The laugh comes up out of me before I can stop it and I have to turn it into a cough, and Ordway looks over and I say, "Nothing," and she says, "Then look at the peas," and I look at the peas.

---

She closes the middle of the day out and starts putting things away, and the market noise goes down a step all along the row at the same time, the way a room does.

"You'll do," Ordway says. "Tomorrow, if you want it. Early. I don't hold a place."

"I want it."

She reaches under the table for the till box. I stand there with my hands hanging and my shoulders hot and my foot throbbing in the new boot, and I hold my hand out flat, because that is what I have been waiting two hours to do.

She counts out of the box, and her fingers stop with the coin still in them.

She is not looking at my hand. She is looking about two feet above my hair.

"Who receives for you?"

"Sorry?"

"Who receives." She says it patiently, which I have learned by now is the sound of somebody discovering that I am missing something enormous. "You're Household, girl."

Something goes cold in the middle of me while everything else stays exactly the same temperature.

"I did the work," I say.

"You did. You did it better than the last two I've had beside me and I've just asked you to come back tomorrow." The coin stays where it is, between her thumb and her finger, six inches out of the box and a foot short of me. "Who's your house?"

"Can you not just give it to me?"

"No."

"I earned it."

"You did," Ordway says again, and she means every word of it. "And it's not yours to take off my table, and it's not mine to put in your hand, and if I do it, then some day this week whoever answers for you comes and stands where you're standing and asks me what I paid you and how long you were behind my table and whether I knew you were out without leave. I've had that man at my table. He had a stick." She sets the coin down on the boards in front of her, where I can see it. "It's not you I'd be paying. It's your house I'd be taking from."

The market goes on doing what markets do. Somebody two stalls down is laughing at something. A dog has got in among the peas.

"Hold it, then," I say. "Keep it for me."

"Until who comes for it?"

I have nothing. She watches me have nothing and does not enjoy it.

"Mark it somewhere. On a slate. That it's mine."

"That is what I'm telling you a slate would say." She wipes her hands down her apron. "It would say the wage is owed to your house."

The word goes through me again with the whole weight it has been putting on since I picked it out of a short list of plain words in a cart rut, and everything I understood about it yesterday turns out to have been the front of it. *Household. That somebody's answerable for you. Out here that beats being nobody's.* He was not lying. He saves the lying for other people. With me he just hands over the true half.

I put two fingers toward my throat before I know I am doing it, and I stop, because I do not have the first idea what I would do after that. Change the word to Hand in front of a woman who has already read it. Stand here having become somebody else between one breath and the next while the warden's slate at the gate still says what I walked in as. I do not know what changing it in front of her would cost me. I do not know what the little list is or who wrote it or whether the words in it come off as easily as they went on, and I have been in this world for three days, and the only person who has ever shown me the inside of my own throat is out.

My hand comes down.

"Whose Household?" Ordway says.

The coin is on the boards eighteen inches from my fingers. Dull, fat, worth eight bits, and I know exactly what eight bits buys because I have spent the morning telling people. It is a loaf and a bowl of something and a candle of my own. It is the one thing.

I have carried one sack four steps up a plank, which is all the carrying there is in me. I have counted a tub of salt and caught a shaved coin and held four prices in my head at once, and a boy came back through a market and asked for me by no name at all because I was the one who was quick.

All that is left is being handed it.

"Tolliver," I say.

Ordway's hand stops on the way to her apron.

It is a small thing. It is smaller than what the warden did and much smaller than what happened in the gateway when a man with his name in the open air took his time reading mine. Her eyes come off the space above my head and land on my face, and stay there a beat longer than they have stayed on it all morning.

"Tolliver," she says.

"Yes."

The dog gets driven out of the peas. Somewhere behind me a shutter goes up on a hinge that wants grease.

Then she picks the coin up off the boards and puts it in my hand, and closes my fingers around it with her own hand over the top of mine, which is the only time she has touched me all day.

"Early," she says. "I don't hold a place."

And she turns to her scale, and a woman is already asking her about soap, and the day just keeps going.

I get about ten steps down the row before I stop in the middle of the middle, where the people are who have not decided yet.

I do not know one thing about what he is in this town. Not how long he has been coming here, not who knows him, not what he was doing on that road in the first place. I have said his name to one woman at one dry goods stall in a town with two rows and a middle, and a coin that was not going to move came off a board.

I am not building anything out of that. One woman is not a pattern; I have watched a raid fall apart because eleven people decided one number meant something. She might have known his mother. She might owe him money. He might have bought soap.

I put it in the folder. That is where the holding is now, the one where the invented dead clerk went, and *I read yours from the bottom of the hill*, and *you answered*, and the folder is not thick but it has stopped being empty, and the whole way down the row I am aware of the shape of it.

Then I open my hand.

The coin has gone warm off Ordway's palm and mine. It is thinner than it looked on the boards and there is no word on it anywhere, only a stamp, a crest or a beast or a face worn down past telling. Eight bits. Bread and a bowl and a candle, and enough left over that nobody thinks I am desperate.

There are four bits lying on that windowsill. This is twice all of them.

It is mine. I carried what I could carry and I counted what I counted and nobody handed me one bit of it.

And the only way it got into my hand was his name.

CHAPTER SEVEN

I spend the first bit on bread.

The woman selling it takes my piece, gives me seven thin coins and a roll still hot enough to sting through its crust, and does not ask whose permission I have to eat. I stand beside her oven and wait for something else to happen. A question. A look at my plate. Somebody coming down the street to inform me that actually, the bread belongs to Tolliver too.

"You're in the way," she says.

I move.

The roll is gone before I reach the corner. I eat the crumbs out of my palm, and by the time I get back to the tavern I am furious in a much more useful way than I was in the market. Apparently blood sugar is a prerequisite for revolution.

Inside, a woman with a red cloth tied over her hair is scraping something off a table with the edge of a knife. Her plate says **[KEEPER, LV. 17]**. I have passed her twice without registering anything except the fact that she is large and I am in her way, and this morning she watched me go out without asking where.

I stop at the end of the table.

"What's a room cost?"

She tests the patch with her thumb. "Which room?"

"Mine. Upstairs. At the back."

"Four bits a night. Food's separate."

I have seven bits in my fist. The knowledge rearranges the entire building.

"How many nights are paid?"

Her knife stops. She looks at me, then at the ceiling, as if she can see the room through it. "Tonight. Leaving in the morning, he said."

Of course he said.

I tuck one of my coins into my other hand. "Can I buy a candle?"

"Half a one."

"Fine."

She gives me a short yellow length with a kink in its wick. I take it upstairs with six bits left, and shut the door, and put the candle on the sill beside Tolliver's four coins.

The room looks exactly as it did when I left it. It is irritating how often the world does that when I have become a different person.

I take my boots off. There is a red place at the back of the right heel and a hot pressure along the healing cut on the left, but no blood inside the boot. My feet have survived my economic policy. My shoulders are less enthusiastic.

The six bits go under my folded shirt beneath the tick. His four stay on the sill. I sit down on the bed with my back against the wall and two fingers at my throat.

It takes longer this time. I am pressing too hard. When I ease off, the skin gives, the room recedes, and my name opens in front of me.

**[MAYA SZCZEPANIAK, LV. 1]**

**[ORIGIN: ]**

I make myself leave the empty line alone.

The place Tolliver showed me is beside the name, though beside is not quite right. I can look at it with my eyes and see nothing. I can attend to it and feel an edge. The first time he told me to reach, I tried moving my free hand through the writing, and he caught my wrist before I could do it twice. Now I hold still and think about that edge until the list opens.

Traveler. Laborer. Pilgrim. Hand. Household.

Other words extend beyond them, dimmer, as though there is more of the list than I have space to want at once. I do not touch any of them. Household sits brighter than the rest, and below the list is a little hooked mark I do not recognize until I think about going back and it becomes obvious.

I go back.

For a moment I am unreasonably pleased. Look at me. Navigating one menu. My parents would be so relieved.

Then I sit with the name and the number and try to find another edge.

This is how you learn software when there isn't a tutorial. You stop clicking things at random, decide what you want to know, and work outward. Also you complain on the internet, but that part of my process has suffered a setback.

I attend to the one.

Nothing happens. I hold it in my attention the way I held the list, wait through the urge to move my fingers, and something opens beneath it.

**[PROGRESS: 7 / 10]**

**[RESERVE: 3 / 3]**

**[RUN: UNSET]**

I read the lines three times.

Seven out of ten. I have seven of something. I might have arrived with seven. I might have earned them by surviving the forest or carrying half a sack of barley or convincing a salt merchant that nine is less than eleven. I have absolutely no idea, which is a substantial improvement on not knowing there was a question.

Reserve looks like a resource. Run looks like the question Tolliver asked me on the hill.

I try the seven. Nothing. The ten. Nothing. Reserve unfolds into a ring of three pale marks, and when I pay attention to one, I become aware of my own breathing in a way that makes me stop doing it properly.

I let go. The ring shuts.

"Okay."

Run does not offer a list. It offers a single word.

**[UNSET]**

I wait. I try again. I consider explaining that I have years of relevant experience and excellent references.

Unset.

My fingers have started to ache, so I take them off my throat, and the room comes forward around me. Nothing follows. No quest window. No congratulations. There is a bench dragging downstairs and a fly repeatedly discovering the shutter.

I sit there looking at the air where the numbers were.

When I crawled out of that tree, I thought the machine had forgotten me. This afternoon it is keeping a score I have not learned to read.

I get the candle, set it in the old stub's little dish, and use the back of my thumbnail to scratch three short lines into the soft side of the wax. Seven. Three. Unset. I give the last one a crossbar so I know which is which.

It is not much of a notebook. It is mine.

---

He comes back while there is still daylight on the opposite roof.

I hear him on the stairs and know the step before he reaches the landing. Knowing it makes me angry. Being relieved makes me angrier. I have been sitting here for an hour practicing how to be a person who does not need him, and my whole body goes quiet when his knuckles touch the wood.

"Maya."

I open the door.

He has a paper parcel in one hand and rain in his hair, though I have not heard rain. His coat smells of cold air and a sharper smoke than the tavern's. For a second I remember his shoulder under my hand in the forest so completely that the room seems warm by comparison, impossibly safe.

Then he looks at the sill.

"You ate?"

"Yes."

He looks at the candle.

I shut the door behind him. "Where are we going tomorrow?"

The parcel stops halfway to the bed.

"Who told you that?"

"The woman you told."

He sets it down. "I said we might leave."

"Then she misunderstood you. So do I, quite a lot."

For the first time since he found me, he has to decide where to put his hands. He settles on taking his coat off, which gives him several seconds and a reason to look somewhere else.

There is only one stool. He leaves it where it is and leans against the wall beside the shutter.

"What happened?"

I had a speech. It had a beginning and a middle and a part where I did not sound nineteen. All of it goes when he asks that, and what comes out is, "I got a job."

His eyes move to my foot.

"Selling things," I say. "I tried carrying things. That did not work. Selling did. I was good at it."

"I believe you."

"Don't do that."

He stops.

I press my palms against the sides of my skirt. "Don't make this easy to get through before you've heard it."

The room is quiet enough that I hear the parcel settling on the blanket.

"All right," he says.

"Ordway wouldn't pay me because I'm Household."

His mouth tightens at the name. Only at the name. I have been watching him too closely all day without him even being here, and now that he is, it is almost embarrassing how much there is to watch.

"She paid you," he says.

"After I told her who I was with."

He looks at the candle again.

"Why?" I ask.

"Because she knows me."

"I got that far by myself."

He rubs a hand over his face. He is tired. I did not know he could look tired until now; I thought he merely had different kinds of patience.

"I collected a debt at her stall last autumn. For a house that hired me. Her husband had signed for winter stock and died before he sold it."

I look down at his hands. He follows my eyes.

"I didn't touch her."

"Did you have a stick?"

He says nothing.

I can hear Ordway again. *I've had that man at my table.* I supplied a stranger when she said it. Some other man, in some other coat, a person convenient enough to dislike without having to remember him cleaning my foot.

"What did you take?"

"The stock the house had paid for."

"That's a very good way to answer that."

His jaw moves. "Half her stall."

I sit on the bed because standing has become a performance I cannot afford. The parcel tilts toward me. Something inside smells of onions.

"Did you tell her to pay me?"

"No. I haven't seen Ordway today."

I cannot prove that. It matters that I notice.

"So she either thought you'd come and take it if she didn't, or she wanted me to have money because she knows what happens when you do."

He glances toward the door, then back. "You'd have to ask her."

It is the first useful answer he has given me all evening.

I pull the parcel closer without opening it. "Does choosing Household make me yours?"

"No."

The word comes quickly enough to hurt.

"Then why did she—"

"Because people believe plates. A word can be changed. A wage dispute can't be wished away when a house comes to collect. She didn't know what was underneath yours."

"Neither do I."

He looks at me then, properly.

"There's no bond in your origin," he says. "No holding. No house. I couldn't put one there by telling you to pick a word."

"But you could tell a gate warden I was yours."

"I stood answerable for you."

"And forgot to explain the difference."

He pushes away from the wall, gets as far as the stool, and stops behind it with both hands on the back. For a moment there is something hard and unfamiliar in his expression. I wait for the anger. Some part of me is already preparing an apology for causing it.

"Yes," he says.

I do not know what to do with that, so I unwrap the parcel. Two thick wedges of pie lie inside, pastry gone soft where the onions have soaked through. I want one badly enough that my mouth aches.

"If I eat that, am I agreeing to something?"

"No."

"If I stay in this room?"

"No."

"If I change my plate?"

He takes longer. "The word won't clear the entry at the gate. If Bertran stops you and you're Hand, he'll ask where your household went. If you tell him there never was one, he'll want to know what else I lied about."

"There it is."

"It's a real problem, Maya."

"I know. I'm the one in it."

The pie burns my tongue. I eat it anyway.

He finally sits, leaving the other wedge untouched. There is nowhere in the room for him to sit far from me, and his knee is close enough to mine that I have to work at ignoring it. I hate that this continues to be true. I would like anger to be a more thorough activity.

"Tomorrow," I say around the last bite. "Use place names."

"Rook House. South road. Two days if we can get you on a cart."

"What is it?"

"A company holding. Warehouses, fields, workshops. They take people without an origin and put them in a book. Food, a bed, training in a run. Work in return."

"For how long?"

"Depends on the terms."

"Terms you know?"

"Terms they'd offer you."

"Do they know about me?"

He watches my face. "A factor here does. I spoke to him today."

My hands go cold around the paper.

"How much?"

"That you're unheld. That you're grown. That your level is one."

"My name?"

"Your first."

I set the paper on the bed very carefully. "What do you get?"

He could lie. He has the room for it. He could make the whole thing into another kindness and I might sit here and want to believe him badly enough to manage it.

"A finding fee. If you enter."

"How much?"

"Six pieces."

Forty-eight bits. Six mornings with Ordway, if she lets me keep coming. Twelve nights in this room.

I look at the four coins on the sill.

"Were you going to tell me?"

"Yes."

"When?"

He has no immediate answer to that one.

I wipe my hands on the paper. "I work tomorrow."

"Maya."

"I told her I'd be there."

"A stall won't get you an origin."

"It got me a candle. I enjoyed the experience. I'm going to repeat it."

He looks tired again, and young enough that I can imagine him being tired of something without knowing what to do about it. The sight is dangerous. I have a lot of room for him to be sorry in, and he has not actually said that he is.

"Stay in town a day," I say. "Tell your factor I haven't agreed to anything. Find out the terms. All of them. I'll read them."

"You read?"

I look at him until he looks away.

"One day," he says.

It is not permission. I have to remind myself of that twice.

---

He eats the second wedge while I light my candle downstairs, cupping the little flame all the way back up. When I return, he is on the floor beside the door again, his pack open. There is a square of leather in his lap and a bent needle between his fingers.

I put the candle on the sill.

"What's reserve?"

He nearly sticks himself.

That is worth the price of the candle all by itself.

"You opened your measure."

"I pressed things. Eventually the universe rewarded initiative."

He puts the needle away. "How much?"

"Three."

"Full?"

"Three out of three."

He nods, thinking, and for a moment we are back on the road with him deciding how much of an answer I can use. I lift a hand before he begins.

"I want to learn it. I don't want you to do something for me and explain afterward that I would have made the wrong choice."

He looks at my raised hand. "Give me the basin."

"Tolliver."

"It's a lesson, Maya. I need something you can drop."

I get the basin.

He makes me sit on the stool with it on my lap and my boots out of the way. It holds perhaps an inch of cold water left from washing this morning. He has me lift it with my right hand, fingers hooked under the rim, until the weight makes my wrist pull.

"Hold that."

"I've established I can carry crockery."

"Then we're starting with a victory. Keep your elbow where it is."

He kneels in front of the stool. His hands stay on his own knees. He tells me to open my measure with the other hand and keep my attention on the full ring under reserve.

The basin begins to shake before I have the ring open.

"That's your arm doing it," he says. "Now find the other weight."

"Very clear. Excellent tutorial. Five stars."

"Close your eyes."

"Will that shut the thing?"

"No."

It doesn't. The letters remain in a darkness that should be mine alone, and my stomach turns over. I open my eyes immediately.

He waits.

"It's still there," I say.

"Yes."

I look at his face, his actual face, which is irritatingly close and not amused at all. "That doesn't bother you?"

"I've never known it not to be."

Of course he hasn't.

I close my eyes again.

The reserve sits beneath my attention, somewhere inside the ring and somewhere lower than my ribs. Looking for it directly makes it recede. Listening is closer. The basin shakes, cold water touches my wrist, and I can feel every muscle I am using and, beneath them, something I have not used yet.

I reach for it.

The basin rises so sharply that the water slaps me in the chin.

"Fuck!"

His hand closes over the rim before I can pitch it into his face. Water runs into my sleeve. I stare at the bowl between us, at my arm holding it, at the plain impossible absence of effort.

The letters change.

**[RESERVE: 2 / 3]**

Then the weight comes back, all of it, and he helps me lower the basin onto my knees.

For several seconds I cannot say anything.

He takes his hand away.

"Again?" I ask.

"You've got two left. Save them."

"How do I get them back?"

"Food. Rest. Time. Usually a measure like yours fills before morning. Longer if you're ill or you keep spending it."

"Usually."

"I haven't taught many people who started at nineteen."

"How old were you? When you learned."

"Six. My mother put a basket in my hands and kept adding turnips."

"And how old are you now?"

"Twenty-two."

Three years. He has three years on me, and sixteen years of knowing where the extra strength lives. I look at the basin and try to separate those two things.

I look at my arm. It is my arm. Same freckles, same short nails, water dripping off my elbow onto somebody else's skirt.

"The woman with the sack," I say. "She was fourteen. Her level. She picked it up with one hand."

"Could be reserve. Could be her run. Could be both. A number won't tell you what a person's spent it learning."

"And I don't have one."

"Not yet."

"Can I choose one without a house?"

"Yes."

I look up.

He holds my gaze this time. "Someone needs to show you the work. You need to understand enough of it for a run to take. A house makes that easier. It doesn't make it possible."

I set the basin on the floor, very slowly, with ordinary muscles.

The same three points that sat unused beneath my ribs while I bled in a tree. The same body that could do this all along, if somebody had taught it where to reach. I want to be furious. I am furious. Beneath that is a bright, greedy thing that has been missing since I won a sword in a room full of black fire.

I want to do it again.

Tolliver sees it. His mouth softens in a way I have no defense against, and for a moment I forget the pie and the factor and the stick at Ordway's stall. He is kneeling in front of me with water on his collar because I put it there. I could lean forward a little. That is all the distance there is.

He reaches up, slowly enough that I see the question, and brushes a drop from the edge of my jaw with his thumb.

I let him.

His hand is warm. My breath catches, and he hears it, and his eyes come back to mine.

For one awful second I want him to make this decision too.

I turn my face away.

He lowers his hand at once. Neither of us speaks. Downstairs, somebody laughs hard enough to end in a cough, and the noise gives me somewhere to put my eyes until I can look at him again.

"Not while you decide where I sleep," I say.

He goes still. Then he nods and moves back, giving me room to stand.

I carry the basin to the sill. My candle has burned down past the first scratch, so I deepen the remaining marks and add two small dots beneath them. Two left. Seven out of ten. No run.

Behind me, Tolliver says, "The factor will want to meet you."

"He can want things."

"He's here in Greyward until tomorrow evening. I can't promise what he'll offer after that."

"Then don't promise. Bring the terms."

He gathers his needle and leather, and this time when he gets up to leave I do not reach for his sleeve or ask when he will be back. He pauses with his hand on the latch.

"Keep two in reserve," he says. "You can spend them on a stumble faster than you can think."

"I will."

He leaves. I bolt the door and wait until his footsteps have reached the taproom before I get the six bits out from under the mattress.

I take four downstairs.

The keeper looks at the coins I lay beside her knife. "You're paid through tonight."

"Tomorrow night. Same room."

She tests one with her thumbnail, then sweeps them into her apron. "Name?"

"Maya."

She writes it on a slate. Just that. Four letters, as far as I can tell before the marks settle into the shape I know.

"Who's it against?" she asks.

I keep my hand flat on the table.

"Paid," I say. "Can you put it against paid?"

She looks at me for a moment, then adds a mark beside my name.

"Breakfast's separate."

"I know."

Upstairs, the candle is still burning. I have two bits of my own left, four of his I have not touched, and a room that will be mine tomorrow whether he comes back or not.

I sit on the bed and watch the flame until my hand stops shaking.

CHAPTER EIGHT

In the morning I am still level one.

I check before I get out of bed, then check again because apparently I am the sort of person who refreshes reality when she doesn't like the result. Seven out of ten. Three out of three. No run.

The reserve has come back. That part matters enough that I sit with it for a while, feeling the three pale marks without spending anything. Last night I dreamed about lifting the basin. Before that I dreamed my mother was washing my hair in the kitchen sink, the way she used to when I was little, except the sink was full of leaves and she kept asking me to hold still.

I put my boots on before that can become the whole morning.

There is no Tolliver on the floor. He did not come back. I know because I woke up four times to look, which is a detail I intend to keep from him until I die.

His coins stay on the sill. I take my last two bits, tuck my shirt farther under the tick, and go downstairs.

The keeper has porridge and no interest in my circumstances. One bit gets me a bowl. I eat all of it, scrape the sides with the spoon, and think of the difference between going to work yesterday and going today. Yesterday I had a point to make. Today I need another piece by noon.

Outside, the gutters are running from rain I slept through. Greyward has been washed badly and left to dry. The market awnings sag in the middle, and people poke them from underneath with poles so the water falls on somebody else.

Ordway is unlocking her till box when I arrive.

"You're early."

"It was mentioned."

She gives me the salt tub. "Check for damp."

I set it on the table, take the cover off, and work the scoop gently through the top. Dry. A few small lumps along one edge, but they break when I press them.

"He didn't send you?" she asks.

I keep the scoop in my hand. "No."

Ordway fits a pin through the hasp of her box and pushes it under the table.

"He told me about last autumn," I say.

Her shoulders settle. Nothing dramatic, just the adjustment you make before lifting something you know is heavy.

"How much of it?"

"Half your stall. A debt your husband signed for."

"My husband signed for it. I ordered it. It was a good price." She takes the scoop out of my hand and levels the salt. "Then he died, and I couldn't be here and at his bed, and the good price came due."

I look at the cards of thread lined up on the dry side of the table. There are fewer than yesterday. I know that now, know enough to count what she hasn't replaced.

"Did you pay me because you're frightened of him?"

She looks down the row. A boy is trying to hold an awning pole upright while his father ties it, and the pole keeps describing wider and wider circles in the air.

"I paid you because you'd worked," she says.

"You weren't going to."

"No."

She lets that stand between us. It is uncomfortable enough that I almost help her get rid of it.

"A proper house can come after a wage," she says at last. "Tolliver can come after a debt someone gave him authority to collect. Different things. When you named him, I knew which sort I wasn't dealing with."

"He could have come back."

"He still could." She pulls the first sack of peas toward her. "I'd have had more to say with your coin already spent."

I look at her hands. The knuckles are red from cold, the thumbnail split along one side. I wanted one clean answer I could put next to his and compare. She has given me a woman with a stall who made a choice after nearly making another one.

"Thank you," I say.

"Don't thank me for paying you. Makes it easier the next time I don't."

She hands me the sack.

An hour later we have customers, and I have sold enough salt to understand why she doesn't let anyone heap the scoop. The margin is hiding in the part everybody wants for free.

I am better today. I know where the needles live and which corner of the table lists when somebody leans on it. I recognize the boy buying for his mother before he speaks, and have the white thread in my hand when he asks for black. We both deal with the disappointment like professionals.

Once, between customers, I open my measure with my back to the covered tub.

Seven out of ten.

I shut it again.

Apparently doing a job twice is not a level farm. Or I have been doing it wrong. Or the seven means something much stranger than I think it does. There are people who could tell me, and every hour I spend knowing that without asking starts to feel less like caution and more like participating in my own stupidity.

"How did you choose your run?" I ask Ordway.

She is sorting bent pins from straight ones. "Badly. I was thirteen."

"Can you change it?"

"Costs more work than choosing right the first time."

"What were you?"

"A runner. Thought I'd carry messages and see the coast."

I try to picture her thirteen and fail, then try again and get a thin girl with her elbows out, furious that somebody else has a better horse.

"Did you?"

"Saw three towns and a man who paid by the mile he admitted I'd walked. My knees still don't like frost." She drops a crooked pin into a separate dish. "You're not choosing one for my stall."

"I didn't say I was."

"You looked disappointed in your number. People do that when they're trying to make it hurry. You can work a counter without spending your life becoming better at my counter."

I stand with a card of thread between my fingers and feel, for the first time, how big the choice might be.

Nyx was a spellblade because I liked the preview animation. If I hated it, I could delete her and start again. The first time I got a build wrong I watched a video while eating cereal and fixed it in twelve minutes.

My knees are going to have to live here.

"Where do people learn?" I ask.

"Yards. Houses. Temples, if you like being cold on purpose. Depends what you want."

"And if you don't know?"

She looks at me over the pins. "Then don't let the first person with a bed decide for you."

A customer reaches between us for the soap, and we go back to work.

---

The trouble begins with a man trying to save half a step.

He has a handcart stacked with sealed jars, a delivery for the oil seller on the opposite row. Ordway sees him coming and moves her basket of spare cloth out of his way without stopping the price she is giving a woman. I pull our little stool under the table. The lane through the middle clears by inches.

The cart's left wheel catches the oil seller's awning rope.

I see the rope tighten. I see the pole shift. The man heaves the handles sideways to free the wheel, and at the stall beside him a woman is lifting a kettle off a charcoal pan.

"Wait," I say.

The pole comes down across the cart. A jar breaks. Oil splashes the kettle woman's apron, the table, the pan beneath her hand.

The flame is small at first, a blue curl around the edge of the coals. Then it climbs the spilled oil and the whole front of the table goes orange.

Everybody moves at once.

The kettle hits the ground. Somebody shouts for water. The carter drops the handles and tries to pull the cart backward, but his wheel is still tangled in the rope and the jars roll together with a noise I will hear later when I close my eyes.

"Sand!" Ordway shouts. "Under Hester's table!"

She is already moving. I go after her because her basket catches my knee and because doing what she says is the only useful thing in my head.

Heat strikes my face across the lane. The fallen awning has caught along its edge, and the woman who was holding the kettle is on the ground behind it, pulling at something I can't see. Someone gets a coat over the fire on her apron. Two men grab the cart's handles.

"Leave it," she screams. "Leave the fucking cart!"

They stop.

Her skirt is trapped under the wheel.

There is not much of her visible between the boards of the tilted table and the collapsed cloth. A hand. One bare forearm. Her face, eyes squeezed shut against the smoke. She has turned onto her knees to crawl away, and the cart has taken the cloth tight across her thighs.

The oil seller and the carter lift together. The wheel rises perhaps two inches before another jar shifts. The cart tips toward the burning table and both men let it down to keep the load from spilling.

Ordway throws sand across the fire. Some of it takes. Some lands on wet cloth and slides off.

I crouch where the kettle has rolled and look under the cart.

The awning rope runs around the axle, down under the wheel, then back to the peg on our side of the lane. Pulling the cart back tightens it. Lifting the cart pulls the fallen pole against the table. Everything they do to free one thing moves another.

I know this feeling. Twelve people trying to fix a wipe in twelve different directions.

"Stop lifting," I say.

Nobody hears me.

"STOP LIFTING."

The carter looks over, furious. I point to the rope beneath his axle.

"That's holding it down. Cut it first."

His eyes follow my hand. He drops one handle, gets a knife off his belt, and kneels.

The burning cloth shifts when the rope parts. The oil seller swears and catches the pole before it can fall farther. A mason takes his place at the cart handles. I get my hands under the lower edge of the overturned table, next to the trapped woman's shoulder, and push.

It moves about an inch.

Enough for me to understand how much it weighs. Not enough for her to get out.

"Here," I tell her. "This side. When they lift, come this way."

Her eyes open. Over her head, tilted with nothing at all though she is nearly lying down, her plate says **[COOK, LV. 16]**.

Level sixteen. Level one. None of the numbers has room for a skirt under a wheel.

Ordway dumps the rest of the sand. Another person arrives with a bucket, and she knocks his arm away before he can throw it. The movement sends sand into my face, gritty and hot. I cough, lose an inch of table, and hear the woman make a sound through her teeth.

The oil seller cannot leave the burning pole without dropping it across us. The two men at the cart have their hands full. The space beneath the table has me in it.

I find the other weight.

There is no panel open. I don't need one. Last night the sensation was an impossible thing beneath my breathing, and this morning it has been waiting for me to remember where I put it.

I push through it.

The table lifts.

"Now!"

The men heave. The wheel clears the cloth. She crawls, one elbow and then the other, dragging her legs after her while I hold the table above her back.

It is easy for one breath.

On the next breath, the weight begins to return.

She is halfway through.

"Move," I say, and hate myself for saying it because she is moving, she is doing every bit of moving she has, and one boot has caught the hem that is still bunched beneath her knee.

Ordway reaches past me. Gets a fist in the woman's apron. Pulls.

I spend again.

This time I am ready for the sudden absence of weight, and I straighten only enough to make space. The woman comes free. Ordway falls backward with her, the cart rolls away, and the oil seller yells at me to get clear.

I let the table go and throw myself after Ordway.

It crashes onto the ground behind my heel. There is a tremendous noise as the remaining jars break, but the cart is out of the flame now and most of the oil runs into the gutter, shining brown through the rainwater.

I am sitting in it.

Somebody pulls me up by the back of my woolen shirt. I try to help and discover that my legs are conducting a private discussion about whether we still do that.

"Stand," Ordway says in my ear.

I stand.

She keeps a fist in my sleeve while people shovel sand and stamp out the awning's edges. The whole market is shouting, names and instructions and accusations layered together until I cannot separate them. The cook is sitting against a post with her hands tucked under her arms. Her face is white beneath the soot.

She looks at me.

"Your hair," she says.

I put a hand up. The very ends on one side feel crisp.

"Great," I say, and start laughing.

It is not a good laugh. Ordway steers me back to our stool and puts me on it, then goes to fetch water I am actually allowed to use.

I put my hands between my knees until they stop trembling enough to count.

Two. I spent two.

I have one left.

---

The wardens arrive after the fire is mostly sand and smoke, which seems unfair until I realize it has been perhaps a minute since the jar broke.

One makes everybody move back. The other calls for the mender, and at that word I start trying to stand because I have one bit in my pocket and I have already had an expensive week.

Ordway pushes me down by the shoulder.

"I'm fine."

"Then be fine sitting."

She crouches to look at my face. There is a scrape along the outside of my left forearm, bright and shallow, and the skin across my knuckles is red. My boots are slick with oil. My foot hurts, though in a familiar way that feels almost friendly.

"Open your measure," she says.

I hesitate.

She notices. "Not your name. Just look. Tell me what you've got left."

I touch my throat. Find the number.

The number is different.

I miss everything underneath it the first time because all I can see is that it is different.

**[MAYA SZCZEPANIAK, LV. 2]**

I make a noise.

Ordway's hand closes on my wrist. "How much?"

"One."

"Out of?"

"Four."

I read it again to be certain.

**[PROGRESS: 1 / 14]**

**[RESERVE: 1 / 4]**

**[RUN: UNSET]**

There is no fanfare. No gold light. My arms hurt, my hair smells like a terrible electrical problem, and in front of me the universe has put a two where the one was.

"I leveled," I say.

"Yes. I can see."

She says it so ordinarily that I nearly cry.

I want Liam. The want comes without warning, absurd and enormous. I want to tell him I finally did it, and have him ask whether I blinked into the fire first, and be annoyed with him while everybody else laughs.

Instead I sit on a stool with my fingers against my throat and try to memorize the shape of the two.

My public plate has changed. Anybody who looks can see it. Whatever that level means, I have made it mean something different than it did yesterday.

I let the measure close.

"Did it fill you?" Ordway asks.

"No."

"Good thing to learn while you've got one left. A bigger cup isn't a drink. Don't spend the last just to see what it does."

She stands and turns toward the warden who is coming down the row. I recognize him before he recognizes me. Heavy face, strap on the shoulder, the same tired eyes that looked at my bare feet in the gateway.

Bertran.

His gaze passes over me, goes up, then comes down again.

"You," he says.

"That keeps happening."

Ordway makes a small noise that might be a cough.

Bertran looks at the smoke, at the cook, at me. "Where's the young man you came in with?"

"I don't know."

"You're working here?"

"Yes."

"For her?"

"For me," Ordway says. "She saw the rope. Hester would still be under there if she hadn't."

"I've heard." His eyes return to my plate. "You've had a busy morning."

I could leave it there. I can feel the opportunity to say nothing opening in front of me, familiar and warm. He hasn't asked about Skell's. He hasn't asked why I am here without Tolliver. There is still enough smoke to hide an entire conversation.

"I need to change something in your book," I say.

Ordway goes quiet beside me.

"What something?"

"The part where he answers for me. He helped me get here. I didn't understand what else you were writing down."

Bertran looks from me to Ordway.

"Is there trouble?"

"There's something I don't understand. I'd like to do it while it's still that."

He rubs the side of his nose with one broad finger. Behind him a warden begins arguing with the carter about where to leave the damaged cart, and the ordinary world tries very hard to reclaim him.

"Where are you sleeping?"

I describe the tavern and my room at the back. "Tonight's paid. I paid it."

"And you'll have her tomorrow?" he asks Ordway.

"If she's got hands enough to count with."

"She has," I say.

Neither of them looks at me.

I stand. "I'm right here."

Bertran's eyes return to my face. After a moment he nods.

"Come to the gatehouse after the midday bell. Bring your keeper or your employer. If they're willing to attest to what you've told me, we can amend the person responsible for your stay."

"To me?"

"We'll discuss that with the book open. It doesn't give you an origin. It doesn't give you leave to stay forever."

"I didn't ask for forever."

"Good. Forever's a poor thing to put in a book."

He goes back to the cart. I sit down again before Ordway can make me.

"Can you come?" I ask.

She looks at her stall. The thread is where we left it. The salt is covered. Somebody has put the lid over the peas while we were across the lane, and I have no idea who.

"After I close," she says.

I nod because anything else is going to come out embarrassingly.

She touches the back of my neck, briefly, below the place where my hair is ruined. Then she picks up her scoop and asks the first returning customer what he wants.

---

Tolliver finds me counting needles with both sleeves rolled up.

He comes down the middle quickly enough that I see three people move before I see him. His attention goes from the burned awning to the stool, then lands on me so hard that I feel it.

"Maya."

"I'm fine."

He reaches the table, catches himself, and puts both hands flat on its edge instead of on me.

"You're burned."

"Mostly inconvenienced. The mender looked."

She did. She dabbed something cool on my knuckles, told me I had used more luck than skin, and moved on to Hester, whose apron had saved her from much worse. Ordway told the warden to put the small treatment against the fire account. I do not yet know whose money that is. I intend to find out.

Tolliver's gaze lifts to my plate.

The change in his face makes me glad in a way I wish it didn't.

"Two," he says.

"I know. Try to remain professional."

He lets out a breath, almost a laugh, and for a moment the table might be the only sensible thing between us. I want to show him every part of it. Where the rope caught. How I held the table. The exact second I found the reserve without opening the ring.

I also want him to understand that I did all of those things while he was somewhere else.

"I kept one," I say.

He nods. "Good."

I look down at the needles before that can become worth more than it should.

"I'm going to the gatehouse after the bell. Ordway's coming. To correct the entry."

His hands stay where they are.

"What did you tell them?"

"That I didn't agree to belong to anybody."

"I told you—"

"I know what you told me. I want the book to tell it too."

Ordway is beside us now. She doesn't say anything. Tolliver looks at her, then at the stall, and there is a moment I cannot read because it belongs to a season before I arrived.

He takes his hands off the table.

"I'll go with you if they need me."

It is a better answer than I expected. I am trying to decide what to do with it when someone behind him says, "Before that, perhaps a word."

The man is dressed in a brown coat with covered buttons. He is perhaps forty, with a narrow beard and ink along the side of one finger, and his boots have none of the market on them. Above his head hangs **[FACTOR, LV. 18]**.

He waits for me to look at him before he comes any closer.

"Master Vey," Tolliver says. "I told you I'd bring her the terms."

"And here I am with them."

The factor holds a folded sheet between two fingers. There is a small black bird impressed in a seal at the bottom. I notice the bird because looking at it is easier than looking at him.

"I haven't agreed to go anywhere," I say.

"Understood."

He lays the paper on the table, clear of the salt. Tolliver watches his hand.

"Take it," Vey says. "Read it. Have someone else read it. You'll find the length of service on the first page, compensation on the second, and the conditions for leaving on the third."

"It's folded," I say. "I haven't found any pages yet."

He smiles without showing his teeth. "A fair correction."

I do not touch it.

"What's so useful about level one?"

His eyes flick upward. "Level two, now. Congratulations."

"That isn't the question."

The smile goes, leaving something more attentive.

"There are several kinds of useful," he says. "I would like to establish which applies to you before we waste each other's afternoon."

"We're working," Ordway says.

"Then I'll be brief."

He reaches inside his coat.

Tolliver moves half a step, just enough to put his shoulder between the man's hand and me. Vey stops, glances at him, and withdraws his hand slowly.

What he brings out is a small leather wallet. Soft, hand-stitched, ordinary. He opens it and takes out something the size of a bank card.

For a moment I cannot see it properly. My mind keeps trying to make it belong on the table, trying to turn it into painted wood or a little piece of enameled metal. There is dirt pressed into one corner. One edge has been cracked and repaired with thread through two tiny holes.

The photograph is of a woman with brown hair and an expression caught halfway between polite and annoyed. She is older than me. Thirty, perhaps. The background is pale blue.

Above her face, in letters that do not shift, do not settle, do not need anything in my head to make them readable, is a word I have seen on my own wallet a thousand times.

MISSOURI.

I forget to breathe.

Beside me, Tolliver says something. I don't hear it. There are numbers on the card and a red mark near the corner and a signature beneath the photograph, and I am reaching before I know my hand has moved.

Vey leaves it on the table. He lets me pick it up.

Plastic. It bends slightly between my fingers. The familiar weight of it is almost nothing.

"Do you know what that is?" he asks.

I look at the woman's face. She has stood in a building on my planet, irritated by a camera and a queue and somebody asking her to take her glasses off. There had been a road outside. Cars in a parking lot. Somebody had printed this and put it in her hand.

I cannot make my voice work the first time.

The second time, it does.

"Where is she?"

CHAPTER NINE

"I don't know where she is now," Vey says. "When I last saw her, she was leaving Rook House on foot. She was alive, and she was angry. That was four years ago."

Four years.

I press my thumb against the woman's photograph. The nail covers one of her shoulders.

"You saw her."

"Yes."

"Not someone who looked like her. Her."

"She had shorter hair by then. But yes."

The card says MERCER, ELENA RUTH. Below that is a birth date in 1993, an issue date in 2023, an expiration date in 2029. An address in Independence. I have driven through Independence. I have complained about traffic there with the air-conditioning on and a drink sweating in the cup holder.

Four years here. A card issued in 2023.

I can't make those numbers useful without knowing when she left, when she arrived, how long she stayed. My brain keeps trying anyway. It wants a calculation with an answer at the bottom, preferably one that tells me my parents aren't old yet.

"Elena," I say.

Vey's eyes sharpen.

I wish I hadn't given him that for free.

"That is the name we had."

"Why do you have her card?"

"She left possessions in a chest. The chest remained when she went."

"You kept them."

"The house kept them. I brought this one from the collection."

"Collection," I repeat.

Ordway pushes a sack away from my elbow before I knock it over.

Vey looks at her, then at the customers passing behind us. "Would you prefer somewhere private?"

"I'd prefer you answer."

"Rook buys unusual objects. Some are recovered from abandoned holdings. Some are sold to us. Some are left by people who don't return. They are inventoried. I don't administer the collection."

"But you use it to hire people."

"Occasionally."

Tolliver is looking at the card now. His mouth is set in a way I recognize from our room, just before an answer gets expensive.

"Did you know?" I ask him.

"I knew they wanted someone who could read strange writing. I hadn't seen that."

"Is that why you found me?"

"No."

The answer has force behind it. Several feet away, a woman turns with a spool in her hand.

He lowers his voice. "I was coming back from a message run. You were on the slope above the creek. I didn't go into those woods looking for you."

"Why did you think I could read it?"

"The marks on your shirt."

I feel the wet cotton again, the hem torn off for my foot, his coat pulled closed over it. CRIT HAPPENS. A stupid joke I bought because Liam had one in a worse color.

Vey watches us. I want to put something over his face.

"You told him about my shirt."

"This morning," Tolliver says. "When he asked what else was unusual."

There is a needle on the table between us. One small bent needle Ordway missed. I concentrate on it until I can ask the next question without shouting.

"Anything else?"

"That you didn't know how to spend reserve when I found you. That you learned quickly."

"Do you want me to leave?" Vey asks.

"I want you both to stop having conversations about me that I get invited to afterward."

Ordway takes the spool from the waiting woman, names a price, and makes change. It gives me time to breathe. It also reminds me that I am standing in the middle of her livelihood holding another woman's driver's license as though I can wring directions out of it.

"How long was Elena at your house?" I ask.

"Nine months, approximately."

"Did she come in like me? Low level. No origin."

"I didn't admit her. I can show you her entry."

"What did she do there?"

"Survey work. Water levels, old culverts, the lower road. She worked with our keeper of records."

"Did she say where she was from?"

"A place called Missouri. Nobody I asked knew it."

Hearing him say it is worse than seeing it printed. He puts the weight in the wrong place, and suddenly I'm hearing an out-of-state caller ask if we're anywhere near St. Louis.

"Why did she leave?"

"She wanted access to a site the house had closed. The south sluice. There was an argument about safety and about what she'd been hired to do."

"And then she left her ID and all her stuff and walked away?"

"I saw her leave with a pack. I didn't search it."

I turn the card over. The barcode is there. The dark strip. Small printed words I have never cared enough to read on my own license.

A thumbnail has worried the plastic beside one of the stitches. Hers, maybe. Someone else's. The card cannot tell me.

"Can I keep this?"

"No."

His first answer without any polish.

"Then I'm going to need something to write on."

Ordway opens her till box and takes out a narrow scrap with figures on one side. She sets it down beside a pencil worn nearly to the wood.

I copy Elena's name and the three dates. My hand shakes badly enough that the first nine looks like a four, and I cross it out. I copy the city. Not the street address. If I ever get to use it, I can look her up. If I never do, another street I cannot reach is not going to help.

Then I put the license down.

Vey slides it back into his wallet. I watch until the flap closes.

"Show me the offer."

---

The letters shift when I unfold the paper.

For a second they are all narrow uprights and little hanging hooks. Then I understand them. The shapes don't become English, exactly. The meaning settles behind them, and I am reading a sentence whose individual letters I couldn't have named a moment ago.

I look back at the name I've just written.

ELENA RUTH MERCER.

Those letters stay themselves.

"Read that," I tell Vey, pointing to the scrap.

He studies it. "I recognize that you've repeated the marks on the object."

"You can't read them?"

"No."

Ordway shakes her head before I can ask her. Tolliver does the same.

I cover the scrap with my palm. There is something here I need to understand, but not with three people watching me discover how useful I am.

The offer is three pages. I read every one.

A year of service. Board and bed. Two pieces each week in cash, with clothing, equipment, and additional instruction charged to an account. A basic course of instruction in one run selected *according to the needs of the holding*. No promise about which one.

I turn the page back.

"What counts as additional instruction?"

"Specialist work beyond the course."

"At what price?"

"The instructor's price. You would be shown it."

"Before?"

Vey points to a line. Before approval. It is there. I mark it with my finger and keep reading.

Leaving requires thirty days' notice and settlement of outstanding charges. Work produced in service belongs to the house. Objects recovered during assigned work belong to the house. The words are plain once I have them, and large enough to fit a driver's license through.

"Does this let you keep somebody until they pay?"

"It lets us pursue a debt."

"That wasn't what I asked."

"Under this agreement, a person with an unsettled account cannot demand release from the service term."

Across the table, Ordway stops winding a loose length of thread.

I fold the third page over the first.

"No."

Vey doesn't reach for it. "Which provision?"

"The year. The unknown bill. You deciding what I learn. The part where anything I find about my own home becomes yours because I'm doing your job when I find it. Pick one."

He considers me without smiling. "You haven't told me where your home is."

"And yet you brought that card."

Tolliver shifts beside me. I don't look at him.

"I cannot open the whole collection to a visitor," Vey says. "Some pieces are fragile. Some have disputed ownership. Some have harmed people who handled them carelessly."

"You can hire a reader without hiring a person for a year."

"For how much?"

The question lands faster than I expect. I almost look at Ordway.

One piece for a morning's work. Two pieces a week on his paper, plus room and food. Those numbers mean different things in different arrangements, and I am tired enough to choose the one that sounds biggest.

"First tell me what you need read."

"A notebook. Some labels. We have partial copies of inscriptions in the same sort of lettering."

"Elena's notebook?"

"We believe so."

"How many pages?"

"Thirty-six with writing."

"And you can't bring it here."

"I am authorized to take samples out. Not the original volume."

The bell begins before I answer. Its first stroke travels through the boards under my hands.

Ordway puts the thread away.

"We have an appointment," she says.

Vey looks toward the gate road. For the first time, his afternoon seems to have developed a problem that isn't me.

"I'm staying tonight," I tell him. "I can meet you at the tavern afterward. If you have a short agreement for reading, bring that. If you only have this, don't."

"Maya—" Tolliver begins.

"Are you coming to the gatehouse?"

He shuts his mouth, then nods.

Vey collects the unsigned offer. I keep the scrap with Elena's name.

Before we leave, Ordway pays me.

Eight bits instead of a piece because her till is low. She counts them into my right hand, clear of the sore knuckles.

"Whole morning," she says when I look at her.

"We closed early."

"And you got the rest of the market opened again. I'm not docking you for that."

Nine bits in my pocket. A job available tomorrow. A room tonight.

I can refuse a year because of those small things. I curl my fingers around them until the edges hurt.

---

The gatehouse smells of wet leather and a pot of something that has been kept warm through several people's disappointment.

Bertran seats Ordway on a bench and leaves Tolliver and me standing. The book takes up most of his desk. There are slips tucked between the pages, a stone holding one corner flat, and a dark stain where somebody lost an argument with the ink.

"Open," he says.

I expose my name. Tolliver does the same beside me. Bertran checks us against the entry, then motions us closed again.

"Employer?"

Ordway gives her name and the location of her stall. He knows both. He writes them anyway.

"She worked two mornings. Earned a piece each. I'd have her back."

"And lodging?"

I tell him what I've paid and where. He writes that too.

"The existing entry places responsibility with him," he says, tapping the page without looking at Tolliver. "Are you withdrawing it?"

"Yes," Tolliver says.

I wait for the rest. It comes slowly.

"I have no claim on her wages. No service agreement. No debt against her for what I've spent."

Bertran looks up. "Any advance?"

"Four bits. She hasn't used them. They're a gift if she wants them."

"I don't."

"Then she'll return them," Tolliver says.

"I can answer."

His jaw tightens. "Yes."

Bertran dips his pen. "Anything else before I amend this?"

The book is open. The part I asked to change is almost changed. I could take that and get out into the air.

"I've never been to Skell's Holding," I say.

Ordway turns her head toward me.

Tolliver doesn't move.

The pen stays above the page long enough for a bead of ink to swell at its tip.

"Go on," Bertran says.

"He found me in the woods. North of here. I didn't know what to say at the gate, and he told me to let him talk."

"Did you lose your origin at Skell's?"

"No."

"Have you ever held an origin?"

"Not that I've known."

He sets the pen down.

"Outside," he tells Tolliver.

"I gave you the account."

"I remember who spoke. Outside."

Tolliver goes. There is a window above Bertran's shoulder, too narrow to climb through even if I had the energy. I look at it while he folds his hands.

"Where are you from?"

"Kansas City."

"Whose territory?"

"You won't know it."

"That wasn't the question."

I swallow. "Missouri. In the United States."

Ordway says nothing. No little noise, no helpful interruption. I am grateful enough to hurt.

Bertran makes me spell the words. I can't name a local road from there to here, or a ship, or a person he can send to verify it. When I tell him I woke in the forest, he asks whether I had been struck. Whether I remember being given a drink. Whether anyone took my things.

"I don't know," I say, and finally start crying.

It is quiet, which somehow makes it worse. Tears drop off my chin onto the front of my borrowed skirt while I keep answering. No, I don't know which holding owns the forest. No, I don't remember a gate. Yes, the foot was cut after I woke. I know because I remember stepping on it.

Bertran pushes a cloth across the desk. It smells faintly of onions.

"I can't put a country I've never heard of into the origin field," he says.

"I didn't ask you to."

"I'm telling you what I can do."

He waits until I look at him.

"Seven days' provisional stay on your own responsibility, based on work and lodging witnessed here. If you stay longer, come back before it ends. If you leave, register the departure. Your account of where you came from goes in as unverified. No one here is attesting to that."

"Can I work?"

"Yes."

"Can somebody take my wages?"

"Not on the strength of this entry. A lawful debt is a separate matter. So don't sign one because a factor bought you supper."

The corner of Ordway's mouth moves.

He brings Tolliver back in and asks him the same questions without letting me answer. Tolliver says Skell's was destroyed by fever, but he had no reason to think I'd come from there. He admits inventing that connection because an injured adult with an empty origin was likely to be detained while somebody investigated.

"You made that my decision with false information," Bertran says.

"Yes."

"Two pieces for the false declaration. Your standing as an entry witness is suspended until Hale reviews it."

Tolliver reaches for his purse.

I look at the floor while he pays. Relief and guilt arrive together, which is inconvenient because I don't believe the guilt has earned a place.

Bertran writes the payment down, then reads the amendment aloud. Ordway witnesses the employment and lodging statement. Tolliver signs the withdrawal. I sign beneath my own responsibility, in the English letters of my name.

The pen is unfamiliar. My signature still looks like mine.

Bertran gives me a narrow stamped slip showing the term of my stay and the amended entry number. It has no magical effect. I know because when I open my measure, the origin is as empty as before.

I go into the other list and select Traveler.

"Changed?" I ask Ordway.

She looks up. "Changed."

I let my hand fall. My neck feels exactly the same.

Before Bertran closes the book, I ask about the mender's bill.

"Market fire fund pays immediate treatment," he says. "Stall dues maintain it. We'll settle damage and fault with the carter and the oil seller. Treatment isn't your debt."

Ordway rises with a grunt. "Somebody gets something for my dues at last."

Outside, Tolliver starts to speak. She walks past him and stops in front of me.

"If you stay, come early. If you go, tell me before I open."

"I will."

She squeezes my good hand and heads back toward the market, where half her stock is waiting under a locked cover.

Tolliver and I stand beside the wall.

"I'm sorry," he says.

There is no explanation attached. It leaves him looking strangely unfinished.

"For which part?"

He takes that without looking away.

"Deciding what you needed to know. Selling what I knew before I'd told you it had a price."

I rub the stamped edge of the slip with my thumb.

"The card isn't a reason for me to forget that."

"I know."

"And you don't get to decide whether I follow it."

"I know that now."

A cart rattles through the gate. For several seconds we can't hear each other even if we want to.

"Do you actually know how to get to Rook House?" I ask when it passes.

"Yes."

"Good. I may need directions."

---

Vey waits in the tavern with a new sheet and no supper.

I wash first. The keeper lends me ash and a rag for the boots, and I scrub until the soles stop sliding on the yard stones. The scrape on my arm burns under clean water. When I finally sit across from him, my hair is still damp and one side ends in a small, ugly fringe.

I make him move the paper away from a ring left by somebody's ale.

Six days of reading work after arrival. One piece for each day worked, paid that evening. No advances. Meals and bed on the journey and throughout the visit, including any wait for return passage. A cart seat there, and one back to Greyward on the first house cart within three days after I finish or leave. Those costs cannot be charged back. I may stop the work at any time; pay already earned remains mine. No change of origin. No choice of run made for me.

There is no training course. A short hire doesn't buy one.

In return, Rook gets my translations of the named notebook and its associated labels. No obligation to open mechanisms, enter closed works, or surrender possessions I bring with me. I can keep copies of my translations and notes about Elena. I cannot take the original objects.

"I want her entry and departure records before I begin," I say.

Vey adds the line.

"And if she's in your house now?"

He sets down the pen. "Then you will be allowed to speak with her. But I do not expect that to be the case."

I make him add it anyway.

"Tolliver's fee?"

"Requires a service entry. This isn't one. He earns nothing from it."

Tolliver is at another table, close enough to hear. His expression changes, but he doesn't argue.

Vey signs both copies. The keeper comes over to witness after I ask her, reads the pay and departure clauses, then reads the rest because apparently she has met people before.

"Return passage includes food," she says.

Vey adds that too.

I sign.

He leaves me one copy and tells me the cart departs from the south gate at first bell. Then he goes upstairs to arrange his own affairs, carrying the card with him.

I buy stew and bread for two bits. Seven left. After I eat, I go upstairs for Tolliver's four coins. He is still at his table when I bring them down and put them beside his hand.

He pockets them without trying to turn them into another gift.

Later, alone, I lay out the contract, the gate slip, and the scrap bearing Elena's name. My reserve is two out of four now. The progress is still one out of fourteen. I have signed an agreement, not defeated a boss.

Under the name I add a question in English.

*Did you find a way back?*

I stare at it until the candle guttering beside my hand reminds me that I have to pack.

CHAPTER TEN

Everything I own fits inside a flour sack.

The keeper gives me one with a split seam and lets me use her needle while she counts yesterday's money. I mend it badly, turn the repaired side inward, and put my Earth clothes at the bottom. The shirt still smells faintly of the forest. I fold the black shorts inside it and tie the bundle with a piece of string so I won't have to see it every time I need something.

The contract and gate slip go inside a fold of the woolen garment while I pack, then against my chest when I put it on. Elena's name goes with them. The candle is too short to be much use, but I take it anyway.

Breakfast costs a bit. Six left.

"Key?" the keeper asks.

"It bolts from inside."

"Then you're done."

I had apparently been waiting for a checkout process. A receipt. Somebody asking whether I enjoyed my stay in the room where I learned the government could see my level.

"Thank you for witnessing."

"Read it again when you get there. Make sure their copy matches."

She goes back to her counting.

Outside, the town is only partly awake. A baker is shoveling ash into a bucket. A woman passes carrying two live hens under her arms, their heads poking out like angry bag handles. I keep expecting to feel the empty room behind me. Mostly I feel the sack bumping my leg.

Ordway is at her stall before the sun reaches the roofs.

"I'm going," I say.

She looks at the sack. "So I see."

I tell her about the six days, the pay, the return cart. She asks to see the paper. I hold it while she reads so the corners don't drag through the damp.

"A piece a day," she says. "Would've offered you that for another morning."

"I know."

"No, you didn't. I hadn't offered."

I laugh, and then my throat hurts.

She takes the paper between her fingers at the departure clause. "If they argue with this, send word with a carrier. Put my stall on it. I can't fetch you, but I can get a warden to ask why."

"I don't want you owing somebody for me."

"Then pay the carrier."

She reaches under the table and brings out a small cloth bag.

"Yesterday's heel. Cheese is good. Hester sent the bread when I told her you might leave."

I accept it. I am getting better at recognizing things that are offered without a hook, although it still takes work not to look for one.

"Tell her thank you."

"Come tell her yourself sometime."

She takes the knot of my flour sack apart, tightens it properly, and gives it back. Then a customer arrives for lamp wicks and our goodbye has to make room for him.

At the gate, Bertran reads my departure into the book. I keep the slip; he marks it to show I have left. If I come back after the provisional term, he says, we will make a new entry. I understand the distinction well enough to nod without looking at Tolliver.

He is waiting beside a cart loaded with canvas-wrapped crates. His bow is strung. A second cart stands behind it, higher-sided, with sacks roped beneath a cover. Master Vey is arguing with a woman about whether his chest belongs on top.

"Are they paying you for this?" I ask Tolliver.

"Road escort. Two pieces for the trip. Separate from finding anyone."

"You could have mentioned it."

"Yes," he says. "I could."

"If you want it cracked when we brake, yes," she says.

Vey moves the chest.

The woman has an old scar through one eyebrow and **[CARTER, LV. 15]** above her head. She introduces herself as Nessa, points me toward the front cart, and tells me where my feet may go. Most of the possible places are wrong.

A young woman leans against the wheel eating an apple. **[GUARD, LV. 12]**. Her dark hair is in two short braids, and her nose looks as if it has been broken at least once by someone with a clear intention.

"You're the reader," she says.

"That seems to be my whole brand now."

She looks at the sack. "Can you sit on a board for a day?"

"My education has prepared me extensively."

She bites the apple again.

Tolliver puts a hand beneath my elbow when I climb, then lets go as soon as I have the rail. I sit on the board Nessa indicated and tuck my sack beneath my knees. The guard swings up opposite me with her pack between her boots.

"Sella," she says.

"Maya."

"Don't put a finger through the side rail. You'll want to. Don't."

The bell starts. Nessa clicks her tongue, the cart lurches, and I immediately understand why everyone has been giving me instructions about where to put parts of myself.

Greyward goes away one uncomfortable yard at a time.

---

For the first hour I watch everything.

By the second, everything includes an impressive number of hedges. My ass has gone numb. Each rut returns it to sensation in a different emotional state.

Tolliver walks on the left side of the road, sometimes ahead, sometimes beside us. He touches his throat at a fork, looks along the verge, then keeps going. Sella watches the right. Vey rides in the second cart beside its driver, a quiet man who seems pleased with the arrangement.

"Is Traveler your run?" I ask when Tolliver draws level.

"No."

"I know the label isn't necessarily the run. I'm asking what yours is."

"Tracker."

"Like finding footprints?"

"Among other things."

I give him a look.

He adjusts his bow strap. "I can hold a trail after it stops being visible. Briefly. If I've found enough of it first. I don't ask the ground where someone is and get an answer."

"Could you find somebody after four years?"

"No."

The directness helps, though I hate the answer.

"Four days?"

"Depends on the weather, the ground, and who crossed it after them."

Sella flicks her apple core into the ditch. "And whether they know how to make him follow a goat."

"Once," Tolliver says.

"An entire afternoon."

I look between them. "You know each other."

"Work," she says. "Last winter. He found the goat eventually."

He walks ahead while she smiles into her sleeve.

For a few minutes the road becomes almost pleasant. I ask about her run. Warder, she says. Her father taught her the first holds before she could carry the shield properly. She has worked caravans for three years, since she was eighteen, and has never been to the coast because every person hiring eastbound wants her for a westbound rate.

"Ordway wanted to see the coast," I say.

"Everybody does. Fish must be wondering what's so special about fields."

A bird lifts from the hedge with a clatter like shaken cutlery. Its plate is gone before I can read it.

"Does being a warder mean you have to stay in one place?"

"It means I get paid to keep something from coming through a place. Different amount of standing."

"Can you fight?"

She looks down at the sword between her knees, then back at me.

"Fair," I say.

"A run helps. It doesn't do all of you. Nessa can break your arm, and hers is Hauler."

"Both arms," Nessa says from the front. "Stay seated until we stop."

I settle back against a crate.

My measure this morning was full: four out of four. The two points I lacked last night returned while I slept. My scraped arm is crusted and sore, my knuckles tight when I curl them. Having a resource bar has done surprisingly little to improve the quality of my skin.

"Could you show me?" I ask Sella. "When we stop."

She studies me more carefully. "Your run's unset?"

"Yes."

"What have you spent on?"

"Strength. Once with a basin. Twice with a table that was on fire."

"We'll use something less ambitious."

I tell her about the basin and the fire. She asks which hand held the table, where my feet were, and what happened when the strength ended. The questions make me realize how little of the rescue I could repeat on purpose.

"At the watering place," she says. "If you're still interested after you've tried walking again."

---

I am interested. Walking again is an argument between several parts of me, but I win it.

The watering place is a stone trough beside a stand of low trees. Nessa checks the horses' legs while the other driver looks over a wheel. Tolliver goes a little way up the rise where he can see the road behind us. Nobody has to announce that we are taking precautions. They fit them around eating and pissing and arguing over a loose strap.

Sella gives me a wooden shield with a metal rim. It is the spare, and has a split repaired with two staples. My arm objects before I have it in position.

"No," she says. "Closer. Let your elbow rest. You're carrying it as if you owe it money."

She turns my wrist, gets permission before adjusting the sore hand, and shows me how the strap takes some of the weight.

Then she pushes me over.

Not hard. Not even with both hands. The shield turns, my rear foot slides, and I sit in the grass.

"That's useful information," she says.

"I'm thrilled to have it."

She offers a hand. I take it with the one that isn't trapped in military equipment.

We try again without reserve. Bend the knees. Don't lock the elbow. Put the shield where the blow is going, rather than chasing it after it arrives. She taps the rim with a stick and I move too far, too late, or occasionally in an entirely unhelpful direction.

I am sweating by the time she has me stand against a tree.

"Your burst makes more force," she says. "What happens if I push you sideways while you're making it?"

"You obtain more useful information."

"Exactly. Spend one, then. Hold the shield. Don't push me."

I find the reserve. The weight leaves my arm.

Sella presses a hand to the rim. I hold. She moves the hand a few inches, changes the angle, and the shield twists despite the strength. I stumble sideways before catching myself against the trunk.

**[RESERVE: 3 / 4]**

"Strong isn't planted," she says. "A first warder's hold keeps the force on the line you set. Shield through arm, back, leg, ground. If any of those gives, the hold gives."

"How do I tell it which line?"

"By knowing where you're braced."

She demonstrates. I push the shield with both hands. It feels ordinary at first, heavy and difficult to move because she is a trained adult doing a thing she knows. Then something changes. The slight give disappears. I might as well be pushing the trunk behind her.

Three breaths later it is a shield again.

"That's Brace. One point. Three breaths if you keep the shape. Less if you panic and try to do something else with it."

"And I need your run to do it?"

"You need a warder's pattern to hold it that neatly. You can waste reserve getting close without one. Most of us do, learning."

I let my hands fall.

She lowers the shield and shows me the stance again, this time from the side, then hands it over. I follow without spending. I can feel the difference between holding my arm rigid and letting the pressure find the ground. Mostly I can feel the places where I do it wrong.

"I wanted a sword," I say.

"Buy one."

"A magic sword. Fire. Possibly a dramatic coat."

"You'll want a better wage."

I laugh. She waits until I've finished, then taps my elbow down.

"Take the run because you want to learn what it does. Don't take it because I happen to have a spare shield. We can practice stance without it."

For another few minutes we do. When I open my measure afterward, progress has moved to two out of fourteen.

I show her my face before I can help it.

"What?"

"One point."

"You learned something."

"I learned about thirty things."

"Then you'll remember one. Put the shield back."

At the cart, Tolliver hands me my cloth bag of food.

"You looked good," he says.

"I fell over."

"You got up."

"Your standards are concerning."

He smiles, and I get a brief, deeply inconvenient picture of that mouth against mine. Then I bite into Hester's bread and discover that I am hungry enough for desire to wait its turn.

---

After midday the fields fall away. The road runs between shallow pools with reeds standing in brown water. There is a raised stone crossing ahead, no railing, wide enough for one cart at a time. Beyond it the ground climbs toward a low building with smoke coming from its roof.

"Wayhouse," Sella says. "We'll stop there."

"Already?"

"Last dry yard before the long stretch. Tomorrow we start earlier."

Tolliver stops at the crossing. Nessa stops behind him, and the second driver reins in with enough space left between the carts to turn.

No one looks surprised by the delay. I sit still and try to be useful by occupying exactly the amount of space I have been assigned.

Tolliver crouches beside a low iron grille under the nearest edge of the stonework. One corner has pulled loose. Water slides through the gap with bits of weed turning in it.

"Reed-jacks," he says.

Nessa swears.

Sella is off the cart immediately, sword out. "Fresh?"

"Mud's still running."

"Maya. Feet up on the bed. Stay behind the crates."

I move before I ask what a reed-jack is.

Something brown and narrow slips through the water beyond Tolliver. My first impression is an otter, which lasts until it rises higher than the reeds and opens a mouth split nearly to its neck.

**[REED-JACK, LV. 5]**

It has too many visible teeth for any activity I want to participate in.

Tolliver backs onto the road with an arrow drawn. Sella walks toward the horse's head, putting herself between it and the water. Nessa turns the animal slowly. Behind us, the other driver is already backing his cart toward the wider part of the road.

"Keep turning," Tolliver says. "There's a second."

The first one comes low and fast, barely lifting out of the ditch. His arrow takes it in the shoulder. It tumbles, gets up, and Sella meets it with the edge of her shield.

The sound is hideous. Bone or wood, I can't tell. The horse jerks sideways and the whole cart rocks beneath me.

I grab a crate. My sore knuckles reopen against the rope.

The second creature hits the back of the cart.

I don't see it jump. There is a wet slap, then claws drag across the board beside my boot. A narrow head comes over the tail rail with its whiskers spread and black eyes fixed on me.

The spare shield is strapped to the crate at my left knee.

I pull at it. The buckle doesn't come loose. I pull again, which is apparently the entire extent of my combat training when something wants my face.

"Back of the cart!" I shout.

Vey shouts something in reply from behind us. The animal snaps at my moving hand and its teeth close on the edge of the sack instead. Flour dust puffs from the seam.

My shirt is in there.

I get the buckle open.

The shield comes free. I put it between us without getting my arm through the strap, both hands on the back, and shove. The creature's forefeet slide off the rail. For half a second I think I've done it.

Then it lands on the road, turns under the cart, and vanishes.

"Where?" Tolliver calls.

"Under me!"

Nessa is holding the horse with both hands on the reins. If it bolts, Tolliver is in front of the wheel. If she lets go to help me, the whole situation becomes faster and worse.

Sella has the first animal pinned away from the horse. I can hear her swearing each time it pulls against her sword.

I drag the sack behind the crate with my heel. The tail rail is barely knee-high when I'm standing. I sit with my back against the load and get my arm into the shield properly.

Something scrapes beneath the bed.

I need it to stay out until someone can kill it. That is the whole job. There is no health bar I can nibble down while strafing. There is a mouth coming over the wood, and my left hand is inside the only thing between us.

My boots find the crossbeam beneath the opposite rail.

Shield. Arm. Back. Legs.

I can feel where the shove would go. Into the crate, through my hips, down to the soles pressed against the beam. The cart is moving slightly with the frightened horse. I am braced against the cart, not the road. I don't know if that counts.

The creature's head rises.

I reach for the shape Sella showed me.

Something answers inside the place where my run has always been empty.

**[WARDER]**

No list. No pretty spinning model. Just a word, available when I finally have some idea what I am asking it to mean.

I think of Nyx, who would have blinked behind the thing and cut it in half.

I cannot do that.

I can keep this space.

I choose.

**[RUN: WARDER]**

The new shape closes around the pressure I am holding.

**[BRACE]**

I spend into it as the creature hits.

The shield drives against my arm, but the force runs through me instead of folding me. The crate creaks behind my back. I feel the impact in my teeth. The animal is scrabbling for purchase on the rim, close enough that spit hits my cheek.

One breath.

"Here!" I yell. "At the back!"

Two.

A blade comes past my right side. I jerk away from it, and the hold breaks.

Weight slams into my shoulder.

"Stay still!" Vey says.

He is on the road behind the cart with a short knife. He has cut across one foreleg, but the thing hasn't let go. His clean brown sleeve is wet to the elbow.

I set my feet again. The pattern is there, easier to find and harder to trust.

One more point.

This time I hold while Vey gets clear.

Sella pulls her sword free of the first body and reaches us before the third breath. She takes the creature behind the skull with her sword, pulls it off the rail, and uses her boot to keep it down. The body beats against the road. I shut my eyes, which doesn't make any part of the sound go away.

"Clear," she says.

I keep holding.

"Maya. It's clear."

The strength drains out of the shield. I lower it onto my knees and start shaking so hard the metal rim knocks against the wood.

Tolliver comes around the cart with his bow down. There is blood on one sleeve. He looks at me, at the shield, then beneath the cart, checking even now.

"Bitten?"

I shake my head. Then I look at my arms because being wrong seems possible.

No holes. The old scrape. The broken knuckles. A long red mark where the strap crossed my wrist.

"No."

He puts his hand on the rim to stop the knocking. He doesn't try to take it until I let him.

---

We do not celebrate beside the dead things.

Sella and Tolliver check both ditches. Vey climbs back into his cart without comment about his sleeve. Nessa gets the horse settled, then we cross the stones slowly with someone walking on each side.

At the wayhouse, a man comes out with a pitchfork, hears about the grille, and immediately calls for his sons. A little girl is sent to keep the goats in their yard. The loose iron isn't our private encounter. It is a thing that will keep happening until somebody fixes it.

I check the sack before I sit on the mounting block. Two tooth holes near the knot, nothing missing. My shirt is still inside its bundle. I put the borrowed shield in the dirt beside me and open my measure.

**[MAYA SZCZEPANIAK, LV. 2]**

**[PROGRESS: 6 / 14]**

**[RESERVE: 1 / 4]**

**[RUN: WARDER]**

Under the run, when I attend to it, Brace opens into the same shape I found against the crate. I can recall it without spending. I don't try to use it.

Sella crouches in front of me.

"You took it."

"Yes."

"Any pain when you breathe?"

I test carefully. My shoulder aches. My ribs move without anything sharp.

"No."

She checks the strap mark after I offer my arm.

"Your back support moved. Next time, choose something that won't."

"I'll request a better cart during the next attack."

She grins, briefly. "Good. Still annoying."

I look at the shield in the dirt. The tooth marks are much deeper than I expected.

"Did I choose wrong?"

She sits beside me instead of answering immediately.

"I can't tell you whether you'll want it in ten years. I can tell you that getting scared doesn't make the choice worthless. You'll have to learn it somewhere quieter now."

"Does it always do that? Offer the word when you try?"

"If you've got enough of the pattern. Some people practice for weeks. Some take it on the first good attempt. A word you don't understand won't hold a run for you."

I rub the heel of my hand against my skirt.

"I stopped moving. That's what I picked."

"For a few breaths. When I fight, do I look nailed to the road?"

I think about her moving from the horse to the back of the cart. "No."

"Then learn the next thing when you can do the first."

She gets up, retrieves her shield, and carries it to the trough to wash off the blood.

Tolliver brings water in a cup. I drink half before noticing he's watching my hand.

"I can hold it," I say.

"I know."

He sits on the ground, leaving the mounting block to me. There is a slice through the outer wool of his sleeve. The skin beneath is unbroken.

"I thought it got you," I tell him.

"The blood isn't mine."

I put the cup down and touch the torn edge anyway. He goes still under my fingers.

It is a small thing to do. I have leaned against this man to walk, slept in a room he paid for, watched him take apart the arrangements that made me dependent on him. Somehow choosing to touch his sleeve in a yard is more difficult than any of that.

"Don't make something out of this," I say.

"I'm sitting very quietly."

I laugh, once, and my hand stays where it is.

After a while he turns his palm up on his knee. I move my fingers down to it. Neither of us pulls. His hand is warm and has a callus along the base of the fingers where the bowstring must rub.

We sit like that until Nessa comes to tell us where we're sleeping. I let go first. He lets me.

---

The short-hire agreement gets me stew, a place on a shared sleeping platform, and a blanket that smells aggressively of sheep. I eat Hester's remaining bread with the stew. My six bits remain six.

Vey has washed his sleeve. A pale patch remains where the blood was, which is apparently how his expensive coat deals with danger.

"Thank you," I say when he sits across from me.

"You're welcome."

I am annoyed that he has earned a sincere thank-you. It would be much easier if the people holding the things I need were consistently awful.

He puts a folded sheet on the table.

"A tracing from the notebook. I brought it as a second sample. For you to look at, if you wish. You don't owe me a word of work before you've seen the records."

"Tomorrow," I say automatically. My shoulder is throbbing, and I have reached the point where reading prices on a menu would count as advanced scholarship.

"As you prefer."

He leaves it on the table.

Of course I unfold it.

There is a diagram in faded copied lines: a channel, two circles, a box with an arrow on each side. Some of the dimensions are written in local script. The notes crowded against the right-hand margin are English.

Not printed. Handwritten. Crossed out in places. Whoever made the tracing preserved even a small spiral doodle beside one of the circles.

I put my finger below the first line so I won't skip anything.

*First gate changes the water level. Second changes where the water comes from.*

Below it, underlined twice:

*It isn't a drain.*

There is one more note at the bottom. The letters get smaller toward the end, squeezed into the space before the edge of the paper.

*Do not send anyone through until we know what happened to the rope.*

I look up.

Vey has not gone upstairs. He is waiting by the hearth with his hands clasped behind his back.

"Did she write this before she left?" I ask.

"We think so."

"What happened at the south sluice?"

He draws out the chair again.

"I'll have the closure record brought with the other documents you've asked to see."

"I'm asking you."

For a moment the common room seems very loud around us. Spoons against bowls. Nessa arguing pleasantly about the quality of the hay. Somebody shifting a log in the fire.

"Two people went below," he says. "One came back."

I flatten the page with my good hand.

"Which one was Elena?"

"The one who came back."

CHAPTER ELEVEN

“Who was the other person?”

Vey pulls his chair nearer the table. A man behind him laughs at something, loud enough to make me hate him for half a second.

“Iven Orrel. A sluicewright in the house's employ.”

“Did you know him?”

“Yes.”

“What happened?”

“I wasn't below with them.”

“Then start where you were.”

He looks at the tracing beneath my hand.

“I was in the counting room. Someone came for me because there had been an accident at the south works. By the time I reached the headwall, Elena was up. Wet to the waist. She had rope burns on both hands. She kept asking them to lower the gate again.”

“The second gate?”

“I don't know what she called them. They had stopped the inner wheel by the time I arrived.”

“Why wouldn't they open it?”

“Because the man who worked it had just lost someone.”

I lift my hand off the paper. There is a damp print where my palm was.

Vey takes a slow breath.

“She said Iven was on a stair. There was no stair on the works plan. She wanted the wheel turned to a particular position so she could go back for him. The foreman refused. They'd had water rising in a chamber that should have been drained. His first duty was to the people he could still reach.”

“What did you do?”

“I agreed with him.”

The answer makes his face harder to look at. I can imagine him standing on the bank in a dry coat, saying something reasonable while Elena tears skin off her hands trying to get past him.

I can also imagine the reed-jack coming over the cart and everyone deciding that the best way to help is to climb in beside me.

I don't know what I would have done. I hate that almost as much.

“Did anyone look afterward?”

“They sounded the lower pool. Dragged the outlet. Sent men along both banks for three days. Nothing was recovered.”

“A search for a body.”

“Yes.”

“She was asking for a search for a person.”

“She was.”

My thumb catches the edge of the table. A splinter lifts without breaking off. I press it flat again.

“How long after that did she leave?”

“Eleven days. I remember because I was still arranging wages for the search crews.”

“And you decided ‘argument about safety’ covered this when you were hiring me.”

“No. I decided you might refuse to come if I told you before you saw the writing.”

For a moment I have nothing to say.

The common room carries on around us. Someone asks for salt. The fire spits. Vey has just admitted to doing exactly what I thought he was doing, and somehow the honesty is more infuriating than another evasive answer would have been.

“You don't get credit for saying that now.”

“I wasn't asking for it.”

“Then why say it?”

“Because you've asked me a direct question, and I have run out of answers that improve it.”

I fold the tracing along its old crease. Carefully. It belongs to a woman who tried to bring somebody back, or to a woman who made a terrible mistake and couldn't accept it. So far I have one man's account of both possibilities.

“Who can tell me what happened below?”

“Only Elena could tell you all of it. Dain worked the wheel. He's still at Rook.”

“And this Orrel man's family?”

“His sister is our keeper of records.”

“The person Elena worked with.”

“Mara. Yes.”

I lean back. My shoulder complains, a deep ache that travels down the outside of my arm.

“Does she know you're bringing me?”

“She knows I've hired a reader.”

“Does she know why you think I can read it?”

“I sent word that you recognized the marks on Elena's card. Nothing about your origin.”

That is a claim I can ask someone else about tomorrow. I put it with the others.

Vey reaches toward the folded tracing, then stops short of it.

“You can keep that copy.”

“I was going to.”

He gets up. Before he can leave, I ask the question that has been underneath all the others.

“Do you think she's alive?”

“I saw a woman leave with food, money, and a walking staff. She had learned a great deal in nine months.”

“That's not an answer.”

“No,” he says. “It isn't.”

---

Sella finds me beside the wash trough trying to get a strip of linen around my knuckles with my teeth.

“You'll make those filthy.”

“I rinsed them.”

“Your mouth?”

I lower my hand.

She takes the strip the wayhouse woman gave me and asks permission before inspecting the skin. The bleeding stopped hours ago. Water has softened the edges, and I have been bending my fingers to see if they hurt, which turns out to be an excellent way of keeping them that way.

Sella wraps them loosely. The linen is included in the wayhouse's charge to Vey, according to the woman, who looked much less concerned about this expenditure than I did.

“Does Brace work without a shield?” I ask.

“Yes.”

“Could I hold a rope?”

She stops with the knot half-made.

“What rope?”

“Hypothetically.”

“No one asks about a hypothetical rope with that face.”

I look toward the stable. Tolliver is helping Nessa shift a feed sack. He looks up once, sees us, and goes back to the sack.

“I read something about someone who went missing in water.”

“A shield spreads pressure,” Sella says. “A rope puts it through your hands or whatever you've tied it to. Brace doesn't make your skin stronger. It doesn't make the thing behind your feet stronger. If you hold against more than either can take, something tears.”

“Even if the hold works.”

“Especially then.”

She finishes the knot.

“You can practice with your forearms on a wall tomorrow. No spending tonight. Those hands need to close.”

I thank her. She accepts it with a brief nod and goes to check the shield straps before bed.

Inside, the sleeping platform has been divided by bags and elbows into territories nobody admits to claiming. I take the space beside Sella's pack. My sack goes beneath my head, with the tooth holes facing the wall.

My mother has a sewing tin with strawberries painted on the lid. When I was little I believed it contained cookies because it had once contained cookies, and apparently my faith in packaging was absolute. Even after I knew, I used to open it. The little paper packets of needles. A tape measure curled like something asleep.

She could fix this sack in five minutes. She'd turn it inside out first and ask why I hadn't brought it over before the holes got so big.

I put my wrapped hand over my mouth.

On Earth someone may be trying to find me. Liam heard me fall. I keep returning to that fact as if I can make it a window by polishing it enough. He knows my first and last name. He knows Kansas City. I cannot remember whether I ever gave him my apartment number.

For a while I try to reconstruct every conversation we've had about food delivery.

Then I stop, because the attempt is doing something ugly to my breathing.

Beside me, Sella turns over without waking. I count her breaths until I can match them. When I finally sleep, there is no forest in it. I dream of my phone ringing in a room I can't enter.

---

We leave before the sun reaches the reeds.

My reserve is three out of four. My shoulder is still attached, although it has submitted an objection. Sella checks the bandage, tells me to leave it alone, and packs her sword within reach.

At the first long stop she gives me a lesson against the side of an old stone cattle pen. Forearms against the wall, feet planted, no shield. She pushes my hip sideways with two fingers and makes my whole carefully arranged body useless.

“You need to know when you've lost it,” she says. “Don't spend because you wanted the first stance to work.”

We practice moving away, setting again, and admitting when I haven't got it. No reserve. No exciting numbers. By the time Nessa calls us back, I have learned that retreat can consist of one extremely unglamorous step.

The marsh opens into fields. Narrow watercourses divide strips of beans and something with a gray seed head. People work along the banks with hooked tools. One waves Nessa down to ask about the damaged crossing; she gives him the wayhouse keeper's report that a temporary grate was fitted before dawn.

News has places to go even when I am not carrying it.

Near midday, the road rises. I see Rook House from the top.

There is a large house, technically. Most of what surrounds it appears to have been built by people who would find the name misleading. Long sheds. A mill. Three yards, two chimneys, a row of narrow dwellings with washing strung between them. Water shines along a raised channel before dropping out of sight beneath a wheel. Beyond the buildings, a low wall cuts across a shallow valley.

I look for a forbidding tower and get a man chasing a pig away from stacked timber.

“Which part is the south sluice?” I ask.

Vey points beyond the mill to the low wall. From here it looks about as sinister as a parking barrier.

A cart of empty barrels passes us going out. The driver complains to Nessa about the lower road being soft. She asks whether anyone has finally filled the hole near the lime shed. Apparently they have not. We roll into the yard while their professional disappointment follows us through the gate.

A clerk checks names against a slate. I expose mine when asked. He looks from my level to my face, then to Vey.

“Reader,” Vey says. “Short hire.”

The clerk writes it down.

Nobody cheers. Nobody rings a bell because someone from another world has arrived. A woman shouts that if we leave the carts there, the meal wagon won't get through.

We move the carts.

---

Mara Orrel meets us in the records room with a stack of books already on the table.

She is somewhere in her forties, with graying hair pinned badly enough that I can see where she has given up on the back. Ink stains the side of one finger. Her plate reads **[KEEPER, LV. 21]**.

“Wash,” she says, pointing toward a basin. “Soap is underneath. Dry thoroughly. No wet hands on the paper.”

Vey introduces me while I obey. Mara waits through my last name, then asks me to say it again. She gets closer on the second attempt.

“You have your agreement?”

I retrieve it.

She lays Rook's copy beside mine. We compare them, including the additions about Elena and food on the return journey. The words match. Mara enters tomorrow as the first reading day if I choose to begin. Today is arrival, records, and a bed.

Then she sets the agreement aside and opens the first book.

“Elena's entry. Here.”

The script takes a moment to become meaning. I follow her finger down the page.

Elena Mercer. Adult. Level one. Origin unrecorded. Found on the western towpath after heavy rain. Admitted on paid survey trial. Place of birth declared as Missouri; attestation unavailable.

There is a signature in English beneath it.

Elena R. Mercer.

The looping M is ridiculous. Big enough to be showing off. I love it immediately and feel foolish for loving it.

“She wrote that herself?”

“I watched her.”

“Could she read your writing?”

“Yes. She found that very upsetting.”

I laugh before I mean to. Mara looks at me, and I press my lips together.

“No,” she says. “It was funny sometimes. She'd be furious to discover I'd made her solemn.”

Vey moves toward the window. There isn't much space there. The room contains shelves from floor to ceiling, with bundles tied in cloth and little bone tags hanging off the knots. It smells of dust and damp wool.

Mara turns several pages in a thinner volume.

“Departure.”

Elena's name. A date eight months and twenty-six days after the entry, Mara explains when I cannot make useful sense of the local month names. Level nine. Trial converted to day hire during the first month. Wages settled. Departed by west gate with a pack and staff. No continuing service claim.

“Four years ago?”

“Four years and a little under two months.”

Below the departure is a cross-reference to retained materials. Mara opens that book too, without waiting for me to ask.

One wooden chest. Survey notebook. Loose plans. Measuring line. Writing implements. Small foreign objects, separately listed. Removal disputed under ownership of paid survey work. Chest sealed pending adjudication.

I look up.

“He said she left her chest.”

“She did leave it.” Mara glances toward Vey. “After we refused to release it.”

The room seems to tighten around the three of us.

Vey says, “I did not tell you she abandoned her claim.”

“You let me think she could have taken it.”

“Yes.”

There is that horrible little honesty again, arriving once it can no longer cost him the journey.

I turn back to Mara.

“Her clothes?”

“Released to her. Most personal effects. The card was held with the items whose relation to her survey we could not establish.”

“It's identification.”

“I know that now. At the time she called it that, and we had no means of reading it.”

“She told you what it was.”

Mara's stained finger rests on the page.

“Yes.”

I want her to explain until it becomes acceptable. She doesn't try.

“The dispute is still open?”

“In this record, yes.”

“Then put the card back under her name when he returns it.”

“It never left her name.”

“Make sure it doesn't.”

Mara draws a narrow slip toward her and writes a note. I cannot tell whether she agrees with me or is merely competent enough to record a complaint.

The closure book is last.

South sluice. Lower works barred following loss of Iven Orrel. Access to inner mechanism prohibited pending examination. Outlet secured; surface water to be carried by bypass. Authorizing signatures follow.

Master Vey's is the second.

Above them is a short account. Rising water. Loss of visibility. Elena returning along the service passage. Iven unrecovered. Search instructions. Attached witness statements, three in all.

Mara lays them out.

Dain's says the inner wheel moved farther than ordered after a retaining tooth failed. He could not restore it immediately under load. Elena came back during the attempt. By the time he brought the wheel to its prior mark, she was demanding that he open it again.

“So it wasn't just somebody deciding to try a door.”

“No,” Mara says.

“Was this tooth ever repaired?”

“The broken part was taken out. The replacement was never fitted. The closure made it unnecessary.”

The second statement belongs to someone on the bank who heard shouting and helped Elena out. It confirms very little beyond how wet she was and that her hands were bleeding.

The third has been written in local script by Mara, with Elena's signature at the bottom.

I read it twice.

Elena says the chamber beyond the arch was dry. There were steps on the far side. Iven crossed the sill before the light changed. When water entered, he was beyond her reach. She pulled the line and got back a length shorter than the one paid out. She did not see him fall. She did not see a body. She objected to the word drowned.

Near the bottom, another sentence has been crossed through once, still readable.

*The steps were lit without flame.*

“Who crossed that out?” I ask.

“I did.”

“Why?”

“Because I couldn't get her to describe the lights. I thought she'd struck her head.”

“Did she?”

“The mender found no wound there.”

I look at Mara. Her mouth is pressed flat, but she doesn't look away.

“I left the words legible,” she says. “That was the compromise I made with myself.”

I put the paper down before my hand shakes against it.

Elena saw lights. She said she saw lights. That difference is the size of a whole world, and I am already trying to climb across it.

“Did you believe her about your brother?”

Mara looks at his name on the closure record.

“I believed that she wanted him back.”

Outside, somebody rolls a barrel over the stones. The hollow bumps reach us through the wall.

“Can I copy these?”

“Yes. The clerk will bring paper. Originals stay here.”

I sit. My feet are grateful enough to distract me for a moment. Then I realize there is a fourth sheet tucked behind Elena's statement.

It is only a scrap. Six words, written in English, the pen pressed hard enough to tear the paper in one place.

*He was still pulling his end.*

I don't know what noise I make.

Mara reaches across the table, then stops before touching me.

“What does it say?”

I look from her hand to the line of writing.

Until now, being able to read this has felt like something people might take from me. I have not considered what it will mean to be the person who tells her.

I read the words aloud.

CHAPTER TWELVE

Mara asks me to read it again.

I do.

She draws the scrap closer with one finger. Her nail has a split near the edge. I watch it catch on the paper because looking at her face feels like something I should ask permission to do.

“When did she write that?” I ask.

“The morning she signed the statement. She handed it to me afterward.”

“What did she tell you it said?”

“Nothing. I thought she had written his name.”

There are six words. Even if you can't read them, there are six distinct pieces of writing.

Mara sees me look.

“I wasn't examining it very closely.”

“I'm sorry.”

She shakes her head once. “So am I.”

Vey stands by the window with his hands behind his back. For once he has nothing to contribute.

I turn the scrap without lifting it. Blank on the other side.

“It doesn't say when the pulling stopped. Or why. I don't know if—”

“I know what you don't know.”

The words come sharply. She shuts her eyes.

“I know,” she says again, quieter.

We sit until a clerk arrives with paper. Mara takes it from him, sets out a ruler and a little pot of ink, and shows me how to keep my copying sheet from sliding. The ordinary instructions make it possible to start.

I copy the records, including the crossed-out sentence and the six English words. Mara watches me reproduce Elena's signature as a labeled copy rather than as my own attempt at signing it. When my hand cramps, she tells me to stop. I am finished anyway.

At the door she says, “He had two sons.”

I turn back.

“Iven. One was small enough that we had to explain more than once.”

“I'll be careful what I say.”

“Yes,” she says. “Please.”

---

My room is above the west kitchen. It has a narrow bed, a peg, and a shutter opening onto a roof where someone has planted herbs in broken pots. The door bolts. I test it twice, then put my copies beneath the folded Earth shirt in my sack.

Supper is downstairs with people who have opinions about flour deliveries. Nobody asks whether Iven is alive. Nobody knows that I have spent half the afternoon considering a length of rope with a person at the other end.

Tolliver is at the far end of the table. He moves a jug so I can set my bowl down, but doesn't turn the empty place beside him into an invitation I have to refuse. I sit there because I want to.

“Paid?” I ask.

He taps his purse. “Two pieces. Sella too.”

“Are you going back?”

“Eventually. Dain wants someone to walk the lower channel with him the day after tomorrow. Tracks, bank damage, animal holes. I've taken two days, paid by the day. After that I haven't decided.”

“You don't have to stay because I'm here.”

“I know.” He tears his bread. “I like knowing where you are. I also need wages. Both can be true.”

I stir my bowl. It contains beans, onion, and something that was probably a bone's most successful ambition.

“I don't know what I want you to do.”

“You don't have to hire me.”

It is funny enough that I smile. He sees it and smiles too, briefly, before someone asks him to pass the jug.

After supper I mend the tooth holes with a needle borrowed from the kitchen. The stitches are uneven and much too close together. They hold. For tonight that is a reasonable standard.

I sleep with the repaired sack under the bed instead of beneath my head.

---

The notebook arrives in a shallow wooden tray.

Mara puts it on the records-room table the next morning, then sets a separate dish beside it containing a pen cap, a rusted metal clip, and two tags tied to lengths of cord. Vey places Elena's card in the dish and Mara records its return in front of me.

I want to take it. Put it with my shirt. Have one more object on my side of the room that comes from a world with traffic lights.

I keep my hands on the table.

The notebook is local paper stitched into a soft leather cover. Some pages have warped where they were wet. A corner near the front is missing, neatly cut rather than torn. Mara says it was like that when she received it. She counted thirty-six written pages, leaving blanks out of the tally.

“Today begins the six?” she asks.

“Yes.”

She writes the date. I have already seen the records. I have slept on the decision. There is no one left to blame for this part being mine.

I open the cover.

The first page contains a list of measurements, a rough conversion between local units and meters, and an English sentence boxed in the margin.

*Do not trust the old map's north.*

“Oh, good,” I say. “She's been here.”

Mara's mouth moves.

“She said that often. Usually with worse words.”

The next pages are drainage notes. Culvert widths. A badly drawn beetle beside a calculation. A list of people owed meals for holding the end of a measuring line. Elena's handwriting grows small when she is thinking and large when she is angry. At least that is how it looks to me. I don't know her. I need to keep remembering that.

Some technical words slow me down. Reading English does not make me an engineer. I write *head* on my paper and explain to Mara that here it seems to mean something about water height or pressure, not a body part. She fetches Dain before I turn an uncertain definition into a confident mistake.

He arrives with a wooden cup and a limp that takes a moment to settle after he sits. **[SLUICEWRIGHT, LV. 24]**. His beard is short and almost entirely white. Two fingers on his left hand end at the first joint.

“That Elena's?”

“Yes,” Mara says.

He sets down the cup with unnecessary care.

I show him the sketch. He traces the lines with a clean sliver of wood, keeping his hands off the page.

“Water stacked above you,” he says. “More stack, more shove. What's she arguing about?”

“Whether the water on this side can get high enough to do what she saw.”

He studies the numbers.

“It couldn't. I told her that.”

“She wrote it down.”

I point to his name in local script, followed by an English note.

*Dain checked twice. Stop asking him the same question.*

He makes a small sound through his nose.

For the next hour he helps us separate things Elena measured from things she guessed. I read each page aloud in pieces, and Mara writes the local version. I keep my own notes and check the copies against each other. It is slow work. It is also work I can do, which steadies me more than I expect.

There is no welcome message for the next person from Earth. No explanation of how to get here or how to leave. Elena has recorded wages in the back, crossed out a shopping list, and spent nearly half a page trying to describe coffee to someone who recommended burnt barley.

I run a finger along the edge of that page.

My first closing shift, I spilled a pitcher of steamed milk down my apron and had to stand in the walk-in because I couldn't stop crying. The manager thought I'd burned myself. I let her think it because explaining that I was tired and eighteen and couldn't do a single fucking thing correctly seemed more embarrassing.

Elena wanted coffee badly enough to make notes about it.

I can tell Mara the words for that. I cannot give her what they mean to me.

Near the middle we find the original of the tracing.

The lines are darker here. One of the apparent circles is a wheel seen from above. The other is a ring around an opening drawn in section. Beside it Elena has made three observations on three different dates.

Cold water, mineral smell.

Warm water, fine pale grit.

Air moving inward when the lower pool is still.

Underneath:

*Changing the setting changes the source. It does not tell us where that source is.*

I read the sentence twice before translating it aloud.

Dain leans forward.

“She did tell me the first part. Thought she meant an old feeder we'd never found.”

“Did you see the grit?”

“Yes. Cleaned it out myself. Twice.”

“Was it different from what's in your river?”

“Different from what comes down here. That doesn't tell you how far it traveled.”

I nod. He has seen what is written on my face and is being careful with it.

Lower on the same page is the rope warning. Beneath the main diagram, a smaller sketch shows something I took for a handle in the tracing: a metal tongue sitting in a notch.

Dain recognizes it immediately.

“The retaining tooth.”

“The one that broke?”

He nods.

There are two sets of writing beside it. Local dimensions in a tidy hand that may be Mara's. An English annotation crammed between them and the binding.

*Secondary inlet still under load with first gate shut. Closing upstream does not isolate. Lock inner wheel before bypass test.*

Dain holds the sliver of wood motionless above the page.

“Read that again.”

I do, more slowly. Then I explain isolate as best I can. Stop something from still getting into the place you're working.

He gets up.

“Where are you going?” Vey asks.

“To stop the test.”

---

Outside, the mill makes enough noise that I have to hurry to hear him.

“What test?”

“Bypass draw. Tomorrow we have the lower bank survey. Today they check how far the surface channel can take the head down.”

“You said the sluice was closed.”

“The sluice is closed. Nobody's supposed to touch the inner wheel.”

He takes the corner beside a stack of tiles faster than his limp ought to allow. I slow to keep from slipping in the mud.

“Is somebody touching it?”

“No. But its tooth is in a cupboard, and everyone thinks shutting the river gate took the weight off it.”

The watercourse leads us past the mill to an open gravel yard. Sella stands by a rope stretched between two posts, redirecting a boy with a basket. Beyond her, two workers are hauling on a long lever. Water foams from an opening in the side of the raised channel and races toward a ditch.

It looks purposeful and expensive. I would have assumed it was fine.

Dain puts his fingers in his mouth and whistles.

Both workers turn. One lets go of the lever; the other keeps it where it is.

“Hold there,” Dain calls. “Don't move it back yet.”

He walks to a narrow sight box set into the stone. A little iron rod protrudes from the top, marked with pale lines. It shakes hard enough to make a ticking sound.

I stop beside Sella. The rope is waist-high. Beyond it a stair leads down to an iron-covered opening in the bank. I can see a lock. Nobody is standing on the stairs.

“Problem?” she asks.

“Maybe.”

Dain crouches at the sight box. He says something to the worker holding the lever. The worker answers. The ticking speeds up.

I cannot read a water gauge. I cannot fix a sluice. I can feel Brace waiting under the thought of my run, absurdly available, as though the world has presented a familiar button beside a problem it will not solve.

Dain looks over his shoulder.

“Sella, clear the towpath below the outlet. Everybody up to the yard. Walk them. No running.”

She is moving before he's finished. She hands me the end of the rope as she unhooks it from the nearest post.

“Across the path behind me. Let the workers come up. Don't let anyone down.”

I take it in my good hand.

There are five people below, two of them carrying a long rake between them. Sella calls them by their work rather than their names. They know she means them. She gets the pair turned first so they don't swing the rake into anyone else.

A woman approaches from the yard with a bucket.

“Not that way,” I tell her.

“I use the lower pump.”

“They're clearing it.”

She looks over my head at my plate.

For one exhausting second I prepare to argue about level two.

Then Dain calls, “Pump as well, Tessa,” and she turns around.

Fine. I will take having an organization behind me for once.

The ticking becomes a rattle. A worker comes up the path too quickly, sees the rope, and hesitates.

I lower it all the way to the ground. He steps across. The next person follows. I count them because counting is available. Three. Four. The last man has stopped for the rake.

“Leave it,” Sella tells him.

He leaves it.

“All up,” she calls.

Dain raises his hand. The worker on the lever eases it back while the other man puts his weight on a second bar. The water leaving the side opening narrows, then surges once before shrinking to a dirty ribbon.

Under the gravel, something knocks.

It is one deep impact. I feel it in my boots.

Everyone stops speaking.

The iron rod gives three more little tremors and settles.

Dain stays where he is for a long time, watching it. Nobody congratulates anybody. One of the workers wipes his mouth with the back of his hand.

Eventually Dain stands.

“Posts stay. No one uses the lower path until I say.”

“What was that?” I ask.

“A gate taking weight.”

“Which gate?”

“That's what I'm going to establish before anyone puts a hand near it.”

Sella takes the rope back from me and knots it to the post. My hand has gone stiff from holding it, although I haven't pulled against anything at all.

“You spent?” she asks.

“No.”

“Good.”

It is the first time anybody has sounded pleased that I didn't use my magic.

---

The argument happens in the yard because Dain refuses to go far enough away that someone might mistake his departure for permission.

A woman in a green coat arrives carrying a rolled plan. Her plate reads **[STEWARD, LV. 27]**. Vey introduces her as Steward Anja Pell, then gives her the shortest version of the discovery he can manage.

She asks Dain whether the test caused damage.

“I won't know until the indicators stay quiet and we check the outer fittings.”

“Was anybody below the closure?”

“No.”

“Then keep it that way. The test is suspended.”

I had been assembling a speech. It has nowhere to go. I stand with my mouth slightly open while she asks who needs to be told about the lower pump.

Only after those instructions are settled does she look at me.

“You read the warning?”

“Yes.”

“Can you show me precisely what it says?”

“It's in the records room.”

“Mara can bring the copy.” She turns to Vey. “You said six days.”

“For the whole notebook. We can prioritize the works pages.”

“What happens in six days?” I ask.

Pell unrolls her plan on a crate. One corner has been patched with a different color of paper. The lines show the mill channel, the bypass, and three fields beyond the low wall.

“In five, a crew arrives to remove the inner wheel and its spindle. We need the lower chamber safe before they cut out the assembly. The bypass is meant to carry drainage permanently.”

“You're taking it apart.”

“It has been shut for four years. We still have fields under water twice a season and a works budget paying men to inspect a lock.”

“It may go somewhere.”

“So does every culvert on this land.”

“That's not what I mean.”

“No,” she says. “I understand what you mean. Vey has explained what you recognized.”

The mill wheel groans behind us. I hate hearing that he has explained me to another person even when this time it's probably part of the job I agreed to.

“What if taking it apart opens it?” I ask.

“Then you and Dain have just given me a reason to change how we remove it.”

“Or not remove it.”

“That will require more than a possibility.”

I look down at the map. The flooded fields have names. Someone has drawn small marks for houses along their edges. Whatever this mechanism might mean to me, other people have been trying to grow dinner beside it.

Dain puts his cup on the corner of the plan. Somehow he brought it all the way from the records room.

“No cutting until I understand what took that load,” he says.

Pell considers him.

“Agreed. But tell me what you need to understand it. Don't hand me another four years.”

Mara arrives with the copied page. Pell reads it, asks me about three words, then has Mara add the suspension to the works instructions in writing. The removal crew is still due in five days. Cutting now depends on Dain's clearance.

The distinction is small enough to fit into two lines and large enough to make me want to sit down.

Before Pell leaves, I ask whether Elena knew they might remove it.

“The present order is mine. Elena left before I became steward.”

“So you're not the person who kept her chest.”

“No. I'm the person with the unresolved claim in my accounts.”

“It's her identification in there.”

“Then submit that finding with the item number. I can review it.”

She rolls the plan up and goes to speak to the miller. I watch her leave, wishing she had either laughed at me or handed me everything. Having to persuade her sounds like a lot of work.

---

By evening, I have a headache behind one eye and a list of words I will never again assume I understand merely because they're English.

Dain returns to say the visible fittings are intact. The inner wheel's indicator has moved a fraction from the mark recorded before the draw. The lock on the access cover remains untouched. He has witnesses for all three observations and refuses to tell me what they prove beyond movement under a change of water level.

I like him more every time he disappoints me accurately.

We finish copies of the warning and its adjoining pages. Mara records which uncertainties need Dain and which need me. I ask for the card's item number and write a short statement identifying it as a personal driving credential, including why the photograph, dates, and address matter. Mara accepts it for Pell's review. Nothing is released today.

At the pay desk, a clerk gives me one piece.

It is heavier than a bit and still ridiculously small for how much I have thought about it. I put it with my six bits. Fourteen bits if I need to make change. Five reading days left.

My measure, when I check in my room, has changed too.

**[MAYA SZCZEPANIAK, LV. 2]**

**[PROGRESS: 8 / 14]**

**[RESERVE: 4 / 4]**

**[RUN: WARDER]**

I don't know when the two progress arrived. The practice at the wall, the work, the yard. Maybe some combination. There is no helpful receipt listing approved activities.

I write the numbers on my copy paper, with the date Mara taught me. My knuckles are closing. My shoulder hurts when I reach too high. Leveling has not filed a repair request on my behalf.

After supper I find Tolliver on the outside stair, replacing the binding on an arrow. There is room beside him, and I sit.

“I heard about the test,” he says.

“I held a rope with absolutely nothing pulling on it.”

“An advanced road skill.”

“Apparently.”

He turns the arrow slowly between his fingers. Below us the kitchen door stands open, letting out light and an argument about who took the clean pot.

“Dain's changed tomorrow's work,” he says. “We're checking the outer banks only. Sella's on the closure path. I'll be back before the evening meal unless he finds a problem.”

“Thank you for telling me.”

He nods, looking at the thread.

For a while I watch his hands. I have watched those hands do a lot of things: draw a bow, count money, take mine without closing too tightly. Knowing what they can do is becoming a problem for my concentration.

“I got paid.”

“How much did they try to deduct for frightening the steward?”

“She frightened me.”

“She's had practice.”

I laugh. He sets the arrow aside before turning toward me.

There is a pale line of old scar near his mouth. I noticed it before, but I have never been this close with nothing happening that requires him to help me stand.

“I still want to go home,” I say.

His expression changes. Not much. Enough.

“I thought you would.”

“If there's a way, I want to find it.”

“I know.”

“I don't want you agreeing because you think I'll stop wanting it later.”

He looks down into the yard. A kitchen worker crosses with a covered bucket, balancing it against her hip.

“I'd be lying if I said the thought pleased me.”

My stomach tightens.

“But I don't want you stranded for my convenience,” he says.

That gets under my ribs in a place I haven't protected very well.

He turns back. I put my good hand against the side of his face. His breath changes beneath my thumb.

“I'm going to kiss you,” I say, which is possibly the least mysterious thing anyone has ever said on a staircase.

“Yes,” he says. “Please.”

The first touch is softer than I expect. I have been imagining him with so much confidence that the small hesitation undoes me. He lets me choose the pressure, then answers it, his hand settling at my waist. Warm through the wool. Careful of the arm tucked between us.

I move closer. The step edge digs into the back of my thigh. He tastes faintly of the mint someone put in the supper water, and for a few seconds my whole ridiculous situation narrows to the fact that I can make him breathe like that.

When I draw back, he doesn't follow until I touch my forehead to his.

“Okay,” I say.

His laugh is quiet. “Okay?”

“I had better words planned.”

“Were there many?”

“An embarrassing amount.”

He strokes the wool at my waist once with his thumb. I feel it much farther away than his hand.

I kiss him again, briefly, because I can. Then I sit back enough to have thoughts.

“I'm going upstairs alone.”

“All right.”

“I wanted that. I want to be clear.”

“You were fairly clear.”

His smile goes crooked. I touch it once before getting up.

In my room, I lean against the bolted door with my face hot and my shoulder reminding me that romance is not an approved treatment. I let myself stand there grinning. Nobody is watching. I don't have to make the moment practical immediately.

Eventually I wash, set out tomorrow's clothes, and take the notebook copies from my sack.

The work is waiting where I left it. So is the part about home. Kissing him has rearranged neither of those facts, although I suspect it will make both of them harder.

On the last page we copied, below a set of measurements, Elena has drawn the stair again. I hadn't looked closely while we were racing the test. Four steps, a flat place, then an empty square outlined twice.

Beside it are three English lines.

*No view of the far side from the wheel. Do not let them call turning it a search.*

*Need a way to see before we cross.*

*Mirror?*

The last word has a question mark large enough to take up its own line.

I pull my blank sheet closer. Tomorrow I can ask Dain whether there is any safe way to look from this side. He may say no. Given the available evidence, no would be a reasonable answer.

Under the question I write another one.

*What would have to be true for yes?*
