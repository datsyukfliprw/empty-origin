# Maya — active novel project

Continue from **[book1/WORKING_DRAFT.md](book1/WORKING_DRAFT.md)**, currently through Chapter Twelve. Individual chapters are in [book1/chapters](book1/chapters).

The two supplied export directories and their ZIPs are preserved as source snapshots. Their old 200,000-word target is superseded by the author's instructions and the active [project notes](book1/PROJECT_NOTES.md).

Read these before continuing:

1. [Project notes and binding author preferences](book1/PROJECT_NOTES.md).
2. [Cumulative story overview](book1/STORY_OVERVIEW.md).
3. [Chapter ledger](book1/CHAPTER_LEDGER.md), especially the current endpoint.
4. The complete latest chapter and relevant earlier scenes.
5. [Editorial direction](book1/EDITORIAL_DIRECTION.md), which is provisional planning, not established canon.

Chapters One–Five were copied without editing from `maya-project-through-chapter-05/chapters/`. Chapter Six was copied without editing from `Nora_Whitcomb_MD_Files_Partial/Pasted markdown.md`. Chapters Seven–Twelve are the continuation; the latest drafting pass added Chapters Eleven–Twelve.

The supplied [Nora Story Ledger skill](Nora_Whitcomb_MD_Files_Partial/SKILL.md) governs the overview and ledger. The full Nora prose specification, Route Five plan, Compass, and Zippy implementation were not present in the export. Do not claim to have used those missing resources or silently reconstruct them as inherited instructions.
